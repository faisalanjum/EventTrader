"""Verify live filing bytes, latest source text, and all duplicate groups independently."""
import collections
import concurrent.futures
from decimal import Decimal, InvalidOperation
import hashlib
import json
from pathlib import Path
from urllib.parse import urljoin, urldefrag
import requests
from lxml import etree

OUT = Path(__file__).parent
XL = '{http://www.w3.org/1999/xlink}'
LINK = '{http://www.xbrl.org/2003/linkbase}'
XS = '{http://www.w3.org/2001/XMLSchema}'
DOC = 'http://www.xbrl.org/2003/role/documentation'
results = {t:json.loads((OUT/(t+'_result.json')).read_text()) for t in ['MRCY','LAND','AAPL']}
latest = json.loads((OUT/'latest_2026_comparison.json').read_text())

def verify_live(source):
    response = requests.get(source['url'],headers={'User-Agent':'EventTrader faianjum@gmail.com'},timeout=45)
    response.raise_for_status()
    digest = hashlib.sha256(response.content).hexdigest()
    record = {'url':source['url'],'http_status':response.status_code,'cached_sha256':source['sha256'],'live_sha256':digest,'equal':digest==source['sha256']}
    if record['equal']:
        path = OUT/'live_sources'/hashlib.sha256(source['url'].encode()).hexdigest()
        path.parent.mkdir(exist_ok=True)
        path.write_bytes(response.content)
        record['snapshot_path'] = str(path)
    return record

filing_sources = [s for r in results.values() for s in r['source_manifest'] if s['filing_owned']]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    live = list(pool.map(verify_live,filing_sources))
(OUT/'live_source_verification.json').write_text(json.dumps(live,indent=2))
assert all(r['equal'] for r in live),live
print('Live filing files match:',len(live),flush=True)

trees = {s['url']:etree.parse(s['path']) for s in latest['sources']}
schema_elements = {url:{n.get('id'):n for n in tree.getroot().findall(XS+'element')} for url,tree in trees.items()}
raw_docs = collections.defaultdict(set)
for url,tree in trees.items():
    for link in tree.iter(LINK+'labelLink'):
        resources = collections.defaultdict(list)
        for resource in link.findall(LINK+'label'):
            if resource.get(XL+'role')==DOC:
                resources[resource.get(XL+'label')].append(resource)
        locs = {n.get(XL+'label'):urldefrag(urljoin(url,n.get(XL+'href'))) for n in link.findall(LINK+'loc')}
        for arc in link.findall(LINK+'labelArc'):
            if arc.get(XL+'to') not in resources or arc.get('use')=='prohibited':
                continue
            schema_url, fragment = locs[arc.get(XL+'from')]
            schema = trees[schema_url].getroot()
            element = schema_elements[schema_url][fragment]
            element_key = '{'+schema.get('targetNamespace')+'}'+element.get('name')
            raw_docs[element_key].update(''.join(n.itertext()) for n in resources[arc.get(XL+'to')])

latest_checks = collections.Counter()
for k,record in latest['catalog'].items():
    if record is None:
        assert k not in raw_docs
        latest_checks['names_absent_in_latest_schema'] += 1
        continue
    root = trees[record['schema_url']].getroot()
    assert root.get('targetNamespace')==record['namespace']
    elements = [n for n in root.findall(XS+'element') if n.get('name')==record['name']]
    assert len(elements)==1 and dict(elements[0].attrib)==record['schema_attributes']
    assert {d['text'] for d in record['documentation']}==raw_docs[k], k
    latest_checks['schemas_checked'] += 1
    latest_checks['present_or_absent_documentation_checked'] += 1
assert not latest['load_errors']
print('Latest source checks:',dict(latest_checks),flush=True)

duplicates = {}
for ticker,result in results.items():
    source = next(s for s in result['source_manifest'] if s['url']==result['summary']['instance_url'])
    tree = etree.parse(source['path'])
    all_source = [e for e in tree.getroot().iter() if e.get('contextRef')]
    by_id = {e.get('id'):e for e in all_source}
    details = []
    affected_stored_ids = set()
    for omission in result['omitted_source_facts']:
        record = dict(omission)
        source_fact = by_id[record['source_id']]
        peers = [by_id[i] for i in record['stored_equivalent_ids']]
        if record['reason']=='duplicate_key_with_different_value':
            assert len(peers)==1
            kept = peers[0]
            try:
                source_value, kept_value = Decimal(source_fact.text),Decimal(kept.text)
            except (InvalidOperation,TypeError):
                record['classification'] = 'unresolved_difference'
            else:
                if source_value==kept_value:
                    record['classification'] = 'equal_numeric_value_different_text_format'
                elif kept.get('decimals') not in [None,'INF'] and source_value.quantize(Decimal(1).scaleb(-int(kept.get('decimals'))))==kept_value:
                    record['classification'] = 'stored_duplicate_is_rounded_value'
                    record['source_decimals'] = source_fact.get('decimals')
                    record['stored_decimals'] = kept.get('decimals')
                    affected_stored_ids.add(kept.get('id'))
                else:
                    record['classification'] = 'unresolved_difference'
        else:
            record['classification'] = record['reason']
        details.append(record)
    counts = dict(collections.Counter(r['classification'] for r in details))
    assert not counts.get('unresolved_difference',0),counts
    assert len(result['facts'])+len(details)==len(all_source)
    duplicates[ticker] = {'counts':counts,'details':details,'rounded_stored_fact_ids':sorted(affected_stored_ids),
                           'scope_note':'Read-only observation of existing stored fact selection; no fact values or importer code were changed.'}
print('Source duplicate accounting:',{t:r['counts'] for t,r in duplicates.items()},flush=True)
(OUT/'source_duplicate_verification.json').write_text(json.dumps(duplicates,indent=2))

hash_checks = 0
for result in results.values():
    for source in result['source_manifest']:
        assert hashlib.sha256(Path(source['path']).read_bytes()).hexdigest()==source['sha256']
        hash_checks += 1
verification = {'live_filing_files_verified':len(live),'latest_source_checks':dict(latest_checks),'source_hashes_checked':hash_checks,
                'unexplained_duplicate_groups':0,'rounded_duplicate_observation':{t:r['rounded_stored_fact_ids'] for t,r in duplicates.items() if r['rounded_stored_fact_ids']},
                'passed':True}
(OUT/'verification.json').write_text(json.dumps(verification,indent=2))
print(json.dumps(verification,indent=2),flush=True)
