"""Compare exact standard names against published 2026 schemas, without rewriting history."""
import collections
import hashlib
import json
from pathlib import Path
from arelle import ModelDocument, XbrlConst
from metadata_audit import controller_for, standard_entrypoint, label_record, key, OUT

results = {ticker:json.loads((OUT/(ticker+'_result.json')).read_text()) for ticker in ['MRCY','LAND','AAPL']}
latest_names = {}
entrypoints = set()
for result in results.values():
    for row in result['elements']:
        if row['custom']:
            continue
        family_namespace, old_version = row['namespace'].rsplit('/',1)
        namespace = family_namespace+'/2026'
        schema_url = row['schema_url'].replace('/'+old_version+'/', '/2026/').replace('-'+old_version+'.xsd','-2026.xsd')
        entry = standard_entrypoint(namespace,schema_url)
        if entry is None:
            raise ValueError('Unsupported latest taxonomy: '+row['namespace'])
        entrypoints.add(entry)
        latest_names[row['key']] = '{'+namespace+'}'+row['local_name']

controller = controller_for('latest_2026')
entries = sorted(entrypoints)
model = controller.modelManager.load(entries[0])
for entry in entries[1:]:
    print('Latest: '+entry,flush=True)
    assert ModelDocument.load(model,entry,isSupplemental=True,isDiscovered=True) is not None
model.relationshipSets.clear()
assert not model.errors, model.errors
concepts = {key(c):c for c in model.qnameConcepts.values()}
labels = model.relationshipSet(XbrlConst.conceptLabel)
catalog = {}
for k in sorted(set(latest_names.values())):
    c = concepts.get(k)
    if c is None:
        catalog[k] = None
        continue
    catalog[k] = {'key':k,'namespace':c.qname.namespaceURI,'name':c.qname.localName,
                  'schema_url':c.modelDocument.uri,'schema_path':c.modelDocument.filepath,
                  'schema_attributes':dict(c.attrib),
                  'documentation':[label_record(r) for r in labels.fromModelObject(c) if r.toModelObject.role==XbrlConst.documentationLabel],
                  'deprecated_labels':[label_record(r) for r in labels.fromModelObject(c) if 'deprecat' in r.toModelObject.role.lower()]}

comparisons = {}
for ticker,result in results.items():
    comparison_rows = []
    for row in result['elements']:
        if row['custom']:
            comparison_rows.append({'as_filed_key':row['key'],'status':'company_specific_kept_with_original_report'})
            continue
        latest = catalog[latest_names[row['key']]]
        old_texts = sorted(d['text'] for d in row['documentation'])
        new_texts = sorted(d['text'] for d in latest['documentation']) if latest else []
        status = ('name_absent_in_latest_schema' if latest is None else
                  'same_documentation' if old_texts and old_texts==new_texts else
                  'changed_documentation' if old_texts and new_texts else
                  'no_documentation_either_version' if not old_texts and not new_texts else
                  'new_documentation_available' if new_texts else 'documentation_no_longer_available')
        comparison_rows.append({'as_filed_key':row['key'],'latest_key':latest_names[row['key']],
                                'status':status,'latest_deprecated':bool(latest and latest['deprecated_labels'])})
    comparisons[ticker] = {'counts':dict(collections.Counter(r['status'] for r in comparison_rows)),
                            'rows':comparison_rows,'latest_deprecated_count':sum(r.get('latest_deprecated',False) for r in comparison_rows)}
    print(ticker,comparisons[ticker]['counts'],flush=True)

manifest = [{'url':d.uri,'path':d.filepath,'sha256':hashlib.sha256(Path(d.filepath).read_bytes()).hexdigest()}
            for d in model.urlDocs.values() if Path(d.filepath).exists()]
output = {'checked_year':2026,'publisher_release_index':'https://www.sec.gov/data-research/structured-data/taxonomies-schemas/standard-taxonomies/operating-companies',
          'match_rule':'Exact local name within the same taxonomy family; not a claim of unchanged meaning or a guessed replacement.',
          'entrypoints':entries,'catalog':catalog,'comparisons':comparisons,'sources':manifest,'load_errors':model.errors}
(OUT/'latest_2026_comparison.json').write_text(json.dumps(output,indent=2,ensure_ascii=False))
model.close()
controller.close()
