"""End-to-end checks against published XML and the existing read-only graph."""
import json
import unittest
from pathlib import Path
from urllib.parse import urljoin, urldefrag
from lxml import etree
import metadata_audit

OUT = Path(__file__).parent

class PublishedSourceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.results = metadata_audit.run_all()

    def test_previous_apple_result_is_preserved(self):
        previous = json.loads(Path('/tmp/xbrl_definition_pilot_20260930/pilot_result.json').read_text())
        actual = self.results['AAPL']
        self.assertEqual({r['key'] for r in previous['elements']}, {r['key'] for r in actual['elements']})
        old = {r['key']:sorted(d['text'] for d in r['documentation']) for r in previous['elements']}
        new = {r['key']:sorted(d['text'] for d in r['documentation']) for r in actual['elements']}
        self.assertEqual(old, new)
        self.assertEqual(actual['summary']['stored_facts'],707)

    def test_every_report_has_complete_sources_and_no_fact_version_mismatch(self):
        for ticker, result in self.results.items():
            with self.subTest(ticker=ticker):
                self.assertEqual(result['summary']['load_errors'],[])
                self.assertEqual(result['summary']['unsupported_namespaces'],[])
                self.assertEqual(result['summary']['fact_mismatches'],0)
                self.assertEqual(result['summary']['unexplained_source_facts'],0)
                self.assertGreater(result['summary']['stored_facts'],0)
                self.assertGreater(result['summary']['documentation_present'],0)
                self.assertGreater(result['summary']['documentation_absent'],0)

    def test_every_definition_matches_raw_published_xml(self):
        trees = {}
        count = 0
        for result in self.results.values():
            for row in result['elements']:
                for definition in row['documentation']:
                    path = definition['source_path']
                    if path not in trees:
                        trees[path] = etree.parse(path)
                    matches = [n for n in trees[path].iter('{http://www.xbrl.org/2003/linkbase}label') if n.sourceline==definition['line']]
                    self.assertEqual(len(matches),1)
                    self.assertEqual(matches[0].get('{http://www.w3.org/1999/xlink}role'),'http://www.xbrl.org/2003/role/documentation')
                    self.assertEqual(''.join(matches[0].itertext()),definition['text'])
                    count += 1
        self.assertGreater(count,313)

    def test_positive_and_wrong_year_controls_cover_every_stored_fact(self):
        for result in self.results.values():
            for fact in result['facts']:
                source = fact['source_key']
                self.assertTrue(metadata_audit.same_expanded_name(source,fact['linked_concepts'][0]))
                wrong = dict(fact['linked_concepts'][0],namespace='urn:deliberately-wrong-version')
                self.assertFalse(metadata_audit.same_expanded_name(source,wrong))
                renamed = dict(fact['linked_concepts'][0],qname='control:DeliberatelyWrongConcept')
                self.assertFalse(metadata_audit.same_expanded_name(source,renamed))

    def test_metadata_types_and_versions_come_from_source_schemas(self):
        trees = {}
        for result in self.results.values():
            for row in result['elements']:
                path = row['schema_path']
                if path not in trees:
                    trees[path] = etree.parse(path)
                root = trees[path].getroot()
                self.assertEqual(root.get('targetNamespace'),row['namespace'])
                candidates = [e for e in root.findall('{http://www.w3.org/2001/XMLSchema}element') if e.get('name')==row['local_name']]
                self.assertEqual(len(candidates),1)
                self.assertEqual(dict(candidates[0].attrib),row['schema_attributes'])

    def test_missing_definitions_are_really_missing_from_raw_resources(self):
        ns = {'link':'http://www.xbrl.org/2003/linkbase'}
        xl = '{http://www.w3.org/1999/xlink}'
        for result in self.results.values():
            trees = {s['url']:etree.parse(s['path']) for s in result['source_manifest']}
            schema_elements = {url:{n.get('id'):n for n in tree.getroot().findall('{http://www.w3.org/2001/XMLSchema}element')} for url,tree in trees.items()}
            available = set()
            for url, tree in trees.items():
                for link in tree.findall('.//link:labelLink',ns):
                    resources = {n.get(xl+'label') for n in link.findall('link:label',ns) if n.get(xl+'role')=='http://www.xbrl.org/2003/role/documentation'}
                    locs = {n.get(xl+'label'):urldefrag(urljoin(url,n.get(xl+'href'))) for n in link.findall('link:loc',ns)}
                    for arc in link.findall('link:labelArc',ns):
                        if arc.get(xl+'to') in resources and arc.get('use')!='prohibited':
                            schema_url, fragment = locs[arc.get(xl+'from')]
                            schema = trees[schema_url].getroot()
                            element = schema_elements[schema_url].get(fragment)
                            self.assertIsNotNone(element)
                            available.add('{'+schema.get('targetNamespace')+'}'+element.get('name'))
            for row in result['elements']:
                self.assertEqual(bool(row['documentation']),row['key'] in available,row['key'])

if __name__=='__main__':
    unittest.main(verbosity=2)
