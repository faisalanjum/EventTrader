# Quarterly filing test, 27 November 2026

Autodesk, Tyler Technologies, Nasdaq and Atlassian, 50 existing driver names each. Source text includes filing exhibits. Each issuer folder holds the original passage text and source locations, driver names, frozen questions and expected details, hosted responses and usage, the passages returned by each method, and the sampled passages and their grades. See protocol.txt for the cutoffs and selection rules.

To replay offline, unzip this archive and run `python3 verify.py /path/to/this.zip`. The check rebuilds the 600 packets from the saved responses and source links, then verifies scores, filing shares, sampled passages and fees. No credentials or model calls are needed.

reference-seal.json records the inputs and labels fixed before inference. equivalent-locations.json credits additional filing passages supporting the same claims, consistently for all methods. Ovintiv is a separate replay of an earlier known miss. Its source excerpts, screen probability and resulting passage IDs are in ovv.json. The four deeper driver reviews used searches of the full source and examination of candidate passages. No review establishes exhaustive recall. Times in routing.json cover both paid routes run as one comparison.
