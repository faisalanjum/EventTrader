from look import *
# Only alternative source locations or exact arithmetic for previously frozen claims.
# Keys are driver/zero-based check index. Frozen results stay in grades.json.
alts={}
def add(c,gold,j,where,alternatives,why):
 facts=(json.loads((w/c/'gold.json').read_text())[str(j)]['checks'] if gold=='regular' else json.loads((w/c/'deep.json').read_text())['checks'])
 alts.setdefault(c,[]).append({'list':gold,'driver':j,'check':where,'meaning':facts[where]['meaning'],'more_options':alternatives,'reason':why})
for j in [8,9,24,42,43,47]:
 add('TYL','regular',j,1,[[128]],'Note 5 independently states subscriptions and maintenance are recurring.')
for j in [33,34,49]:
 add('TYL','regular',j,0,[[279,a,b] for a in (111,122) for b in (112,123)],'The separate transfer-timing tables print exactly the same current and prior fee amounts. Each requires the separately returned annualization rule.')
for j in [33,34]:
 add('TYL','regular',j,1,[[i,299] for i in (275,281)],'The new/existing-client growth statement and the separate explicit on-premises conversion explanation together support the same claim.')
for j in [43,44]:
 add('NDAQ','regular',j,1,[[574]],'Quarterly other-revenue discussion explicitly names the Nordic power business and transfer.')
for j in [8,9]:
 add('NDAQ','regular',j,1,[[450,574]],'Corporate divested-business reconciliation plus the Other revenue discussion.')
add('ADSK','deep',9,4,[[50,372]],'The balance sheet gives current and long-term deferred revenue, which together subtract from exact total RPO to yield $3.515bn.')
add('TEAM','deep',28,6,[[39]],'Current and non-current deferred revenues on the balance sheet add to the closing balance.')
(w/'equivalent-locations.json').write_text(json.dumps(alts,indent=1))
