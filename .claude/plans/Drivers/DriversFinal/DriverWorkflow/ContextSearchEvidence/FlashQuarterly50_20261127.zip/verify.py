"""Offline verification. Run python3 verify.py PATH_TO_ARCHIVE. No API access."""
import collections,gzip,hashlib,json,math,statistics,sys,zipfile
def replay(read,has):
 from rebuild import check_packets,check_spots
 signs=read('reference-seal.json')
 for k,v in signs.items():assert has(k,v),k
 eq=read('equivalent-locations.json'); out={};total_cost=collections.Counter()
 for c in ('ADSK','TYL','NDAQ','TEAM'):
  f=lambda k:read(f'{c}/'+k)
  names=f('names.json');gold=f('gold.json');de=f('deep.json')
  original=f('grades.json');paks=f('packets.json.gz');p=f('source.json.gz')['pieces'];uset=f('usage.json.gz');route=f('routing.json');keys=f('cost-keys.json')
  check_packets(f,names,f('source.json.gz'),paks,route,uset)
  den=sum(len(v['text']) for v in p.values()); charges={k:v[1]*(1e-8 if v[0]=='pplx-decider-flash-v1.3' else 2e-8) for k,v in uset.items()}
  assert all(v[0] in ('pplx-decider-flash-v1.3','pplx-decider-v1.3') for v in uset.values())
  costs={a:sum(charges[k] for k in sorted(set(ks))) for a,ks in keys.items()};assert math.isclose(sum(charges.values()),route['actual_new_usd'])
  for a,b in [('full','full_usd'),('flash','flash_usd'),('routed_full','routed_full_usd')]:assert math.isclose(costs[a],route[b])
  assert len(gold)==len(set(names))==len(names)==50 and names==[g['driver'] for g in gold.values()]
  byarm={}; spots=f('spot-grades.json');spots_by=f('spot-arms.json')
  for a in ('full','flash_full','flash_groups'):
   totals=collections.Counter(); observed=[];ss=[];allhit=[];df=[]
   num_positive=sum(not x['unverified_value'] for x in gold.values());ungraded=sum(not x['checks'] for x in gold.values())
   for j,name in enumerate(names,1):
    g=gold[str(j)];ids=set(paks[a][name]);assert len(ids)==len(paks[a][name]) and ids<=set(map(int,p))
    pct=sum(len(p[str(i)]['text']) for i in ids)*100/den;ss.append(pct)
    res=[]
    def hits(checks,key):
     arr=[]
     for i,xx in enumerate(checks):
      loc=xx['options']; rigid=any(set(opt)<=ids for opt in loc)
      expected=(original[a]['driver'][j-1]['checks'] if key=='regular' else original[a]['deep'])[i]
      assert rigid==expected
      for rr in eq.get(c,[]):
       if (rr['driver'],rr['check'],rr['list'])==(j,i,key):
        assert rr['meaning']==xx['meaning'];loc=loc+rr['more_options']
      graded=any(set(opt)<=ids for opt in loc);arr.append(graded)
      if key=='regular':totals[xx['kind']]+=graded
      observed.append([key,j,i,xx['kind'],graded])
     return arr
    res=hits(g['checks'],'regular')
    if res:allhit.append(all(res))
    if j==de['driver']:df=hits(de['checks'],'deep')
   assert math.isclose(statistics.median(ss),original[a]['median_share'])
   assert len(spots_by[a])==len(set(spots_by[a]))==12
   check_spots(c,a,paks,p,f('spot.json'),spots_by[a])
   precision=collections.Counter(spots[i]['grade'] for i in spots_by[a])
   byarm[a]={'numbers':totals['number/inputs'],'numbers_total':num_positive,
    'context':totals['interpretation'],'context_total':sum(sum(q['kind']=='interpretation' for q in v['checks']) for v in gold.values()),
    'deep':sum(df),'deep_total':len(df),'deep_core':sum(hit for hit,q in zip(df,de['checks']) if q['kind']=='core'),
    'deep_core_total':sum(q['kind']=='core' for q in de['checks']),
    'all_scored_checks':sum(allhit),'drivers_scored':len(allhit),'no_numeric_reference':50-num_positive,'no_positive_reference':ungraded,'median_share':statistics.median(ss),'driver_pct':ss,'spot':dict(precision),'outcomes':observed,
    'known_distraction_included':original[a]['distractor']}
  ec={'full':costs['full'],'flash_full':costs['flash']+costs['routed_full'],'flash_groups':costs['flash'],'actual':sum(charges.values())}
  total_cost.update(ec);out[c]={'costs':ec,'arms':byarm,'seconds_for_both_scans':route['wall_seconds_compare_including_archive'],'identical_after_flash':sum(paks['full'][n]==paks['flash_full'][n] for n in names)}
 ov=read('ovv.json');assert ov['by_arm']['full']['final_134'] and not ov['by_arm']['flash_full']['final_134'] and not ov['by_arm']['flash_groups']['final_134']
 return {'companies':out,'cost_usd':dict(total_cost)}
if __name__=='__main__':
 sys.path.insert(0,sys.argv[1])
 with zipfile.ZipFile(sys.argv[1]) as z:
  def obj(k):
   data=z.read(k);return json.loads(gzip.decompress(data) if k.endswith('.gz') else data)
  r=replay(obj,lambda k,v:hashlib.sha256(z.read(k)).hexdigest()==v)
  assert r==obj('summary.json')
  print('Verified 600 packets from hosted responses, frozen and adjudicated scores, filing shares, costs, sampled passages and the saved Ovintiv result. Actual USD %.6f'%r['cost_usd']['actual'])
