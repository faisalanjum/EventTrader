"""Rebuild the selection for every driver from hosted responses."""
import hashlib
import json
import re
from expand import material


def key(value):
    data = json.dumps(value, ensure_ascii=False, separators=(',', ':'), sort_keys=True)
    return hashlib.sha256(data.encode()).hexdigest()


def check_packets(read, names, source, packets, route, usage):
    original = source['pieces']
    edges = source['source_structure']['edges']
    selections = {arm: {name: set() for name in names} for arm in packets}
    receipts = read('replies.json.gz')
    assert set(receipts) == set(usage)
    for rid, receipt in receipts.items():
        assert usage[rid] == [receipt['model'], receipt['usage']['input_tokens']]
    for full_key, gate_key, body in read('jobs.json.gz'):
        rows = body['state']['consecutive_originals']
        accepted = {names[int(slot[1:])] for slot, answer in receipts[gate_key]['answers'].items()
                    if answer['noul'] >= 0.01}
        for name in accepted:
            selections['flash_groups'][name].update(map(int, rows))
        questions = {}
        for slot, question in body['questions'].items():
            match = re.search(r'original passage (\d+) contribute to "(.*)"\? Read it', question['instructions'])
            questions[slot] = (int(match[1]), match[2])
        for arm, rid in [('full', full_key), ('flash_full', route['candidate'][full_key])]:
            expected = {slot for slot, (_, name) in questions.items() if arm == 'full' or name in accepted}
            if not expected:
                assert rid is None
                continue
            answers = receipts[rid]['answers']
            assert answers.keys() == expected
            for slot, answer in answers.items():
                pid, name = questions[slot]
                prob = answer['probabilities']
                if prob['direct'] + prob['linked'] >= 1/3:
                    selections[arm][name].add(pid)
    for arm, byname in selections.items():
        for name, initial in byname.items():
            assert sorted(material(original, initial, edges)[1]) == packets[arm][name], (arm, name)


def check_spots(issuer, arm, packets, source, excerpts, ids):
    candidates = sorted((key(['quarter-noise-v1', issuer, name, pid]), name, pid)
                        for name, pids in packets[arm].items() for pid in pids)[:12]
    assert [row[0] for row in candidates] == ids
    for sample, name, pid in candidates:
        assert excerpts[sample] == {'name': name, 'id': pid, 'text': source[str(pid)]['text']}
