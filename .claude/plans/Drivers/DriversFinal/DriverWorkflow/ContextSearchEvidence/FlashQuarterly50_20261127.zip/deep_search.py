from look import *
terms={'TYL':r'backlog|obligation|unfilled|unfulfilled|contracted revenue|contract liabilities|deferred revenue|2[.,]13|\b45\s*%|order book|performance|new contracts|invoice',
'TEAM':r'obligation|deferred revenue|unbilled|backlog|contract liabilit|contracted revenue|2[.,]3\s*billion|2,3[0-9]{2}|\b81\s*%|unearned|sales commitment|booking',
'ADSK':r'\brpo\b|\bcrpo\b|obligation|\bunbilled\b|backlog|commit(ted|ment).*contract|4[.,]83|4[.,]457|6[.,]938|7[.,]36|\b66\s*%|deferred revenue|unearned|\b2[.,]53',
'NDAQ':r'\bipos?\b|initial public offering|first north|listing|equity capital raising|go(ing)? public|nordic|baltic'}
for c,term in terms.items():
 pics=get(c);record=[]
 for k,p in pics.items():
  text=simple(p['text'])
  match=re.search(term,text,flags=re.I)
  record.append([int(k),p['file'],bool(match)])
  if match and (not c=='NDAQ' or (int(k)<750)):
   print(c,k,' '.join(text.split())[max(0,match.start()-50):match.start()+125])
 (w/c/'deep-screen.json').write_text(json.dumps(record))
