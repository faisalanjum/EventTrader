from look import *
# Fixed source-only substantive facts. Supporting items are kept apart from direct measure facts.
deep={
'ADSK':(9,[
 ('core','Current balance $4.83bn at October 31',[[81],[348],[372]]),
 ('core','January balance $4.457bn or stated eight percent FY-end comparison',[[348],[372]]),
 ('core','Recognition is expected within the next twelve months',[[81],[516]]),
 ('core','66% of total RPO is current; remainder $2.53bn or 34%',[[81],[372]]),
 ('core','Total includes the unbilled portion, $7.361bn total and $3.515bn unbilled',[[370]]),
 ('core','Annual contracts replacing multiyear agreements would depress total RPO growth while current RPO stays broadly unchanged',[[373]]),
 ('support','Seasonality from fourth-quarter enterprise agreements',[[373]]),
 ('support','Timing, size, duration, renewals and FX can move RPO',[[82],[373]]),
 ('support','Unbilled committed revenue is excluded from receivables and balance-sheet deferred revenue',[[369],[527]])]),
'TYL':(4,[
 ('core','September 30 backlog $2.13bn',[[141],[276]]),('core','Growth of 9% versus September 2023',[[276]]),
 ('core','Contracted unrecognized revenue includes both deferred revenue and future invoices',[[141]]),
 ('core','45% expected over the next 12 months, rest thereafter',[[141]]),
 ('support','127 extra professional services employees were hired to deliver backlog and anticipated new business',[[317]]),
 ('support','Current deferred balance underlying backlog was $682.422m',[[42],[137],[139]]),
 ('support','Multiyear agreements are generally invoiced at start of each annual coverage period',[[95]])]),
'NDAQ':(16,[
 ('core','Four Nordic/Baltic IPOs versus one a year ago',[[511]]),
 ('core','Counts include companies on First North alternative markets',[[514]]),
 ('core','New listings include IPOs and are distinct: nine new listings versus two',[[511,514]]),
 ('support','First North is the alternative venue for smaller and growth companies',[[34],[171]])]),
'TEAM':(28,[
 ('core','September 30 RPO approximately $2.3bn',[[221]]),
 ('core','Approximately 81% is expected within twelve months; the remainder comes later',[[221]]),
 ('core','Contracted unrecognized revenue includes deferred revenue and unbilled amounts',[[220]]),
 ('core','Renewal timing, delivery, average term and FX influence RPO',[[220]]),
 ('core','Unbilled amount is subject to bankruptcy, regulatory and other economic risks',[[220]]),
 ('support','Cash due or paid before performance, including refundable amounts, is deferred revenue',[[231]]),
 ('support','Underlying closing deferred revenue $2.013bn, separate from the RPO total',[[232]]),
 ('support','61% of revenue recognized came from beginning-of-year deferred revenue, versus 58% a year earlier',[[233]])])}
neg={'ADSK':(9,581),'TYL':(4,160),'NDAQ':(16,484),'TEAM':(28,396)}
for c,(j,ff) in deep.items():
 p=get(c);assert all(str(i) in p for _,_,opts in ff for opt in opts for i in opt)
 (w/c/'deep.json').write_text(json.dumps({'driver':j,'checks':[dict(kind=k,meaning=m,options=opts) for k,m,opts in ff],'known_distraction':neg[c][1]},indent=1))
