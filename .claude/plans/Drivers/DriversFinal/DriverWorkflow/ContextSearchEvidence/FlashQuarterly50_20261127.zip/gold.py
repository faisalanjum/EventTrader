"""Source-only keys. Each option is a sufficient set of original passage IDs. No inference output is read."""
from look import get,w,simple
import json,itertools,re
def run(c):
 p=get(c);names=json.loads((w/c/'names.json').read_text());facts={i:[] for i in range(1,51)}; unresolved={}
 def seq(x):return [x] if isinstance(x,int) else list(x)
 def register(js,kind,meaning,options):
  options=sorted({tuple(sorted(set(a))) for a in options})
  assert options and all(a and all(str(k) in p for k in a) for a in options),(c,meaning,options)
  for j in seq(js): facts[j].append({'kind':kind,'meaning':meaning,'options':options})
 def alt(js,kind,meaning,ids):register(js,kind,meaning,[[i] for i in seq(ids)])
 def link(js,meaning,ids):alt(js,'interpretation',meaning,ids)
 def basis(js,why):
  for j in seq(js):assert j not in unresolved;unresolved[j]=why
 def table(js,meaning,ids,values,den=None):
  # Values and allowed presentations are chosen from the source. A reported share also needs
  # its denominator. Current/prior amounts suffice for testing evidence for a change.
  def hits(ids,vals):
   r=[]
   for i in seq(ids):
    tx=' '.join(simple(p[str(i)]['text']).split())
    if all(re.search(r'(?<![\d,])'+re.escape(v)+r'(?![\d,])',tx) for v in vals):r.append(i)
   assert r,(c,meaning,vals,ids)
   return r
  am=hits(ids,values)
  for j in seq(js):
   share='Common Size' in names[j-1]
   if share and den:
    dm=hits(*den)
    register(j,'number/inputs',meaning+' and corresponding total',itertools.product(am,dm))
   else:alt(j,'number/inputs',meaning,am)
 if c=='ADSK':
  gross=([36,441,447],['1,688','1,423']);rev=([36,79,387,391,394,400,403],['1,853','1,570'])
  for js,meaning,ids,vs in [
   ([1,2],'Americas quarterly revenue $820m versus $705m',[79,394],['820','705']),
   (3,'AECO quarterly revenue $921m versus $751m',[79,391],['921','751']),
   ([4,5,6],'APAC quarterly revenue $318m versus $285m',[79,394],['318','285']),
   ([7,8],'AutoCAD and LT quarterly revenue $458m versus $398m',[79,391],['458','398']),
   ([11,12,13],'Design revenue $1,537m versus $1,295m',[79,403],['1,537','1,295']),
   ([15,16],'EMEA quarterly revenue $715m versus $580m',[79,394],['715','580']),
   ([17,18],'Maintenance revenue $8m versus $9m',[36,387],['8','9']),
   ([19,20],'Make revenue $205m versus $171m',[79,403],['205','171']),
   ([24,25],'Manufacturing revenue $355m versus $307m',[79,391],['355','307']),
   ([26,27],'Media and Entertainment revenue $86m versus $83m',[79,391],['86','83']),
   (31,'Other product family revenue $33m versus $31m',[79,391],['33','31']),
   (37,'Recurring revenue $1,804m versus $1,530m, up 18%',[356],['1,804','1,530']),
   ([38,39],'Subscription revenue $1,734m versus $1,457m',[36,387],['1,734','1,457']),
   (43,'GAAP gross profit $1,688m versus $1,423m',gross[0],gross[1]),
   (46,'Total revenue $1,853m versus $1,570m',rev[0],rev[1]),
   ([47,48],'Geographic totals including Americas, EMEA and APAC, current and prior quarter',[79,394],['820','715','318','705','580','285']),
   ([49,50],'Combined subscriptions and maintenance $1,742m versus $1,466m',[36,387],['1,742','1,466'])]:table(js,meaning,ids,vs,rev)
  alt(9,'number/inputs','Current RPO $4.83bn at October 31, 2025',[81,348,372])
  alt(10,'number/inputs','Current RPO rose 8% from FY-end, or $4.830bn vs $4.457bn; comparator is January, not prior October',[348,372])
  alt(44,'number/inputs','Total RPO $7.36bn at October 31, 2025',[81,347,370,372])
  alt(45,'number/inputs','Total RPO rose 6% from FY-end or $7.361bn vs $6.938bn; January comparator',[347,370,372])
  for js,meaning in [([40,41],'Subscription and maintenance revenue $1,742m and direct cost $118m; developed-tech amortization shown separately')]:
   table(js,meaning,[36],['1,742','118','1,466','105'],gross)
  basis([14,21,22,23],'No verified count or growth of Design/Make subscriptions on this basis. Product revenues or Flex descriptions are not subscription counts.')
  basis([28,29,30,33],'Other gross profit/Other Service Gross Profit allocation is not separately reconciled. The filing has an Other revenue/cost line and a separate amortization line.')
  basis([32,34,35,36],'Several catalogue measures use Other; the filing distinguishes product-family Other ($33m) and type/statement Other ($111m), including services. No verified one-to-one scope.')
  basis(42,'Billings definition found; no verified current-quarter growth figure or complete balance rollforward for both comparative quarters.')
  for js,tx,ids in [([1,5,16],'Reported and constant-currency growth rates differ',394),
   ([3,7,24,26],'Management explains product-family growth',391),([11,12,19,20],'Management identifies drivers of Design and Make revenue',403),
   ([17,18],'Maintenance revenue recognized over the contract term, usually one year',502),
   (37,'Recurring revenue excludes third-party subscriptions; acquisition timing can affect comparison',514),
   ([38,49,50],'Renewals, cloud services and enterprise agreements contributed to growth',387),
   ([40,41],'Hosting and employee costs explain higher subscription and maintenance cost',413),
   (42,'Billings definition is total revenue plus change in deferred revenue',[485]),
   ([28,29,30,33],'Other revenue, its direct cost, and separately recorded amortization are presented',36),
   ([32,34,35,36],'Separate product-family and product-type Other classifications appear together',79),
   ([21,22,23],'Make includes cloud-based product subscriptions and some dual-function products',504),
   (14,'Design combines maintenance, product subscriptions and enterprise agreements',491),
   ([9,10,44,45],'Current RPO is revenue expected in the next twelve months',[81,516]),
   ([9,44],'FX and timing, size, duration and renewals influence RPO',[82,373])]:link(js,tx,ids)
 if c=='TYL':
  rev=([29],['543,337','494,684'])
  def across(js,meaning,now,then,extra=(),den=True):
   a,b=now,then
   for j in seq(js):
    options=[[a,b],*[[v] for v in extra]]
    if 'Common Size' in names[j-1] and den:
     # 111/112 and 130/131 each show segment numbers and the matching consolidated totals.
     opts=[]
     for v in options:
      if set(v) in ({111,112},{130,131}) or v==[29]:opts.append(v)
      else:opts.extend([v+[29],v+[111,112],v+[130,131]])
     options=opts
    register(j,'number/inputs',meaning,options)
  across([5,7],'Quarterly segment operating income/loss, including Corporate losses $66,819k and $61,475k and Enterprise Software $139,874k and $121,560k',111,112)
  across(6,'Corporate total revenue/eliminations -$11,748k vs -$5,984k',111,112)
  across([8,9],'Enterprise recurring $315,352k vs $277,497k',130,131)
  for js,label in [([11,12],'Enterprise Software $390,731k vs $353,755k'),([25,26,27],'Platform Technologies $164,354k vs $146,913k')]:
   for j in js: register(j,'number/inputs',label+' and consolidated totals',[[a,b] for a in (111,130) for b in (112,131)])
  across([19,20],'Consolidated non-recurring $80,580k vs $82,010k',130,131)
  across(24,'Platform Technologies recurring $147,405k vs $135,177k',130,131)
  for js,tx,ids,v in [(14,'Hardware and other $9,930k vs $10,330k',[29],['9,930','10,330']),
    (15,'Maintenance $115,587k vs $117,484k',[29,298],['115,587','117,484']),
    ([28,29,30,31,32],'Professional services including appraisal $64,462k vs $61,126k',[29,302],['64,462','61,126']),
    (39,'Licenses and royalties $6,188k vs $10,554k',[29,308],['6,188','10,554']),
    ([40,41],'Subscriptions $347,170k vs $295,190k',[29],['347,170','295,190']),
    (48,'Consolidated total $543,337k vs $494,684k',[29],rev[1])]:
   for j in seq(js):
    table(j,tx,ids,v,rev)
    old=facts[j][-1]['options'];old.extend([[111,112]]) # both period tables carry total and relevant revenue components
  across(47,'Consolidated recurring $462,757k vs $412,674k and totals',130,131)
  alt(4,'number/inputs','September backlog $2.13bn',[141,276])
  alt([42,43],'number/inputs','Total ARR $1.85bn vs $1.65bn, up 12%',281)
  for j,label,ids in [(33,'quarterly SaaS fees annualization inputs', [294]),(34,'quarterly SaaS fees growth inputs', [294]),(49,'quarterly transaction fee growth inputs',[295])]:
   register(j,'number/inputs',label+' and company annualization method',[[279,k] for k in ids]+[[279,111,112]])
  basis([1,2,3,16,17,18],'Legacy segment not separately disclosed in the two-segment quarterly tables; appraisal services and NIC-related operations must not be equated to a named current segment.')
  basis([10,13],'Filing uses post-reorganization Enterprise Software basis; no bridge to the named historical basis verified.')
  basis([21,22,23],'Other/Other Segment can combine distinct revenue lines; no unambiguous quarter-specific mapping to that catalogue figure verified.')
  basis([35,36,37,38,44,45,46,50],'Subscription mix and new/converted SaaS customer numbers are given, but no verified amount or count for this bookings/contract measure.')
  for js,desc,ids in [([5,7],'Segment profit definition, intercompany treatment and corporate cost allocation',[109,264]),([8,9,24,42,43,47],'Recurring revenue consists of subscriptions and maintenance',279),([28,29,30,31,32],'Professional services includes property appraisal and implementation work',304),(15,'On-premises conversions reduced maintenance; price increases partially offset',299),([40,41],'Subscriptions grew with SaaS shift and transactions',275),([33,34],'New SaaS customers and on-premises conversions drove SaaS growth',294),(49,'Transaction growth, acquisitions, and gross-to-net effects',295)]:link(js,desc,ids)
 if c=='NDAQ':
  net=([133,199,448,492,502],['1,237','1,117']);op=([133,448,492],['547','410'])
  for js,desc,ids,nums,den in [
   ([1,2,3],'Capital Access Platforms $515m vs $479m',[133,448,502,507],['515','479'],net),
   ([4,5],'Capital Access operating income $306m vs $279m',448,['306','279'],op),
   ([6,7],'Capital Markets Technology $254m vs $238m',[199,528],['254','238'],net),
   ([8,9],'Corporate operating loss $130m vs $178m',[448,450],['(130)','(178)'],op),
   ([13,14],'Separate financial crime and regulatory technology revenue inputs: $77m/$64m and $101m/$90m',[199,528],['77','64','101','90'],net),
   (15,'Financial Technology operating income $198m vs $176m',448,['198','176'],op),
   ([16,17],'Nordic/Baltic IPOs: 4 vs 1',511,['4','1'],None),(18,'US IPOs: 63 vs 27',511,['63','27'],None),
   ([26,27],'Market Services operating income $173m vs $133m',448,['173','133'],op),
   ([28,29],'Market Services gross $1,134m vs $794m and net $281m vs $237m; distinguish the bases',[133,448,544],['1,134','794','281','237'],([133,448,502],['2,090','1,674'])),
   (31,'Market Services net $281m vs $237m',[199,448,544],['281','237'],net),
   (32,'Market Services transaction-based expenses $853m vs $557m or the rebate and brokerage components',448,['(853)','(557)'],None),
   (35,'Nordic/Baltic new listings 9 vs 2',511,['9','2'],None),([36,37],'US new listings 170 vs 79',511,['170','79'],None),
   ([38,39],'Nordic/Baltic listed companies 1,160 vs 1,203',511,['1,160','1,203'],None),
   ([40,41],'US listed companies 4,139 vs 4,020',511,['4,139','4,020'],None),
   ([43,44],'Other revenues $9m vs $9m (rounded)',[133,199,448,450,502],['9'],net),
   ([47,48],'Financial Technology revenue $432m vs $392m',[133,448,502,528],['432','392'],net),
   ([49,50],'Consolidated gross revenue $2,090m vs $1,674m and net $1,237m vs $1,117m',[133,448,502],['2,090','1,674','1,237','1,117'],net)]:table(js,desc,ids,nums,den)
  facts[32][-1]['options'].extend([[544],[502],[133]])
  basis([10,11,12,19,20,21,22,23,24,25,30],'Historical division or historical measure basis; no like-for-like reconciliation to the current three reportable segments verified.')
  basis([33,34],'Market technology is one business inside Capital Markets Technology; its standalone quarterly revenue was not established.')
  basis([42,45,46],'The filing reports segment and consolidated operating profit, with other nonoperating items. Standalone vendor EBIT/Other EBIT definition and denominator are unverified.')
  for js,d,ids in [([1,2,3],'Contributions of Data & Listing, Index, and Workflow & Insights',507),([4,5,15,26,27],'Indirect overhead allocation treatment during integration',449),
   ([6,7,33,34],'Capital Markets Technology growth from subscriptions, professional services and Calypso',541),
   ([8,9,43,44],'Corporate includes the Nordic power business proposed for transfer',453),
   ([13,14],'Crime management new sales/pricing and Regulatory Technology AxiomSL/Surveillance growth',[532]), # separate regulatory leg below
   ([16,17,35,38,39],'Nordic/Baltic figures include the First North alternative markets',514),
   ([18,40,41],'Quarterly US counts identify SPACs or listed ETPs',513),
   ([28,29,31,32],'Transaction expenses break into rebates and brokerage, clearance and exchange fees',[133,502,544])]:link(js,d,ids)
  for j in [13,14]:facts[j][-1]['meaning']='Crime management revenue benefited from new sales, pricing, and new clients'
  link([13,14],'Regulatory technology benefited from AxiomSL and Surveillance subscriptions',536)
 if c=='TEAM':
  den=([46,225,229,330,334,340,342],['1,187,781','977,775'])
  for js,desc,ids,ns in [
   ([1,2,3],'Asia Pacific $134,013k vs $110,241k',[225,342],['134,013','110,241']),
   ([4,5],'Cloud $792,306k vs $604,647k',[229,340],['792,306','604,647']),([6,7],'Data Center $335,594k vs $242,943k',[229,340],['335,594','242,943']),
   ([10,11,12],'Marketplace and other $59,881k vs $51,433k',[229,340],['59,881','51,433']),
   ([17,18,19],'Other Americas $78,272k vs $63,337k',225,['78,272','63,337']),([20,21,22],'Other EMEA $351,467k vs $286,880k',225,['351,467','286,880']),
   ([30,31],'Server $0 vs $78,752k',[229,340],['78,752','—']),
   ([32,33,34],'Subscription $1,131,948k vs $851,982k',[46,330,334],['1,131,948','851,982']),
   ([35,36],'Total Americas $584,499k vs $489,528k',[225,342],['584,499','489,528']),
   ([37,38],'Total EMEA $469,269k vs $378,006k',[225,342],['469,269','378,006']),
   ([39,40,41],'Total reported other revenue $55,833k vs $125,793k',[46,330,334],['55,833','125,793']),
   (42,'Total revenue $1,187,781k vs $977,775k',den[0],den[1]),
   ([43,44,45],'Geography totals for Americas, EMEA and APAC plus total revenue',[225,342],['584,499','469,269','134,013','1,187,781']),
   ([48,49,50],'US $506,227k vs $426,191k',225,['506,227','426,191'])]:table(js,desc,ids,ns,den)
  alt(13,'number/inputs','More than 300,000 customers at September 30, 2024; lower bound, not an exact count',288)
  alt([15,16],'number/inputs','Customers over $10k Cloud ARR 46,844 vs 40,103',290)
  alt(28,'number/inputs','Remaining performance obligations approximately $2.3bn at quarter end',221)
  basis([8,9],'Maintenance is immaterial after Server end of support and reclassified in Other in all periods. The quarterly decline is disclosed; exact standalone current revenue and comparable percentage are unverified.')
  basis(14,'Only a lower bound for customer count is disclosed here; no exact prior-period comparison verified.')
  basis([23,24,25,26,27],'Other has multiple possible revenue lines or geographic residuals; the bare driver name does not establish the intended numerator. No equivalent assumed.')
  basis(29,'Current RPO is given, but no verified matching year-ago RPO or percentage change in this document.')
  basis([46,47],'The geography table discloses Germany and Other EMEA; a standalone UK amount or change was not verified.')
  for js,tx,ids in [([1,2,3,17,18,19,20,21,22,35,36,37,38,43,44,45,48,49,50],'Geography assigned to end-users purchasing the product or service',223),
    ([4,5,6,7,10,11,12],'Cloud and Data Center deployment and Marketplace/premier-support presentation',226),
    ([8,9,30,31,39,40,41],'Server maintenance generally ended February 2024 and is in Other revenues',[227,304]),
    ([8,9],'Maintenance revenue fell $75.5m with Server end of support',337),
    ([13,14,15,16],'Unique domains with active subscription for two or more seats; $10k cohort uses annualized Cloud MRR',285),
    ([15,16],'December 2023 comparator includes 326 additional customers from Loom',291),
    ([28,29],'Amount and expected recognition of approximately 81% within twelve months',221),
    ([32,33,34],'Seat expansion, migrations and price increases drove subscription growth',336),
    ([39,40,41],'Other declined mainly due to Server maintenance ending',337)]:link(js,tx,ids)
 for j in names and range(1,51):
  if not any(x['kind']=='number/inputs' for x in facts[j]):assert j in unresolved,(c,j)
  assert not (j in unresolved and any(x['kind']=='number/inputs' for x in facts[j]))
 out={str(j):{'driver':names[j-1],'checks':facts[j],'unverified_value':unresolved.get(j)} for j in facts}
 (w/c/'gold.json').write_text(json.dumps(out,indent=1))
if __name__=='__main__':
 for c in ('ADSK','TYL','NDAQ','TEAM'):run(c)
