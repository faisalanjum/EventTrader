from pathlib import Path
import json,gzip,csv,hashlib,re,sys
w=Path(__file__).parent
repo=Path('/home/faisal/EventMarketDB')
accs={'ADSK':'0000769397-25-000129','TYL':'0000860731-24-000052','NDAQ':'0001120193-25-000012','TEAM':'0001650372-24-000056'}
sys.path.insert(0,'/tmp/driver_flash_vs_full_10x20_20261127')
import prepare_trial as pt
from structure import prepared_edges
def one(c,acc):
 path=Path('/tmp/driver_price_sources_20261127')/('10-Q_'+acc);d=w/c;d.mkdir(exist_ok=True)
 rows={r['metric_name'].strip():r for r in csv.DictReader((repo/'data/fiscal_ai_segments/runs/2026-07-10/kpi_catalog/kpi_catalog.csv').open()) if r['symbol']==c and r['is_kpi']=='1' and r['metric_name'].strip()}
 names=sorted(sorted(rows,key=lambda n:pt.key(['quarterly-50-20261127',c,n]))[:50]); assert len(names)==50
 ix=pt.read(path/'index.json');ix['source_structure']=prepared_edges(ix,path/'job')
 sub=pt.read(path/'subject.json'); mf,mem=pt.inputs.prepare.open_package(sub['version']);assert ix['package_sha256']==mf['package']['sha256']
 for p in ix['pieces'].values():
  a,b=p['bytes'];assert hashlib.sha256(mem[p['file']][a:b]).hexdigest()==p['sha256_bytes']
 pt.save(d/'source.json.gz',ix);pt.save(d/'names.json',names)
 (d/'names.txt').write_text('\n'.join(f'{i:02d} {n}' for i,n in enumerate(names,1)))
 with (d/'tables.txt').open('w') as ft,(d/'lines.txt').open('w') as fl,(d/'tableindex.txt').open('w') as fi:
  for k,p in ix['pieces'].items():
   s=' '.join(p['text'].split());print(k,s,file=fl)
   if p['kind']=='table' or re.match(r'^r\d+: \[',s):
    print(k,p['text'],file=ft); print(k,s[:260]+ ' '+' | '.join(re.findall(r'r\d+: \[c0(?:[-:]\d+)?\] (.+?)(?= · |\n|$)',p['text'])[:22]),file=fi)
 jobs,_=pt.make_jobs(ix['pieces'],names);scr={};js=[]
 for _,_,b in jobs:
  q={'model':'pplx-decider-flash-v1.3','state':b['state'],'questions':{f'd{i}':{'type':'noul','instructions':f'Does any part of the supplied text contain or help interpret evidence about "{n}"? Count relevant headings, definitions, components and qualifications.'} for i,n in enumerate(names)}}
  g=pt.key(q);scr[g]=q;js.append([pt.key(b),g,b])
 pt.save(d/'jobs.json.gz',js);pt.save(d/'screens.json.gz',scr);(d/'receipts').mkdir(exist_ok=True)
 print(c,len(names),len(ix['pieces']),len(js),len(scr),flush=True)
if __name__=='__main__':
 for c,a in accs.items():one(c,a)
