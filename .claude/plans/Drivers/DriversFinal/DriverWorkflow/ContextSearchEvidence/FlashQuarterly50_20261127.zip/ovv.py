from setup import *
from compare import neighbors,ids_from_reply
from collections import defaultdict
arch=Path('/tmp/decider-runpod-pilot-mOKKLZ/pooled');v=arch/'validation';same=arch/'same_hosted'
manifest=pt.read(v/'manifest.json');orig=pt.read(v/'originals.json.gz');qs=pt.read(v/'requests.json.gz');doc=manifest['docs']['OVV']; n='Canada Revenue Common Size';di=doc['names'].index(n)
src=Path('/tmp/driver_price_sources_20261127')/(doc['source_type']+'_'+doc['accession']);ix=pt.read(src/'index.json');pcs=ix['pieces'];ed=prepared_edges(ix,src/'job')['edges']
raw=defaultdict(set);exp=[];alls=set()
for k,g in manifest['jobs'].items():
 if g['sym']!='OVV':continue
 b=orig[k];h=g['gate'];ss=pt.read(same/'screen'/(h+'.json'))
 assert ss['model']=='pplx-decider-flash-v1.3' and ss['answers'].keys()==qs[h]['questions'].keys()
 score=ss['answers'][f'd{di}']['noul'];pp=set(map(int,b['state']['consecutive_originals']))
 al=pt.read(v/'full'/(k+'.json'));assert al['answers'].keys()==b['questions'].keys()
 allsel=ids_from_reply(al,b);raw['full'].update(allsel[n]);alls|=pp
 if score>=.01:
  raw['flash_groups']|=pp
  rep=pt.read(same/'recheck'/(k+'.json'));raw['flash_full'].update(ids_from_reply(rep,b)[n])
 if 134 in pp:exp.append([k,score,134 in allsel[n]])
assert alls==set(map(int,pcs))
wh={a:sorted(neighbors(pcs,ss,ed)[1]) for a,ss in raw.items()}
tot={k:[int(i) for i,r in pcs.items() if all(t in r['text'] for t in terms)] for k,terms in {'segment_product_and_service_totals':['693','782','2,592','3,407'],'Canada_NGLs_2023_2022':['237','362'],'Canada_gas_2023_2022':['455','419']}.items()}
final={a:{'selected_134':134 in raw[a],'final_134':134 in ids,'product_sales_and_intercompany_policy':136 in ids,'candidate_equivalent_hits':{k:sorted(set(l)&set(ids)) for k,l in tot.items()}} for a,ids in wh.items()}
pt.save(w/'ovv.json',{'accession':doc['accession'],'driver':n,'threshold':1/3,'screen_info':exp,'all_source_matches':tot,'by_arm':final,'source_passages':{str(i):pcs[str(i)]['text'] for i in {134,136,*sum(tot.values(),[]) }},'packets':wh,'new_cost':0})
print(final,'screen',exp)
