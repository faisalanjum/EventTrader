def material(pieces, ids, edges):
    def related(seeds):
        found, pending = set(seeds), list(seeds)
        while pending:
            n = pending.pop()
            extra = set(pieces[str(n)]["companions"]).union(edges.get(str(n), ())) - found
            found.update(extra)
            pending.extend(extra)
        return found

    proven = related(ids)
    # Plain prose at a table boundary may carry its scale. Keep it as possible context.
    # Do this once so neighboring tables cannot recursively collect an entire document.
    adjacent = {j for n in proven if pieces[str(n)]["kind"] == "table" for j in (n - 1, n + 1)
                if str(j) in pieces and pieces[str(j)]["file"] == pieces[str(n)]["file"]}
    return proven, proven | related(adjacent)
