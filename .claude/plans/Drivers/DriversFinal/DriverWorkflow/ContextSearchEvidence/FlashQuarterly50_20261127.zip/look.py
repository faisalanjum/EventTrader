from pathlib import Path
import json,sys,re,gzip
w=Path(__file__).parent
def get(c):return json.load(gzip.open(w/c/'source.json.gz'))['pieces']
def simple(s):
 return re.sub(r'r\d+:|\[c\d+[^\]]*\]|\[link [^\]]*\]','',s).replace(' · ',' ').replace('$','').replace('  ',' ').strip()
if __name__=='__main__':
 c=sys.argv[1];p=get(c)
 for arg in sys.argv[2:]:
  for a in arg.split(','):
   rb=a.split('-'); rr=range(int(rb[0]),int(rb[-1])+1)
   for i in rr:print(i, ' / '.join(' '.join(simple(x).split()) for x in p[str(i)]['text'].splitlines() if x.strip()))
