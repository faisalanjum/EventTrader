from setup import *
from compare import ids_from_reply,neighbors
from collections import defaultdict,Counter
import statistics,time
arms=('full','flash_full','flash_groups')
def collect(c):
 d=w/c;ix=pt.read(d/'source.json.gz');pcs=ix['pieces']; names=pt.read(d/'names.json')
 jobs=pt.read(d/'jobs.json.gz');rr=pt.read(d/'routing.json'); source_ids={int(i) for i in pcs}
 chosen={a:defaultdict(set) for a in arms}; question_counts=Counter();charges={};dollar=0
 for h,g,b in jobs:
  gate=pt.read(d/'receipts'/(g+'.json'));assert gate['model']=='pplx-decider-flash-v1.3' and len(gate['answers'])==len(names)
  ss={names[int(i[1:])] for i,v in gate['answers'].items() if v['noul']>=.01}
  pp=set(map(int,b['state']['consecutive_originals'])); assert pp<=source_ids
  for n in ss:chosen['flash_groups'][n].update(pp)
  for a,rid in [('full',h),('flash_full',rr['candidate'][h])]:
   qs={k:v for k,v in b['questions'].items() if a=='full' or re.search(r'contribute to "(.*)"\? Read it',v['instructions'])[1] in ss}
   if not qs:assert rid is None;continue
   r=pt.read(d/'receipts'/(rid+'.json')); assert r['model']=='pplx-decider-v1.3' and r['answers'].keys()==qs.keys()
   if a=='full':
    for v in qs.values():
     n=re.search(r'contribute to "(.*)"\? Read it',v['instructions'])[1];question_counts[n]+=1
   for n,ids in ids_from_reply(r,b).items():chosen[a][n].update(ids)
 for n in names:assert question_counts[n]==len(pcs),(c,n,question_counts[n],len(pcs))
 for f in (d/'receipts').glob('*.json'):
  v=pt.read(f);charges[f.stem]=(v['model'],v['usage']['input_tokens']);dollar+=charges[f.stem][1]*(1e-8 if 'flash' in v['model'] else 2e-8)
 assert abs(dollar-rr['actual_new_usd'])<1e-8
 whole={a:{n:sorted(neighbors(pcs,chosen[a][n],ix['source_structure']['edges'])[1]) for n in names} for a in arms}
 pt.save(d/'usage.json.gz',charges);pt.save(d/'packets.json.gz',whole)
def evaluate(c):
 d=w/c;p=pt.read(d/'source.json.gz')['pieces'];n=pt.read(d/'names.json');gold=pt.read(d/'gold.json');deep=pt.read(d/'deep.json');pap=pt.read(d/'packets.json.gz')
 den=sum(len(v['text']) for v in p.values());all_entries={}; excerpts={};precision={}
 for a in arms:
  k=Counter();per=[];audit=[];sm=[];pairs=[]
  for j,name in enumerate(n,1):
   ids=set(pap[a][name]);g=gold[str(j)];assert g['driver']==name
   results=[]
   for fact in g['checks']:
    hit=any(set(op)<=ids for op in fact['options']);results.append(hit);k[(fact['kind'],hit)]+=1
   if g['checks']:k[('all checks per scored driver',all(results))]+=1
   amt=sum(len(p[str(i)]['text']) for i in ids);share=amt/den*100;sm.append(share)
   per.append({'driver':name,'checks':results,'pct':share})
   if j==deep['driver']:
    audit=[any(set(o)<=ids for o in f['options']) for f in deep['checks']];neg=deep['known_distraction'] in ids
   pairs.extend((pt.key(['quarter-noise-v1',c,name,i]),j,i) for i in ids)
  for h,j,i in sorted(pairs)[:12]:
   name=n[j-1];excerpts[h]={'name':name,'id':i,'text':p[str(i)]['text']};precision.setdefault(a,[]).append(h)
  all_entries[a]={'stats':{f'{t}/{h}':v for (t,h),v in sorted(k.items())},'median_share':statistics.median(sm),'driver':per,'deep':audit,'distractor':neg}
 scores=all_entries
 pt.save(d/'grades.json',scores);pt.save(d/'spot.json',excerpts);pt.save(d/'spot-arms.json',precision)
 for a,v in scores.items():print(c,a,v['stats'],round(v['median_share'],2),'deep',sum(v['deep']),len(v['deep']),flush=True)
if __name__=='__main__':
 for c in sys.argv[1:] or accs:
  if (w/c/'routing.json').exists():collect(c);evaluate(c)
