import json
import os
import sys
import uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

run = Path(os.environ["PROBE_RUN"])
sys.path.insert(0, os.environ["IBP_CONTEXT_ARCHIVE"])
import probe

model = "claude-sonnet-5-5"
settings = dict(model=model, effort=os.environ["IBP_CONTEXT_EFFORT"], system=(run / "shared-prompt.txt").read_text())
base = probe.call("base", (run / "base-input.jsonl").read_text(), session_id=str(uuid.uuid4()),
                  flags=("--input-format", "stream-json"), **settings)
events = [json.loads(line) for line in (run / "calls/base.jsonl").read_text().splitlines() if line.strip()]
assert base["exit"] == 0 and not base["is_error"] and base["subtype"] == "success" and base["num_turns"] == 1
assert base["model"] == model and base["result"].strip() == "READY" and base["apiKeySource"] == "none"
assert all(step["model"] == model for step in base["steps"]) and "True" not in base["overage"]
assert not any("compact" in str(e.get("subtype", "")).lower() or e.get("safety_stops") for e in events)
assert any(e.get("type") == "result" and e.get("stop_reason") == "end_turn" for e in events)
def read(job):
    label, numbers = job
    work = "WORK\n" + " ".join(map(str, numbers))
    return probe.call(label, work, resume=base["session_id"], fork=True, **settings)

with ThreadPoolExecutor(max_workers=2) as pool:
    list(pool.map(read, json.loads((run / "assignments.json").read_text()).items()))
