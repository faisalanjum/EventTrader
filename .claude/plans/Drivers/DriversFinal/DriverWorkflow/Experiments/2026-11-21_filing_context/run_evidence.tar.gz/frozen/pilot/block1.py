import base64
import gzip
import hashlib
import json
import os
import sys
from collections import defaultdict
from operator import itemgetter
from pathlib import Path
from driver.prepare.reconstruct import _first_byte

run = Path(os.environ["PROBE_RUN"])
archive = Path(os.environ["IBP_CONTEXT_ARCHIVE"])
sys.path.insert(0, str(archive / "real10k_tools"))
import real

def extent(start, size):
    return str(start) if size == 1 else f"{start}-{start + size - 1}"

def annotated(text, marks):
    return text + " [" + " | ".join(dict.fromkeys(marks)) + "]" if marks else text

def table_text(unit, markings):
    rows = defaultdict(list)
    for cell in sorted(unit["cells"], key=itemgetter("r", "c")):
        at = _first_byte(cell)
        marks = markings.get((unit["id"], at)) if at is not None else None
        text = annotated(cell["text"], marks)
        if text.strip():
            col = "c" + extent(cell["c"], cell["cs"])
            if cell["rs"] > 1:
                col += ",r" + extent(cell["r"], cell["rs"])
            rows[cell["r"]].append(f"[{col}] {text}")
    return "\n".join(f"r{r}: " + " · ".join(cells) for r, cells in rows.items())

version = "aabf3ebf23d699a42a7f979ce1e7a2f5d4e9f31a37068760a382de31823a6733"
package = archive / "real10k/package/versions/0001580905-26-000004" / version
members = {m["filename"]: m for m in json.loads((package / "manifest.json").read_bytes())["members"]}
with gzip.open(package / "submission.txt.gz") as submission:
    assert hashlib.sha256(submission.read()).hexdigest() == version
metadata = {"company": "Installed Building Products, Inc.", "form": "10-K", "filed": "2026-02-26", "version": version}
files = json.loads((real.JOB / "RESULT.json").read_bytes())["rows"]
pieces, content = {}, []
lines = ["LOAD", " | ".join(metadata[k] for k in ("company", "form", "filed"))]
for file in files:
    name = file["file_id"]
    doc = real.route(file["ordinal"])
    assert file["outcome"] == "verified_saved_output" and doc["status"] == "OK"
    assert doc["file_id"] == name and doc["sha256"] == members[name]["sha256"]
    first = len(pieces) + 1
    paragraphs = defaultdict(list)
    for number, unit in enumerate(doc["units"], first):
        if "paragraph" in unit:
            paragraphs[unit["paragraph"]].append(number)
    markings = defaultdict(list)
    for symbol in doc["source_symbols"]["records"]:
        if symbol.get("status") == "decoded":
            for owner in symbol["owners"]:
                markings[owner["unit"], owner.get("cell")].append(f"{symbol['raw']} → {symbol['unicode']['name']}")
    for link in doc["source_links"]:
        for owner in link["owners"]:
            markings[owner["unit"], owner.get("cell")].append("link " + link["href"])
    lines.append("FILE " + name)
    for number, unit in enumerate(doc["units"], first):
        kind = unit["kind"]
        if kind == "table":
            body = table_text(unit, markings)
        elif kind == "image":
            body = "Image " + unit["src"] + " · " + (unit.get("alt") or "")
        else:
            assert kind in ("text", "heading"), kind
            body = unit["text"]
        body = annotated(body, markings.get((unit["id"], None)))
        location = unit["anchor"]
        piece = {"file": name, "unit": unit["id"], "bytes": [location["byte_start"], location["byte_end_exclusive"]], "body": body}
        pieces[number] = piece
        lines.append(f"PIECE {number}")
        if "paragraph" in unit:
            piece["paragraph"] = paragraphs[unit["paragraph"]]
            lines.append("SAME PARAGRAPH " + " ".join(map(str, piece["paragraph"])))
        lines.extend((body, ""))
        if kind == "image":
            image = archive / "real10k_pic" / unit["src"]
            data = image.read_bytes()
            assert hashlib.sha256(data).hexdigest() == members[image.name]["sha256"] == unit["input"]["input_sha256"]
            piece["image"] = str(image)
            content.append({"type": "text", "text": "\n".join(lines)})
            content.append({"type": "image", "source": {"type": "base64", "media_type": "image/jpeg", "data": base64.b64encode(data).decode("ascii")}})
            lines = []
content.append({"type": "text", "text": "\n".join(lines)})
assert len(files) == 7 and len(pieces) == 1350 and sum("image" in p for p in pieces.values()) == 1
a = [7, 504, 511, 518, 547, 655, 660, 724, 730, 1009, 1018, 1291]
b = [6, 188, 510, 512, 516, 548, 570, 652, 1010, 1011, 1019, 1267]
assignments = {"A1": a, "A2": a, "B": b}
(run / "index.json").write_text(json.dumps({"metadata": metadata, "pieces": pieces}, ensure_ascii=False))
(run / "assignments.json").write_text(json.dumps(assignments))
message = {"type": "user", "message": {"role": "user", "content": content}}
(run / "base-input.jsonl").write_text(json.dumps(message, ensure_ascii=False) + "\n")
(run / "shared-prompt.txt").write_bytes((Path(os.environ["IBP_CONTEXT_PLAN"]) / "step1_prompt.txt").read_bytes())
print(run, len(pieces), "pieces,", sum(len(c.get("text", "")) for c in content), "text characters, plus the image and prompt")
