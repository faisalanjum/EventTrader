# ON Semiconductor 10-Q — independent reading of the revised groups

The header identifies ON Semiconductor Corp., Form 10-Q, filed May 1, 2023. Each entry uses only the pieces printed in that group. Brackets give the file's printed byte bounds.

## 95

At March 31, 2023, ON estimated $17.6 billion of remaining performance obligations, excluding contracts originally lasting one year or less. It expected to recognize about 33% as revenue in the next twelve months upon shipment, roughly $5.8 billion by multiplication. Negotiated prices and volumes, product mix and new-part timing can increase the amount. Manufacturing or supply constraints, contract changes and regulatory changes can affect actual revenue. The packet does not name a particular supply-agreement program or give a customer or product breakdown. All of this is in 95 alone (`on-20230331.htm`, u94 [694097, 697039]).

## 116

Piece 115 supplies the measure and scale missing from 116, **net property, plant and equipment by geographic location, in $ millions**. March 31, 2023 / December 31, 2022 balances are U.S. 1,360.8 / 1,329.2, South Korea 990.9 / 871.0, Czech Republic 335.3 / 279.3, Philippines 287.1 / 296.8, China 227.4 / 215.3, Malaysia 199.0 / 190.2, Japan 128.1 / 133.2, Other 164.3 / 135.7, and total 3,692.9 / 3,450.7. The group does not identify the places in Other or explain changes. Both pieces are in `on-20230331.htm`, 115 u114 [837571, 837669] and 116 t115 [838435, 858910].

## 156

For quarters ended March 31, 2023 / April 1, 2022, service cost was 1.2 / 2.2, interest cost 1.6 / 1.1, and the expected return on plan assets reduced cost by 1.2 in both periods. These amounts add to net periodic pension cost of 1.6 / 2.1. Piece 155 establishes $ millions. The group does not give the plans covered, discount or return assumptions, or actual returns. Both pieces are in `on-20230331.htm`, 155 u154 [956441, 956522] and 156 t155 [957456, 969561].

## 172

These are balances at March 31, 2023 / December 31, 2022 / April 1, 2022 / December 31, 2021. Cash and equivalents were 2,702.4 / 2,919.0 / 1,645.1 / 1,352.6. Restricted cash in other current assets was 14.2 / 14.0 / 18.8 / 20.1 and in other non-current assets — / — / 5.0 / 5.0. They reconcile to cash, cash equivalents and restricted cash on the cash flow statements of 2,716.6 / 2,933.0 / 1,668.9 / 1,377.7. Piece 171 supplies $ millions and confirms the reconciliation. The reasons for the restrictions are absent. Both pieces are in `on-20230331.htm`, 171 u170 [1036324, 1036449] and 172 t171 [1037653, 1058910].

## 259

ON or its subsidiaries initiate guarantees or standby letters of credit in the ordinary course for purchases, collection risks, leases, utilities, customs and other transactions. At March 31, 2023, the revolving facility included $15.0 million available for issuing letters of credit. Its $0.9 million in outstanding letters reduced borrowing capacity. A further $16.5 million outside the facility covered both guarantees and letters of credit. The text does not split those outside instruments or report total remaining borrowing capacity. No support is needed for the stated figures (259, `on-20230331.htm`, u258 [1291808, 1294080]).

## 282

Because maturities are short, ON says carrying amounts approximate fair value for cash and its equivalents and such other current balances as receivables and payables. Demand and time deposits and money market funds are Level 1. Corporate bonds, commercial paper and the cited other current balances are Level 2. Piece 278 defines Level 1 as quoted prices for identical items in active markets. Pieces 279–280 together define Level 2 as other directly or indirectly observable inputs. The group gives no dollar balances or express valuation date. All are in `on-20230331.htm`, 278 u277 [1303011, 1303135], 279 u278 [1303297, 1303428], 280 u279 [1303590, 1303613] and 282 u281 [1304109, 1304737].

## 301

ON reports long-term borrowings including the current portion. Piece 300 supplies $ millions. Piece 302 explains that carrying amounts deduct applicable debt discounts and issuance costs. Each pair below is carrying amount / fair value. The group gives the note rates, but no maturity dates or valuation methods.

| Debt (301) | March 31, 2023 | December 31, 2022 |
|---|---:|---:|
| 0% notes | 791.9 / 1,306.2 | 791.1 / 1,057.8 |
| 0.50% notes | 1,469.3 / 1,572.8 | — / — |
| 1.625% notes | 134.4 / 517.6 | 137.0 / 417.8 |
| 3.875% notes | 693.6 / 641.1 | 693.3 / 618.3 |
| Other long-term debt | 375.0 / 377.0 | 1,572.1 / 1,549.2 |

All are in `on-20230331.htm`, 300 u299 [1453525, 1453636], 301 t300 [1454742, 1483393] and 302 u301 [1483827, 1483942].

## 411

ON's other income (expense) was income of $4.7 million in the quarter ended March 31, 2023, compared with $2.1 million in the quarter ended April 1, 2022. The $2.6 million increase (calculated) primarily reflects a gain on terminating interest rate swaps, partly offset by foreign-currency transaction losses. The gain and losses are not separately quantified. The main is sufficient (411, `on-20230331.htm`, u410 [1701150, 1701524]).

## 418

ON lists operations, working capital, strategic acquisitions and investments as its first category of cash needs. The next four cover principal and interest payments, research and development, capital expenditures and share repurchases. Piece 418 states general uses. It gives no amount, spending commitment, period, priority or source of funding (`on-20230331.htm`, u417 [1704057, 1704358]).

## 457

Only the heading “Forward-Looking Statements” is present. It conveys no forecast, cautionary terms, reporting period or assumptions of its own. Keeping it as an independent substantive item adds a heading without a claim. The packet contains no accompanying text (457, `on-20230331.htm`, u456 [1722684, 1722710]).

## 580

Piece 579 identifies Hassane El-Khoury as the individual certifying. He states in 580 that he reviewed ON Semiconductor Corporation's quarterly Form 10-Q. The same-exhibit filename `q123ex311certificationceo.htm` identifies it as the CEO certification and indicates first-quarter 2023. The printed clause gives no precise quarter-end or signature date, nor any conclusion about accuracy or controls. The May 1 date in the header is the filing date. Piece 579 is u2 [960, 999] and 580 is u3 [1293, 1526].

## 595

Piece 594 identifies Thad Trent as the individual certifying. He states in 595 that he reviewed ON Semiconductor Corporation's quarterly Form 10-Q. The same-exhibit filename `q123ex312certificationcfo.htm` identifies it as the CFO certification and indicates first-quarter 2023. The clause gives no precise quarter-end, signature date or opinion on the financial statements or controls. The May 1 filing date is supplied separately in the header. Piece 594 is u2 [960, 992] and 595 is u3 [1285, 1518].
