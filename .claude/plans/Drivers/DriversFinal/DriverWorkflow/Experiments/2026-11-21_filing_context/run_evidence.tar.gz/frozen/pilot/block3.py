import json
import os
from pathlib import Path

run = Path(os.environ["PROBE_RUN"])
pieces = json.loads((run / "index.json").read_text())["pieces"]
assignments = json.loads((run / "assignments.json").read_text())
answers, failures, groups = {}, {}, {}

def rows(label, targets):
    reply = json.loads((run / f"calls/{label}.summary.json").read_text())
    if reply["exit"] or reply["is_error"] or reply["subtype"] != "success":
        raise ValueError("call failed")
    if reply["model"] != "claude-sonnet-5-5" or reply["num_turns"] != 1 or not isinstance(reply["result"], str):
        raise ValueError("unexpected model, turn count or result")
    by_target = {str(n): [] for n in targets}
    found, issues = {}, []
    for line in reply["result"].splitlines():
        fields = line.split()
        if fields:
            if fields[0] in by_target:
                by_target[fields[0]].append(fields[1:])
            else:
                issues.append(f"unassigned or unrecognized row {line!r}")
    for n in targets:
        entries = by_target[str(n)]
        if len(entries) != 1 or not entries[0]:
            issues.append(f"{n}: expected one labeled answer, got {entries!r}")
            continue
        status, *links = entries[0]
        sure = {v for v in links if not v.endswith("?")}
        possible = {v[:-1] for v in links if v.endswith("?")}
        ids = sure | possible
        if status not in ("keep", "useless", "incomplete") or (status == "useless" and ids):
            issues.append(f"{n}: invalid label or links for {status!r}")
        elif str(n) in ids or not all(v in pieces for v in ids) or sure & possible:
            issues.append(f"{n}: self, unknown or contradictory link in {links!r}")
        else:
            ordered = [v + ("?" if v in possible else "") for v in sorted(ids, key=int)]
            found[n] = {"status": status, "links": ordered}
    return found, issues

def with_paragraphs(numbers):
    return {other for n in numbers for other in pieces[str(n)].get("paragraph", [n])}

for label, targets in assignments.items():
    try:
        answers[label], issues = rows(label, targets)
    except (OSError, ValueError, KeyError) as error:
        failures[label] = [str(error)]
        continue
    if issues:
        failures[label] = issues
    if label in ("A1", "B"):
        for n, row in answers[label].items():
            if row["status"] == "useless":
                continue
            sure = with_paragraphs([n] + [int(v) for v in row["links"] if not v.endswith("?")])
            possible = with_paragraphs(int(v[:-1]) for v in row["links"] if v.endswith("?"))
            groups[n] = {"status": row["status"], "needed": sorted(sure - {n}), "possible": sorted(possible - sure)}

(run / "review.json").write_text(json.dumps({"answers": answers, "failures": failures, "groups": groups}))
print("Open calls or rows", failures)
print("Incomplete", [(label, n) for label, rows_ in answers.items() for n, r in rows_.items() if r["status"] == "incomplete"])
if "A1" in answers and "A2" in answers:
    compared = [n for n in assignments["A1"] if n in answers["A1"] and n in answers["A2"]]
    different = [n for n in compared if answers["A1"][n] != answers["A2"][n]]
    print("Agreements", len(compared) - len(different), "of", len(compared), "paired answers;",
          len(assignments["A1"]) - len(compared), "unpaired. Differences", different)
