# Independent reading of the supplied pieces

Each entry treats the main and its listed pieces as the available evidence. The filing header identifies Installed Building Products, Inc. (IBP) and a Form 10-K filed February 26, 2026.

## Main 6

- The checked box in row 1 selects an annual report under Section 13 or 15(d) of the Securities Exchange Act of 1934 (6). Piece 7 identifies the fiscal year ended December 31, 2025. Without 7, the box still identifies the report type, but the reader loses the period it covers. The filing date in the header serves a different purpose.
- No supplied piece is redundant. Pieces 6–7 do not specify which of the two statutory sections applies to IBP individually.

## Main 188

- IBP formed the Foundation primarily for employees, their families and local communities. IBP commits a portion of annual profits to nonprofit partners and initiatives focused on education, housing and stronger communities. In 2025, the Foundation **and IBP** awarded over 240 grants and made over $4.1 million in contributions, including employee scholarships and financial assistance and donations and matching gifts to employee-supported charities. The separate figure of over $18.4 million is grants by **the Foundation** since its 2019 inception. Emergency and disaster assistance is part of its continuing mission (188).
- Piece 135 supplies the full name, Installed Building Products Foundation, and identifies who administers the employee and family scholarship program and the employee financial assistance program. It ties eligibility for that assistance to hardship from an unexpected emergency or disaster. Removing 135 loses those details. Its mission and three community focus areas repeat 188. The amounts and dates stand on 188 alone.
- Neither piece gives the percentage of profits pledged or allocates the 2025 contributions by payer, program or recipient (135, 188).

## Main 511

- I inspected the image itself. Its vertical axis reads “$ Price Returns” and runs from 0 to 300. The legend shows IBP as dark circles, Russell 2000 as blue squares, S&P 500 Industrials as green diamonds and S&P 600 Building Products as red triangles. All four start together. IBP falls below all three in 2022, rebounds above them in 2023, dips slightly in 2024 and finishes well ahead in 2025 (511).
- Piece 510 is needed to establish the $100 starting investment, dividend reinvestment and the stated measure of cumulative total shareholder return over five fiscal years through December 31, 2025. The image's axis label alone does not establish that treatment of dividends. Piece 510 names three comparison indices but says “four indices.” The image legend and table show three indices plus IBP (510–512). No fourth benchmark can be identified.
- Piece 512 repeats the plotted series but gives exact reported values, which the image marks only by position. The six columns, in order, are December 31, 2020, December 31, 2021, December 30, 2022, December 29, 2023, December 31, 2024 and December 31, 2025 (511–512).

| Series (512) | 2020 | 2021 | 2022 | 2023 | 2024 | 2025 |
|---|---:|---:|---:|---:|---:|---:|
| IBP | 100 | 138 | 87 | 189 | 183 | 276 |
| Russell 2000 | 100 | 115 | 91 | 107 | 119 | 134 |
| S&P 500 Industrials | 100 | 121 | 114 | 135 | 158 | 189 |
| S&P 600 Building Products | 100 | 125 | 104 | 137 | 177 | 193 |

- Interpreting the $100 baseline in 510, IBP's ending 276 implies a five-year cumulative gain of 176% (calculation from 510 and 512).

## Main 516

| 2025 period | All shares purchased | Average paid per share | Announced program shares | Approximate amount still authorized |
|---|---:|---:|---:|---:|
| Oct 1–31 | 32 | $240.32 | — | $365.0 million |
| Nov 1–30 | 150,006 | $250.96 | 150,000 | $327.4 million |
| Dec 1–31 | — | — | — | $327.4 million |
| Quarter | 150,038 | $250.96 | 150,000 | $327.4 million |

- Piece 516 gives the rows above. Piece 515 confirms the unlabeled last row covers the three months ended December 31 and that all purchases include employee share surrenders. The months and 519 largely duplicate that information. The last dollar column is a balance at period end.
- Note (1) in 517 explains the balance. The board's February 27, 2025 program authorized up to $500.0 million of common stock through March 1, 2026. IBP purchased $172.6 million under it during 2025. Without 517, both the cap and annual purchases disappear. The February 26, 2026 announcement of a new $500.0 million program replacing it through March 1, 2027 is a subsequent event. Note 13 is a pointer in 517.
- Note (2) in 518 identifies the seller, PJAM IBP Holdings, Inc., and the privately negotiated program purchase of 150,000 shares for $37.6 million, or $250.96 per share. The monthly rows place that transaction in November by elimination (516, 518). The filing points to Note 16 on related parties. The relationship itself is unspecified here.
- Note (3) in 519 explains the otherwise unmatched 38 shares. Employees surrendered them for withholding taxes on 108 vested restricted shares under the 2014 and 2023 Omnibus Incentive Plans. Subtracting program purchases from all purchases gives 32 in October and six in November (516, 519). The 108 vested shares are not allocated by month or plan. Without 518–519, the buyer's counterparty, the transaction terms and the reason for the 38-share difference disappear.

## Main 547

- Piece 547 reports year-over-year percentage changes for years ended December 31. Each pair in the first seven rows below gives total sales growth followed by same-branch sales growth. The final rows are single measures. In 2025, companywide sales rose 1.0% while sales at comparable branches fell 1.3%. Commercial installation grew at both levels while residential installation contracted (547).

| Metric, all in % (547) | 2025 | 2024 | 2023 |
|---|---:|---:|---:|
| Consolidated, total / same branch | 1.0 / −1.3 | 5.9 / 3.5 | 4.1 / 0.2 |
| Installation, total / same branch | 0.1 / −1.5 | 6.0 / 3.8 | 3.7 / −0.1 |
| Single-family installation, total / same branch | −1.9 / −4.1 | 6.4 / 3.6 | −5.4 / −9.0 |
| Multi-family installation, total / same branch | −5.4 / −5.7 | 6.5 / 5.6 | 35.0 / 33.3 |
| Residential installation, total / same branch | −2.6 / −4.4 | 6.4 / 4.0 | 1.0 / −2.3 |
| Commercial installation, total / same branch | 11.2 / 10.4 | 3.0 / 1.2 | 17.2 / 11.5 |
| Other, net of eliminations, total / same branch | 15.5 / 2.3 | 3.7 / −1.0 | 10.7 / 5.2 |
| Same-branch installation volume | −5.7 | 0.2 | −8.4 |
| Same-branch installation price/mix | 1.6 | 3.7 | 7.2 |
| U.S. housing completions, total | −7.9 | 12.3 | 4.2 |
| U.S. housing completions, single-family | −0.8 | 1.8 | −2.3 |
| U.S. housing completions, multi-family | −20.3 | 35.4 | 22.1 |

- Piece 548 is essential to the meaning of the row labels. Notes (1)–(6) define a comparable branch as owned **more than** 12 months at each statement date. All-installation covers all its end markets. Single- and multi-family are subsets of residential **new construction**. Commercial combines heavy and light projects. Note (7) defines Other as Manufacturing and Distribution, excluding intercompany transactions (547–548).
- Notes (8)–(10) explain why the two component rows cannot simply be read as a breakdown of the whole installation segment. They exclude unusually large heavy commercial jobs. Volume measures the change in completed same-branch job count. Price/mix uses the change in average selling price per same-branch job multiplied by current-year jobs. Product and customer mix affect it. Note (11) says every period for the marked rows uses the revised exclusion of certain intercompany sales. Note (12) attributes U.S. housing completions to revised Census Bureau data. Removing 548 would lose these boundaries, calculations and source. No dollar sales, raw job totals or split of price from mix appear (547–548).
- Piece 546 adds that management uses these measures to evaluate performance. It adds no row definition or number, so the table can be read without it (546–548).

## Main 655

- At December 31, 2025 IBP had two active interest rate swaps. Together they hedge $400.0 million of variable cash flows on its variable-rate Term Loan through December 14, 2028. IBP records the swap assets at fair value within other current assets and other non-current assets. The $400.0 million describes the exposure hedged. The sentence gives no dollar value for the assets (655).
- Piece 649 identifies the underlying loan and adds terms the main omits. The March 2024 amendment allowed a new $500 million loan maturing March 28, 2031. After the November 2024 repricing, IBP could choose adjusted Term SOFR plus 1.75% annually or the alternative base rate plus 0.75%. The loan's maturity is later than the stated hedge end date (649, 655). The old $490.0 million refinancing, fees, working capital, earlier amendment dates and Royal Bank of Canada's agency roles explain the loan's history. They are separate from the swap disclosure. Removing 649 loses the underlying rates and loan maturity, but all swap figures printed in 655 remain readable.
- The cited Note 12 and Note 10 contents are absent. Individual swap amounts, interest rates and maturities, swap counterparties and fair-value balances or valuation inputs are undetermined. Piece 649 gives the original loan amount, so it does not establish current principal or an amount still unhedged at December 31, 2025 (649, 655).

## Main 724

- This is IBP's consolidated balance sheet at December 31, 2025 and 2024. Piece 722 supplies the formal title and confirms consolidation. The rows alone suggest a balance sheet. Piece 723 is essential for scale. Dollar balances are in millions, with share counts and per-share amounts in their own units. The dates and all values below are from 724. Pairs follow **2025 / 2024**.

| Balance-sheet rows (724) | December 31 amounts in $ millions (723–724) |
|---|---|
| Current assets | Cash 321.9 / 327.6, receivables 444.1 / 433.9 after credit-loss allowances of 13.9 / 10.7, inventories 203.0 / 194.6, prepaids and other 73.6 / 98.8. Total 1,042.6 / 1,054.9. |
| Remaining assets | Net property and equipment 183.3 / 174.8, operating lease right-of-use assets 98.7 / 95.6, goodwill 450.4 / 432.6, net customer relationships 172.2 / 178.8, other net intangibles 89.3 / 91.7, other non-current assets 31.5 / 31.5. Total assets 2,068.0 / 2,059.9. |
| Current liabilities | Debt maturities 36.6 / 32.4, operating lease maturities 37.0 / 34.3, finance lease maturities 2.7 / 2.8, payables 119.0 / 146.6, accrued compensation 69.5 / 66.4, other 79.4 / 76.5. Total 344.2 / 359.0. |
| Remaining liabilities | Long-term debt 850.0 / 842.4, operating leases 61.4 / 61.0, finance leases 4.0 / 5.4, deferred income taxes 24.7 / 26.3, other long-term liabilities 73.8 / 60.5. Total liabilities 1,358.1 / 1,354.6. |
| Equity | Preferred stock — / —, common stock 0.3 / 0.3, additional paid-in capital 284.1 / 261.3, retained earnings 1,043.4 / 865.5, treasury stock at cost −640.0 / −456.8, accumulated other comprehensive income 22.1 / 35.0. Total equity 709.9 / 705.3. |

- Share exceptions in 723 matter for the equity rows in 724. Both classes have $0.01 par value. Preferred has 5,000,000 authorized and zero issued or outstanding in either year. Common has 100,000,000 authorized, 33,837,379 / 33,713,662 issued, 6,862,152 / 5,955,171 in treasury and 26,975,227 / 27,758,491 outstanding. Issued less treasury agrees with outstanding in each year. Liabilities plus equity likewise equal total assets of $2,068.0 million / $2,059.9 million (calculated check of 723–724).
- The blank commitments-and-contingencies row points to Note 17 (724). Its contents are absent, so the nature or amount of commitments cannot be determined from this row. Pieces 722 and 723 each contribute information, and neither supplies that note.

## Main 730

- IBP reports its consolidated operations and comprehensive income for the years ended December 31, 2025, 2024 and 2023. Piece 728 provides the formal title and consolidation scope. Piece 729 establishes that dollar amounts are in millions, except for share counts and per-share amounts. Removing 728 leaves the scope inferred from layout. Removing 729 loses the monetary scale. Neither supplies additional financial results. All triples below follow **2025 / 2024 / 2023** (728–730).

| Rows (730) | Values in reported year order |
|---|---|
| Sales and gross profit, $ millions | Net revenue 2,970.8 / 2,941.3 / 2,778.6, cost of sales 1,961.5 / 1,946.8 / 1,847.9, gross profit 1,009.3 / 994.5 / 930.7. |
| Operating expenses and income, $ millions | Selling 144.6 / 139.8 / 131.8, administrative 437.2 / 424.8 / 385.3, impairment — / 4.9 / —, amortization 41.1 / 42.5 / 44.5. Operating income 386.4 / 382.5 / 369.1. |
| Interest, taxes and net income, $ millions | Net interest expense 31.7 / 36.9 / 37.0, other income shown as an expense offset (2.3) / (0.8) / (1.0), pretax income 357.0 / 346.4 / 333.1, income tax provision 91.6 / 89.8 / 89.4, net income 265.4 / 256.6 / 243.7. |
| Other comprehensive income, $ millions | Cash flow hedge changes −12.9 / +1.3 / −6.9 after tax benefits (provision) of +5.0 / −0.6 / +2.5. Comprehensive income 252.5 / 257.9 / 236.8. |
| Earnings and declared cash dividends, $ per share | Basic earnings 9.76 / 9.16 / 8.65, diluted earnings 9.71 / 9.10 / 8.61, dividends declared 3.18 / 3.00 / 2.22. |
| Weighted-average shares outstanding, shares | Basic 27,201,802 / 28,030,187 / 28,161,583, diluted 27,327,972 / 28,190,404 / 28,306,313. |

- Net income rose in 2025 while comprehensive income fell. The table reconciles each year by adding the after-tax cash flow hedge change to net income. It gives weighted-average shares, not a year-end share count. The reasons for the underlying hedge movement and the timing of dividend payment are unspecified (730).

## Main 1018

- Piece 1018 contains just the subject of a sentence, “Amounts reported in accumulated other comprehensive income.” Piece 1019 is its necessary continuation. The amounts related to derivatives will move into net interest expense as IBP pays interest on variable-rate debt and recognizes amounts from amended swaps that have matured. IBP estimates a further **$8.5 million decrease** in net interest expense over the next twelve months. Removing 1019 leaves no derivative scope, action, timing, direction or amount (1018–1019).
- Piece 1012 explains the reference to the amended matured swaps. There were three, all with amended maturities. Remaining unrealized gains reduce net interest expense through the original maturity dates of April 15, 2030 and December 15, 2028. IBP recognized $7.1 million of those gains in **each** of 2025, 2024 and 2023. A separate financing element from off-market terms at inception *increased* net interest expense by $7.4 million in each year through the amended December 31, 2025 maturity (1012). Without 1012 the complete forecast still stands, but the reader loses which swaps are meant, the different dates and why the two historical amounts run in opposite directions.
- The pieces do not allocate the $8.5 million forecast between variable-debt payments and matured swaps. They also do not allocate the three swaps to the two original dates. Applying “next twelve months” to the next calendar year is an inference from the year-end discussion, not a start or end date printed in 1019 (1012, 1018–1019).

## Main 1267

- Piece 1267 is an exhibit index. Piece 1263 supplies its column headings, “Exhibit Number” and “Description.” Without 1263, the roles of the columns can still be inferred. Its earlier entries on corporate documents, securities, employment, incentive plans and financing are separate listings. No transaction amounts, share quantities or agreement terms are printed in the three repurchase entries (1263, 1267).

| Exhibits (1267) | What is actually listed |
|---|---|
| 10.29–10.31 | Three share repurchase agreements between IBP and PJAM IBP Holdings, Inc., incorporated from Exhibit 10.1 of three separate Form 8-K reports. The 2025 agreement date / 8-K filing date pairs are March 7 / March 10, August 19 / August 20 and November 24 / November 24, respectively. |
| 19 and 97 | Insider Trading Policies incorporated from Exhibit 19 of the February 27, 2025 Form 10-K. Mandatory Recoupment Policy adopted November 7, 2023, incorporated from Exhibit 97 of the February 22, 2024 Form 10-K. |
| 21.1* and 23.1* | IBP's list of subsidiaries and Deloitte & Touche LLP's consent, respectively. The list and consent themselves are outside these pieces. |
| 31.1* / 31.2* | CEO / CFO certifications under Exchange Act Rule 13a-14(a) and Sarbanes-Oxley Act Section 302. |
| 32.1* / 32.2* | CEO / CFO certifications under 18 U.S.C. Section 1350 and Sarbanes-Oxley Act Section 906. For 32.2 the exhibit-number link ends in `ex322xcfo.htm`, but the CFO description's link ends in `ex321xceo.htm`. The printed description and links disagree. |
| 101** / 104** | Exhibit 101 describes inline XBRL versions of the consolidated balance sheets, statements of operations and comprehensive income, equity, cash flows and accompanying notes. It explicitly gives the period ended December 31, **2021**. Exhibit 104 is the inline XBRL cover-page data file contained in 101. |

- Piece 1269 is essential for interpreting the single asterisk on six exhibits as “Filed herewith.” Piece 1270 is essential for the double asterisk on 101 and 104, “Submitted electronically with the report.” Neither meaning is printed in 1267. The wording in 101 and the inconsistent links in 32.2 can be reported as printed. Their intended corrections and the contents of linked documents cannot be established from these pieces (1267, 1269–1270).

## Main 1291

- Pieces 1290 and 1291 form one sentence. The speaker consents to incorporation by reference in **Form S-8 Registration Statements 333-195107 and 333-272369** of its February 26, 2026 reports on IBP's consolidated financial statements and on the effectiveness of IBP's internal control over financial reporting. The reports appear in IBP's Form 10-K for the year ended December 31, 2025 (1290–1291).
- Without 1290, the main starts mid-sentence. The action, consent by the speaker, and both registration numbers disappear. Nothing in 1290 repeats 1291. Neither piece names the speaker, gives either report's opinion or states the controls were effective (1290–1291).
