import json
import os
from pathlib import Path

run = Path(os.environ["PROBE_RUN"])
index = json.loads((run / "index.json").read_text())
n = int(os.environ["PIECE"])
group = json.loads((run / "review.json").read_text())["groups"][str(n)]
print(index["metadata"], "main", n, group["status"])
for number in sorted([n] + group["needed"] + group["possible"]):
    p = index["pieces"][str(number)]
    role = "main" if number == n else "possible" if number in group["possible"] else "support"
    print(number, role, p["file"], p["unit"], p["bytes"], "\n", p["body"])
    if "image" in p:
        print("Show original image", p["image"])
