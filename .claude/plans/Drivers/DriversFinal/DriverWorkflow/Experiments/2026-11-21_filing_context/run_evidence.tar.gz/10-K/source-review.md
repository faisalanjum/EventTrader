# Simply Good Foods 2024 Form 10-K — independent source reading

The reader already knows the filer, form and filing date. I judged whether a piece changes the meaning of the selected passage itself. Where a figure can be read by itself but a definition limits how it can be used, I state both. Numbers refer to original filing pieces.

| Main | Decision | Closest source dependency |
|---:|---|---|
| 44 | Omit as a standalone item | Table of contents |
| 115 | Keep | Figures and strategy stand alone. 98 or 99 identifies the full brand portfolio. |
| 276 | Keep | The conditional risk stands alone. |
| 362 | Keep | The personnel risk stands alone. |
| 577 | Keep | The definition stands alone. 580 explains the residual adjustment. |
| 662 | Keep | 697 identifies the auditor. 659 or 665 establishes its independent role. |
| 770 | Omit as a standalone item | Accounting-policy heading |
| 937 | Keep | 936 confirms a fact already given. |
| 949 | Keep | Table labels and amounts stand alone. 788 qualifies the coverage of the recorded balances. |
| 965 | Omit as a standalone item | Numbered note heading |
| 1006 | Keep | 1005 identifies the award and reporting interval. 1002 explains how the grant price is set. |
| 1146 | Keep the actual image | The logo is readable. 1148 identifies which document it heads. |
| 1212 | Keep | 1148 or 1151 names the policy. 1166 identifies the people addressed. 1211 is the original question. |
| 1288 | Keep | 1289 names the firm giving consent. 1287 gives its capacity. |
| 1309 | Keep | 1297–1298 establish what Tanner signed. 1296 distinguishes his Section 302 certification. |
| 1316 | Keep | 1315 identifies the speaker. 1327 also supplies his role. 8 gives the report's fiscal year-end. |

### 44

The linked rows list the parts, item numbers, names and page locations of the report. This is a useful navigation aid with no independent statement about any listed topic. Piece 43 merely labels it “TABLE OF CONTENTS.” The presence of “Unresolved Staff Comments,” for example, does not establish the company has any. No supporting piece is needed to rescue 44.

### 115

For the 53 weeks ended August 31, 2024, mass retail, grocery and convenience together accounted for approximately 77% of Quest's and 83% of Atkins' U.S. gross sales. E-commerce accounted for approximately 22% and 17% of the respective brands' gross sales in the same period. The e-commerce sentence does not expressly repeat the U.S. geographical restriction. The main describes further distribution as management's belief and intention. The historical shares, dates and plan are complete in 115. Piece 98 or 99 resolves the literal scope of “each of our brands” to Quest, Atkins and OWYN. Without either, a reader could extend the two-brand figures to OWYN or assume the portfolio has only two brands. Neither supplies an OWYN channel percentage. The text itself lists convenience both as an existing channel and as an example of further opportunity. Piece 154's retailer percentages have a different denominator.

### 276

This is a substantive risk statement even though it serves as a heading. Failure to sustain brand recognition and distribution, attract new consumers, or introduce products on time or at all may harm the business (276). Its conditional wording is complete. Piece 277 adds evidence about changing demand, growing reliance on new products, premature launches, taste and texture, and revenue risk. These are reasons for the risk, not missing parts of the statement. Piece 57 repeats much of it. Piece 278 starts a separate shelf-space risk.

### 362

Dependence on key executives and on skilled staff throughout the organization creates a risk. Sudden loss of personnel, poor succession planning, slow or unsuccessful replacement, and failure to attract and retain staff could impair operations and expansion (362). It reports no actual departure or vacancy. Pieces 361 and 71 summarize the same risk. No adjoining piece is required.

### 577

The company defines EBITDA from net income or loss before interest income, interest expense, income tax, depreciation and amortization. Adjusted EBITDA also excludes stock compensation, executive transition, business transactions, inventory step-up, integration, term-loan fees and other non-core expenses. Management uses them alongside GAAP net income. Neither replaces net income for operating performance or operating cash flow for liquidity. Companies can calculate them differently (577). The adjacent heading 576 contributes no definition. Piece 580 is the source for what “other” principally means in these periods, namely foreign-currency transaction effects and other expenses. It also shows an adjustment of negative $265,000 in 2024 and positive $393,000 in 2023. The reconciliation amounts and unaudited two-period scope in 579–580 concern the example calculation. They are unnecessary for the definition as stated.

### 662

This is **Deloitte & Touche LLP's** opinion on Simply Good Foods and its subsidiaries. The same report's signature is 697. Its heading 659 or responsibility statement 665 makes the independent public accounting firm's capacity explicit. The latter distinguishes management's responsibility for the statements from the auditor's responsibility for the opinion. The filer name alone would misattribute “we.” The auditor concluded the statements fairly present, in all material respects, financial position at August 31, 2024 and August 26, 2023, and results and cash flows for the three fiscal years ended August 31, 2024, under U.S. GAAP. The current year had 53 weeks. The other two had 52 each (662). Piece 699 explicitly dates the auditor's report October 29, 2024. Piece 660 identifies its addressees. Piece 666 describes the reasonable-assurance standard if the audit method is needed. Piece 663 concerns a separate opinion on internal controls. OWYN's internal-control exclusion in 1062 does not qualify the financial-statement opinion in 662.

### 770

“Property and Equipment, Net” labels an accounting policy and supplies no assertion or number. Piece 771 owns the acquired-asset valuation and straight-line depreciation policy, 772 the asset lives, 773 the leasehold policy and 774 the impairment disclosure. Piece 857 is a different note heading whose balances appear in 859. No amount or policy belongs to 770 alone.

### 937

The company records interest and penalties on unrecognized tax benefits in tax expense. At both August 31, 2024 and August 26, 2023, it had accrued none because no such position was recorded. Management anticipates no change to the uncertain-tax-position balance over the next twelve months and no material financial statement effect (937). The year-end discussion anchors that outlook at the latest fiscal year-end. It is an expectation. Piece 936 explicitly confirms no unrecognized tax benefits at the same two dates but its removal loses no practical qualification. Piece 938 discloses years still open for examination, a different matter.

### 949

The columns themselves identify dates, balance sheet captions and dollars in thousands. In 2024 / 2023, operating right-of-use assets were 35,097 / 40,022 and finance right-of-use assets were — / 125, totaling 35,097 / 40,147. Current operating liabilities were 5,494 / 7,566, current finance liabilities — / 143 and long-term operating liabilities 34,330 / 37,272. The reported liabilities total 39,824 / 44,981. The dates are August 31, 2024 and August 26, 2023 (949). Piece 948 repeats the table's scope. The printed balances need no further labels.

For a claim about **which leases those balances measure**, 788 matters. The company excludes short-term operating leases of a year or less, discounts payments at commencement, generally uses its secured incremental borrowing rate when an implicit rate is unavailable, and includes extension or termination options when exercise is reasonably certain. Without that scope a reader could equate recorded liabilities with gross obligations on every lease. Piece 953 independently reconciles 2024 operating lease payments of 48,384 less interest of 8,560 to 39,824. Piece 955 gives weighted-average operating discount rates of 5.1% / 4.4%, finance rates of — / 5.6%, and remaining lease terms. Those are separate measurement details. The table's 2023 total includes finance liabilities. The 2024 operating maturity schedule cannot stand in for that balance.

### 965

“12. Stockholders’ Equity” identifies a note and contains no standalone equity disclosure. The next sections deal with warrants (966–968), the repurchase program (969–971) and accumulated other comprehensive loss (972–973). None is necessary to interpret the heading itself.

### 1006

The table says only “Units.” Its exact introduction, 1005, establishes that these are **restricted stock units** during the 53 weeks ended August 31, 2024. Without this, performance stock units are an especially credible wrong reading. Their separate table 1011 uses the same column labels, dates and movement categories. Piece 1001 or 1002 can alternatively identify the award, and the table's dates imply the interval. Piece 1002 further explains the grant price is the common stock's closing market price on the grant date and that awards generally vest over three years. Neither a Black-Scholes option assumption (997–999) nor a performance-unit Monte Carlo assumption (1009, 1012–1013) applies to this table.

On August 26, 2023 there were 514,498 unvested units at $35.59 weighted-average grant-date fair value. Grants were 337,183 at $36.64, vestings 272,485 at $32.93, and forfeitures 32,925 at $38.72. The unit counts reconcile to 546,271 unvested at $37.38 on August 31, 2024 (1006). The dollar figures are per-unit grant-date averages. Piece 1007's $11.8 million future compensation expense and 1.6-year recognition period are distinct.

### 1146

I inspected the original image. It shows a bright green, heart-shaped mark above the dark-blue words “SIMPLY GOOD.” Keep the image. Its message survives without surrounding text. Piece 1147 supplies the formal corporate name already known to the reader. Piece 1148 identifies this use as the logo at the head of the **Insider Trading Policy**, if its placement matters. The February 27, 2023 effective date in 1149 belongs to the policy. The pixels do not claim that date or express a trading rule.

### 1212

The company's **Insider Trading Policy** extends to any entity a covered person influences or controls, including corporations, partnerships and trusts. The covered person treats these entities' transactions as their own for purposes of the policy and applicable securities laws (1212). Piece 1148 names “this Policy,” and 1151 is a stronger substitute that expressly defines it. Piece 1166 identifies the addressee as a covered insider, including directors and company/subsidiary officers and employees and others the company may designate, plus the household and controlled parties it describes. This prevents reading “you” as every investor. Piece 1211 is the exact question answered by “Yes.” Its subject is fully repeated in 1212, so omitting the question alone loses the Q&A form but no operative condition. The family-member exception in 1210 belongs to the prior question. Piece 1149 gives the policy's effective date if reporting applicability over time.

### 1288

The speaker consenting to incorporation by reference is **Deloitte & Touche LLP**, identified by the signature in 1289. Piece 1287 identifies it as the independent registered public accounting firm. Omitting both would invite attributing the consent to the filer. An alternative is the filing's exhibit index, 1096 row 22, expressly describing Exhibit 23.1 as Deloitte's consent and linking to the source exhibit. The covered financial statement and internal-control reports are dated October 29, 2024. The Form 10-K period ended August 31, 2024. The registrations are S-8 No. 333-220776 and S-3 Nos. 333-228696 and 333-234004 (1288). The sentence consents to use of the reports and makes no new independent opinion on the statements or controls. Piece 1291 separately dates the consent the same day.

### 1309

The table establishes that Geoff E. Tanner signed October 29, 2024 as president, CEO, director and principal executive officer. The table alone leaves **what he signed** open. Pieces 1297–1298 identify his certification that he reviewed this Simply Good Foods Form 10-K. Piece 1296 locates it under Section 302 of the Sarbanes-Oxley Act. Pieces 1294–1295 give the Exchange Act rules. Another precise way to identify the instrument is 1292 (Exhibit 31.1) with 1096 row 23. The titles and date alone also fit the company's general filing signature in 1107 and Tanner's signature on the joint Section 906 certification in 1337. The other clauses of his Section 302 certificate in 1299–1308 give substantive attestations, but no part is needed merely to identify the signer, authority and date.

### 1316

This is **Shaun P. Mara** certifying that he reviewed Simply Good Foods' Form 10-K. Piece 1315 supplies the missing subject of “I” and the verb “certify.” Piece 1327 is a strong alternative for the name and additionally establishes he signed on October 29, 2024 as CFO and principal financial officer. Without a same-exhibit attribution, the identically worded CEO clause in 1298 is an actual counterexample. Piece 8 identifies “this Annual Report” as covering the fiscal year ended **August 31, 2024**. The filing date alone does not supply the fiscal period. Pieces 1311–1314 identify the formal Section 302 certification and its underlying rules. The next clause's knowledge-qualified representation about material errors is separately numbered (1317). Clause 1 claims review only.
