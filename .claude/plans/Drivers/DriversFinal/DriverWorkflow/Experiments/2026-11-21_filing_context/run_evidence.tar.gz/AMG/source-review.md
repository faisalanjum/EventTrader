# Independent reading of AMG's May 1, 2023 Form 8-K and earnings release

I read the numbered source pieces and inspected original courtesy pages 113–120. Each entry below treats the numbered main piece as already available. A single courtesy page can contain several original pieces. A page that merely repeats a table does not supply its off-page footnotes.

## 57

President and CEO Jay C. Horgen attributed first-quarter 2023 Economic EPS of $4.18 to AMG's business profile, the diversity of its affiliates and its capital allocation. The attribution of those explanations to Horgen matters. **56** supplies the speaker. **55** supplies the year and quarter, as do **33** or the title in **47–48**. **113** contains the speaker, period and complete quote together. **60** or **79** can also identify the quarter by the dated $4.18 Economic EPS row. Ordinary diluted EPS was a separate measure. The dollar figure in 49 or 51 alone does not identify who made the claim. The rest of the speech, another period's restatement and all the detailed measure calculations are unnecessary to report this single-period quote.

## 60

This table compares the quarters ended March 31, 2022 and 2023, in that order. Assets under management and client flows are in billions, other dollar amounts in millions, and EPS in dollars per share. It reports operating indicators, net income attributable to the controlling interest, diluted EPS and three supplemental measures. In order, the supplemental pairs are Adjusted EBITDA of $240.0m/$216.8m, Economic net income of $178.5m/$158.1m, and Economic EPS of $4.36/$4.18.

**The changed definition is material to this comparison.** The 2022 column already uses the new basis. In Q1 2023 AMG changed the treatment of strategic investments so that only realized economic gains and losses count, consistent with its treatment of seed capital and general partner commitments. The two directly revised measures were Adjusted EBITDA and Economic net income. Economic EPS changed through its numerator. **91 or 118** supplies the new rule and retrospective application and identifies all three as non-GAAP. **92 or 118** establishes the numerical effect on the 2022 column. The prior-definition amounts were $255.3m, $190.0m and $4.65. The old amounts are evidence for why the change matters. They are optional in a presentation of 60's reported amounts.

**61 or 113** carries the adjacent warning that the three metrics are affected, without the adjustment rule or the fact that the prior figures were recomputed. **92** by itself distinguishes old and new values but omits the rule. **96–98 or 119** describe how the measures work today without saying when AMG changed them or that it applied the change to prior periods. A copy of the table or a general non-GAAP disclaimer alone misses that point.

The (1) mark on diluted EPS is separate from (2) on supplemental measures. **86** gives the general dilution qualification. **87–88** give the maximum-share assumption for redeemable interests, if-converted treatment and after-tax interest addback for junior convertibles, and the exclusion of anti-dilutive effects. **118** supplies all of that and note (2) on a single page. **90** shows the actual numerator and denominator adjustments. The detailed arithmetic is unnecessary if the table's figures are quoted with their correct basis.

## 70

“Financial Tables Follow” is a signpost. It makes no financial or operating claim and needs no supporting piece. **114** repeats it. It can be omitted when collecting substantive information.

## 73

The quarter-to-date bridge runs from December 31, 2022 to March 31, 2023, by Alternatives, Global Equities, U.S. Equities, Multi-Asset & Fixed Income and total. It moves from $650.8bn to $668.0bn, with net client flows of −$3.2bn and market changes of +$20.2bn. The closing amounts by strategy are $223.7bn, $192.6bn, $137.0bn and $114.7bn. **72 or 115** supplies the shared heading spelling out assets under management and expressly assigning billions to the entire statement. Without it the dollar signs in 73 do not establish scale. 74 is a different breakdown of the same balances and flows. 60 corroborates the scale of certain totals, without labeling all of 73's rows.

## 74

For the same dates, 74 breaks the change in assets under management down by institutional, retail and high-net-worth clients. Ending balances are $337.9bn, $196.6bn and $133.5bn. Net client flows were −$2.2bn, −$1.4bn and +$0.4bn. **72 or 115** supplies the name and billion-dollar unit across all rows. 73 supplies a different breakdown. The two totals of $668.0bn describe the same assets and cannot be added together.

## 77

The consolidated income statement compares the quarters ended March 31, 2022 and 2023. Dollars/share counts are in millions except per-share amounts. Revenue fell from $607.3m to $517.4m and controlling-interest income from $146.0m to $134.5m. Basic EPS was $3.68/$3.74 and diluted EPS $3.44/$3.47. **76 or 116** contains the formal statement title. It confirms the consolidated scope already evident in several labels.

Two rows carry notes. For equity method income (3), **102** explains that the line is after equity method intangible amortization and impairments. **103** demonstrates the same composition in dollars. **119** includes both. For diluted EPS (1), **86–88 or 118** gives the share and income assumptions, including the exclusions if anti-dilutive. **90 or 118** gives the equivalent numeric reconciliation for these specific quarters. This matters because dividing the displayed controlling-interest income by the displayed diluted shares misses adjustments to the numerator. **116** reproduces the title, numbers and marks, but the explanations are on other pages. The supplemental performance definition change does not govern these financial statement rows.

## 79

The two quarter columns, millions and per-share units are already printed. Starting from controlling-interest net income, the table reconciles to Economic net income ($178.5m/$158.1m), Economic EPS ($4.36/$4.18 on 40.9m/37.9m adjusted diluted shares) and Adjusted EBITDA ($240.0m/$216.8m). **78 or 116** provides the heading and its (2) mark. **91 or 118** identifies these as supplemental non-GAAP figures and gives the current investment-gain rule and retroactive treatment of the comparative period. 61/113 flag the change. 92 quantifies the old/new values. Neither is the full rule.

The (4) on both BPEA rows needs **104 or 119**. AMG received EQT shares when it sold its Baring Private Equity Asia interest in the Q4 2022 combination. The negative entries for Q1 2023 remove **gains** on EQT shares, $16.3m after tax for Economic net income and $21.6m before tax for Adjusted EBITDA. Q1 2022 shows dashes. Removing this note leaves the source, tax basis and sign of the underlying amounts unclear. **98 or 119** explains the adjusted diluted denominator if its calculation is needed. 79 already gives its amount. Reproducing the entire share reconciliation or the unrelated upper income table is unnecessary.

## 83

The dated balance sheet shows December 31, 2022 and March 31, 2023 balances in millions. Total assets were $8,881.0m/$8,895.8m and liabilities $4,240.0m/$4,143.2m. Redeemable non-controlling interests ($465.4m/$533.2m) have a separate row before equity. Total equity was $4,175.6m/$4,219.4m. The dates and dollar scale are explicit. **82 or 117** adds the missing company-wide scope through the title “Consolidated balance sheet.” No numbered footnote appears. The untitled subtotal before treasury stock is untitled in both versions.

## 90

**89 or 118** identifies what the numerator and denominator are for. The table reconciles basic and diluted EPS for the quarters ended March 31 in 2022 and 2023. The numerator is in millions of dollars and the denominator in millions of shares. Adjusted income was $161.5m/$138.6m and diluted shares 46.9m/39.9m. **87** explains the maximum-share assumption for redeemable interests. **88** explains assumed conversion even if conversion is not yet contractually available and the after-tax interest addback. Both exclude anti-dilutive cases. Those provisions qualify the hypothetical rows and **118** contains them together with the caption and table. **86** provides the general lead-in to note (1). The reported EPS outputs in 77 add a cross-check, without changing 90's figures or supplying the settlement assumptions.

## 92

The table measures the impact of the new definitions, in dollars and percentages, for the years ended December 31 in 2020, 2021 and 2022 and, separately, the three months ended March 31, 2022. EBITDA and net income are in millions. The EPS amounts are dollars per share. In Q1 2022 Adjusted EBITDA moved from $255.3m to $240.0m (−6.0%), Economic net income from $190.0m to $178.5m (−6.1%), and Economic EPS from $4.65 to $4.36 (−6.2%). **91 or 118** explains “as reported” versus “prior definition.” The change was made in Q1 2023, counted realized investment gains/losses, excluded unrealized strategic investment gains/losses and was applied retrospectively. It also says earlier years were affected without a material annual impact. **118** includes the explanation and the complete table. 61/113 give notice only, 119 gives current measure descriptions only, and 93 merely points elsewhere for a different reconciliation.

## 100

For the March 2022 and March 2023 quarters, respectively, the reconciliation starts with 46.9m/39.9m diluted shares, removes 4.0m/0.3m for hypothetical settlement of redeemable interests and 2.0m/1.7m for junior convertibles, and arrives at 40.9m/37.9m adjusted diluted shares. **98 or 119** supplies the meaning of that adjustment. AMG intends to settle the redeemable interests without issuing shares, and applies a treasury-stock calculation to the convertibles, including only net shares representing conversion value above par, if any. The table does not establish a general rule that convertibles can never dilute the economic EPS denominator. 98 also identifies the figure as that denominator. **99** simply names the reconciliation already visible in 100. 90 shows the starting GAAP adjustments and lacks the alternative treatment.

## 103

The rows themselves show equity method earnings of $71.9m/$79.5m, deductions of $23.3m/$20.9m for equity method intangible amortization and impairments, and net equity method income of $48.6m/$58.6m for Q1 2022/Q1 2023. All are in millions. **No additional fact is necessary for the calculation as printed.** **102 or 119** supplies the explicit aggregation wording and identifies this as note (3). **77 or 116** shows exactly which consolidated income statement row bears that same mark. These IDs matter for tying 103 to the parent line. They add no other condition on the amounts.
