# AMG v2 compared with v1 and the frozen original reading

All 12 keep/skip decisions agree. Nine answers are identical, as are their saved packets. The three changed packets match the original text. Links fell from 31 to 24. The financial figures themselves agree in both versions. V2 keeps the definition change 31 pieces away, loses two diluted-EPS qualifications in each of two groups, and removes one unnecessary reconciliation.

| Main | V2 links | Grade and change from v1 |
|---|---|---|
| 57 | 56 | Unchanged. The speaker is clear. The May 1, 2023 filing date makes the first-quarter year inferable. Its explicit link to 2023 still requires 55, 33 or 113. |
| 60 | 61, 86, 91 | **Mixed.** 91 still supplies the investment rule and its retrospective application. New 61 explicitly ties the change to all three measures, including Economic EPS. 86 only introduces dilution. Dropping 87–88 loses the maximum-share and if-converted assumptions, the after-tax interest addback and anti-dilution exclusions. The removed 96–98 provided fuller current formulas. They are optional for quoting this comparison. Original page 118 includes both marked notes. |
| 70 | None | Unchanged. Correctly skipped signpost. |
| 73 | 72 | Unchanged. The heading supplies assets under management and the unit in billions for each strategy. |
| 74 | 72 | Unchanged. The same heading applies to every client-type row. |
| 77 | 76, 86, 102 | **Regression.** 76 retains the consolidated title and 102 explains net equity-method income. 86 covers potential shares. Dropping 87–88 loses the assumptions that also change the diluted EPS numerator. In Q1 2023, $134.5m ÷ 39.9m shares gives $3.37, while the adjusted $138.6m ÷ 39.9m gives the reported $3.47. Original 90 gives the amounts and 118 both the amounts and assumptions. |
| 79 | 78, 91, 96, 97, 98, 104 | **Improvement.** Removed 100, an unnecessary second share reconciliation. 78 and 91 retain the title and revised comparison basis. 104 identifies the pre- and post-tax gains. 96–98 explain the named measures and adjusted denominator. The main already gives the denominator values. |
| 83 | 82 | Unchanged. The title identifies the consolidated balance sheet. |
| 90 | 86, 87, 88, 89 | Unchanged. 89 identifies the EPS calculation, 87–88 preserve both adjustment rules, and 86 is defensible as the numbered-note lead. |
| 92 | 91 | Unchanged. The date, revised rule and retroactive treatment are explicit. |
| 100 | 98, 99 | Unchanged. 98 gives the two share adjustments. 99 still repeats the table's purpose. |
| 103 | 102 | Unchanged. 102 is defensible for the note (3) identity. The figures and equation stand on their own. |
