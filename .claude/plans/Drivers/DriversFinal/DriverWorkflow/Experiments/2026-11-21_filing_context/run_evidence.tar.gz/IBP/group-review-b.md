# Independent reading of the supplied pieces

## 7

Main 7 dates the fiscal year covered by the filing. It ended December 31, 2025. The packet separately identifies Installed Building Products, Inc. and February 26, 2026 as the filing date. Main 7 does not give the fiscal year's start date. No additions were supplied.

## 504

Main 504 identifies where Installed Building Products' common stock trades (the New York Stock Exchange) and its ticker (IBP). The security type, exchange and symbol are explicit. No additions were supplied.

## 510

Main 510 describes a five-fiscal-year comparison through December 31, 2025. It assumes $100 per investment and reinvested dividends. It names three benchmark indices but says “four indices.” Both 511 and 512 show four series in total, including IBP. Neither identifies a fourth index.

512 supplies the exact comparison that 510 points to. Its date columns are 12/31/2020, 12/31/2021, 12/30/2022, 12/29/2023, 12/31/2024 and 12/31/2025. Each row starts at 100. The final values are 276 for IBP, 134 for Russell 2000, 189 for S&P 500 Industrials and 193 for S&P 600 Building Products. Those are values of the initial $100 investment. The table carries no separate unit label. Removing 512 leaves only approximate plotted amounts.

I inspected image 511. It repeats the series and dates in 512, and uniquely labels the vertical axis “$ Price Returns.” That wording differs from 510's description of total returns with reinvestment. I cannot verify the actual calculation. 511 is needed to see this labeling issue. 512 alone suffices for the exact comparison.

## 512

512 reports six dated investment values in each row. Across 12/31/2020, 12/31/2021, 12/30/2022, 12/29/2023, 12/31/2024 and 12/31/2025, respectively, the rows read as follows.

| Investment | 2020 | 2021 | 2022 | 2023 | 2024 | 2025 |
|---|---:|---:|---:|---:|---:|---:|
| IBP | 100 | 138 | 87 | 189 | 183 | 276 |
| Russell 2000 | 100 | 115 | 91 | 107 | 119 | 134 |
| S&P 500 Industrials | 100 | 121 | 114 | 135 | 158 | 189 |
| S&P 600 Building Products | 100 | 125 | 104 | 137 | 177 | 193 |

510 is needed. Without it the table still gives the dates, names and numbers, but the unit, initial $100 investment, reinvested dividends and cumulative-return basis are unstated. The ending value of $276 for IBP implies a cumulative gain of 176%. 510 names the same three benchmark indices that 512 shows, yet says “four indices.” I cannot identify a fourth benchmark from these pieces.

## 518

Footnote (2) reports a privately negotiated program purchase of 150,000 shares from PJAM IBP Holdings, Inc. for $37.6 million in aggregate (rounded), or $250.96 per share. It points to Part II, Item 8, Note 16 on related-party transactions. The main piece alone does not date the trade or say what “Includes” qualifies.

516 is needed to attach (2) to the total-shares-purchased column. November 1–30, 2025 shows 150,006 total shares at an average $250.96, including 150,000 program shares. October shows 32 total at an average $240.32 and no program purchases. December shows dashes for purchases and price. The unlabeled final row reconciles to 150,038 total, 150,000 under the program and an average $250.96. The last column is remaining approximate spending authority in millions of dollars ($365.0 million after October and $327.4 million after November and December).

515 is useful for scope. It says this is the three months ended December 31, 2025 and that the table includes shares surrendered when employee restricted stock awards vest. Removing it loses this explanation of what else can enter total purchases. It is unnecessary for dating the PJAM trade once 516 is present. Neither addition expressly assigns every one of the 38 other shares to employee surrenders or gives an exact trade day.

## 548

548 is a two-column key of footnote numbers and definitions. (1) requires branches to have been owned for **more than** 12 months at each financial statement date. (2) covers all Installation markets. (3) and (4) cover the single-family and multi-family subsets of residential new construction. (5) covers residential new construction and (6) combines heavy and light commercial projects. Each measures period-over-period sales change. (7) covers net sales of Manufacturing and Distribution in “Other,” excluding intercompany transactions.

(8) excludes high-revenue heavy commercial jobs from Installation volume and price/mix calculations because of their size. They still count in commercial sales growth under (6). (9) measures change in the number of completed same-branch jobs. (10) uses the change in average selling price per same-branch job times current-year jobs, reflecting pricing and customer/product mix. Both use Installation markets excluding heavy commercial. (11) excludes certain intercompany sales under a revised calculation in all presented periods. (12) identifies revised U.S. Census Bureau data.

547 is needed to see which rows carry each note, especially the otherwise unidentified calculation in (11) and the data in (12). Its columns are year-over-year percentage changes for the years ended December 31, 2025, 2024 and 2023. (11) marks both Other sales-growth rows and Installation same-branch volume and price/mix growth. (12) marks U.S. housing completions growth (total, single-family and multi-family). For example, in 2025 total commercial sales grew 11.2%, while the narrower Installation same-branch volume fell 5.7% and price/mix grew 1.6%. The table does not quantify the intercompany adjustments or the Census revisions.

## 652

652 says all existing restricted subsidiaries guarantee all obligations under the Term Loan and ABL Revolver. Future restricted subsidiaries will also guarantee them. The obligations and guarantees are secured by substantially all assets of the company and guarantors, subject to exceptions and permitted liens. The paragraph describes first priority on ABL Priority Collateral and second priority on Term Loan Priority Collateral. It refers to the agreements for the meanings of those asset classes. I cannot identify the individual assets, exceptions, or each lender's full order of payment from these pieces.

645 expands ABL and identifies the asset-based revolving credit agreement. Its commitments, availability, interest and amendment dates are additional credit terms. 649 identifies the Term Loan as the $500 million loan issued under the March 2024 amendment and supplies separate refinancing and repricing details. Each identifies one facility. The guarantee and security terms in 652 can be read without either piece. The collateral definitions remain unavailable.

## 1010

1010 has five rows with an effective date, notional amount, fixed rate and maturity date. Three entries effective April 28, 2023 matured December 31, 2025. They comprised $200 million at 0.46% and two separate $100 million entries at 1.32% each. The $300 million swap at 3.06% and $100 million swap at 2.93% both run from December 31, 2025 to December 14, 2028. Notional amounts are the amounts on which the swap payments are calculated.

1009 is needed for the instrument (interest rate swaps), dollar scale (millions), and reporting dates (December 31, 2025 and 2024). 1011 explicitly confirms that only the two later rows were active at December 31, 2025, the day the first three mature and the last two start. One can infer the handover from the dates. Without 1011 the explicit count and the fact that those swaps hedge $400 million of variable Term Loan cash flows disappear. Its balance-sheet classification and fair-value reference add information beyond the table.

## 1011

1011 says two swaps active on December 31, 2025 hedge $400.0 million of variable cash flows on the variable-rate Term Loan through December 14, 2028. The related assets are recorded at fair value in other current and other non-current assets on the consolidated balance sheets. Note 10 is cited. The $400.0 million measures the exposure hedged. The fair values and their current/non-current split are unavailable in this packet.

923 identifies the underlying loan as the $500 million facility issued in 2024 and due March 28, 2031. It gives the floating-rate options after repricing, the refinancing history and other loan terms. Those are additional facts. Removing 923 leaves the hedge, its date, amount and accounting treatment understandable. The original $500 million amount does not establish the loan balance on December 31, 2025.

## 1019

1019 starts mid-sentence. 1018 is necessary to identify the amounts being reclassified. They are derivative-related amounts reported in accumulated other comprehensive income. They move to net interest expense as interest is paid on variable-rate debt and as amended, matured swaps are amortized. The company estimates an additional $8.5 million will reduce net interest expense over the next twelve months. The pieces give no split of that estimate between the two mechanisms.

1012 identifies the amended swaps and explains why there is still an effect after maturity. Three swaps matured December 31, 2025. Remaining unrealized gains reduce net interest expense through the original maturities of April 15, 2030 and December 15, 2028. In each of 2025, 2024 and 2023 the gains reduced expense by $7.1 million and a separate financing element increased it by $7.4 million. The latter ran through December 31, 2025. Removing 1012 loses this explanation of the matured swaps, while the direction and amount of the twelve-month estimate remain clear with 1018.
