"""Build bounded, original-backed reading windows from all-filing text and row labels."""
from collections import defaultdict
from hashlib import sha256
from itertools import zip_longest
from pathlib import Path
from time import monotonic
import json,re,sys
from edgar.display.formatting import split_camel_case
from edgar.search.textsearch import BM25Search
from claude_trial import PRIOR,OUT,load
from study import grade

S=OUT/'issuer_notes_study'
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=1))
def rank(search,query):
    return [h.loc for h in sorted(search.search(query).sections,key=lambda h:(-h.score,h.loc))]

def distinct(rows):
    return list(dict.fromkeys(x for x in rows if x is not None))

def run(dest,co,previous):
    t=monotonic();dest.mkdir(exist_ok=False);source=PRIOR/'filings'/f'{co}.json.gz';idx=load(source);pieces=idx['pieces']
    words=load(S/'generic_name_terms_v1/terms.json');saved=load(S/'searchable_tables_v1'/(co+'.json'));native=saved['tables']
    old=load(previous/co/'packets.json');meta=load(previous/co/'inputs.json');names=meta['names']
    if not meta['source_sha256']==saved['source_sha256']==sha256(source.read_bytes()).hexdigest():raise ValueError('Stale source')
    keys=sorted(map(int,pieces));textindex=BM25Search([pieces[str(n)]['text'] for n in keys]);rowkeys=[];rowtexts=[]
    for num,table in native.items():
        n=int(num);rows=table['rows'];head=next(iter(rows.values()))['printed'][0]
        for rr,data in rows.items():
            tabs=[split_camel_case(tag.partition(':')[-1]) for tag in data['accounting_terms']]
            rowkeys.append((n,int(rr)));rowtexts.append(' '.join([data['printed'][0],head,table['lead_in'][:230],*tabs]))
    rowindex=BM25Search(rowtexts);group=set().union(*(set(v['selected']) for v in old.values()))
    candidates={};upper={};cuts=[]
    for j,name in enumerate(names,1):
        queries=distinct([name,*words[name]])
        queries_by_text=[[keys[k] for k in rank(textindex,q)] for q in queries]
        queries_by_row=[[rowkeys[k] for k in rank(rowindex,q)[:16]] for q in queries]
        hits=defaultdict(list)
        for rows in queries_by_row:
            for n,r in rows:
                if r not in hits[n]:hits[n].append(r)
        basic=queries_by_text[0][:8];neighbors=[n+1 for n in basic[:3] if str(n+1) in pieces and pieces[str(n+1)]['file']==pieces[str(n)]['file']]
        table_ids=distinct(n for row in zip_longest(*queries_by_row) for item in row if item is not None for n,_ in [item])
        copy_pool=distinct(n for row in zip_longest(*(a[:100] for a in queries_by_text)) for n in row if n in group)[:8]
        own=set(old[str(j)]['selected'])
        owned=distinct([n for n in queries_by_text[0] if n in own]+sorted(own))[:4]
        alternates=distinct(n for row in zip_longest(*(x[:6] for x in queries_by_text[1:])) for n in row)
        order=distinct(n for wave in zip_longest(basic,table_ids[:7],neighbors,owned,copy_pool,alternates[:8]) for n in wave)
        snippets={};total=0
        for n in order:
            original=pieces[str(n)]['text']
            if pieces[str(n)]['kind']=='table' and len(original)>1800:
                lines=list(re.finditer(r'(?m)^r([0-9]+): (?=\[c[0-9])',original))
                wanted=distinct([int(m[1]) for m in lines[:2]]+hits[n][:5]+[int(m[1]) for m in lines[-2:]])
                spans=[(m.start(),lines[i+1].start() if i+1<len(lines) else len(original)) for i,m in enumerate(lines) if int(m[1]) in wanted]
            else:spans=[(0,len(original))]
            seen=[];used=0
            for a,b in spans:
                end=min(b,a+max(0,2000-used))
                if end>a and total+sum(y-x for x,y in seen)+(end-a)<=12400:seen.append([a,end]);used+=end-a
            if seen:
                snippets[n]={'spans':seen,'text':'\n'.join(original[a:b] for a,b in seen)}
                total+=used
        candidates[j]={'requested':name,'queries':queries,'actual_ids':list(snippets),'windows':snippets,'candidate_chars':total,
                       'name_hits':basic,'table_hits':table_ids,'own_first':owned,'other_sources':copy_pool}
        upper[j]=set(snippets)|set(old[str(j)]['with_companions'])
    save(dest/'windows.json',{'names':names,'source_sha256':meta['source_sha256'],'previous':str(previous),'requests':candidates,
           'time_to_build':monotonic()-t+saved['seconds'],'new_terms_cold_seconds':load(S/'generic_name_terms_v1/usage.json')['seconds'],
           'method':'Eight strongest direct-name originals, next original after first three, row-label and account-concept lexical search, related originals already found for any name and prior best driver selections. Interleave sources within 12,400 characters per name and 2,000 per original. Original table rows only (or anchored preview); returning IDs only. No control in discovery.',
           'hash':sha256(Path(__file__).read_bytes()).hexdigest()})
    save(dest/'address_upper_bound.json',grade(co,idx,names,upper))
    print(co,grade(co,idx,names,upper)['kept'],grade(co,idx,names,upper)['checks'],[v['candidate_chars'] for v in candidates.values()],flush=True)

if __name__=='__main__':run(Path(sys.argv[1]),sys.argv[2],Path(sys.argv[3]))
