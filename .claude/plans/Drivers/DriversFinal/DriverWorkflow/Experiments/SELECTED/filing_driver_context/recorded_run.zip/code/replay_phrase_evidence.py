"""Verify the supplementary source excerpts from the two providers' recorded replies."""
from collections import defaultdict
from decimal import Decimal
import json
import re

from scoped_prose import FilingTerms, attach_scope

def check(value, message):
    if not value:raise ValueError(message)

def source_additions(record, cfg, pieces, base, direct, note_roots, phrases, frequency):
    links = record.read('more/links.json')
    protocol = record.read('more/reader/protocol.json')
    check(links['source_sha256']==protocol['source_sha256']==cfg['source_sha256'] and
          links['names']==cfg['names'] and protocol['scope']==list(base), 'Supplement belongs to different inputs')
    check(all(sorted(v)==links['base_ids'][str(j)] for j,v in base.items()), 'Supplement baseline changed')
    proposals = {}
    seen = set()
    by_phrase = defaultdict(set)
    for n, ps in phrases.items():
        for p in ps:
            if frequency[p]==2:by_phrase[p].add(n)
    with FilingTerms(pieces, cfg['names']) as index:
        eligible = set()
        for j, initial in base.items():
            seeds = (initial & direct[j]) | (initial-note_roots[j])
            duplicates = {pieces[str(n)]['text'].strip() for n in initial}
            for seed in seeds:
                for p in phrases.get(seed,()):
                    for n in by_phrase.get(p,()):
                        if n not in initial and index.matches(j,n) and pieces[str(n)]['text'].strip() not in duplicates:
                            eligible.add((j,n))
        for i in range(protocol['jobs']):
            folder = f'more/reader/{i:03d}'
            case = record.read(folder+'/input.json')
            response = record.read(folder+'/raw.json')
            j = case['driver']
            prefix = protocol['rule']+'\nRequested subject: '+cfg['names'][j-1]+'\n'
            check(case['prompt'].startswith(prefix), 'Changed source-reader question')
            candidates = json.loads(case['prompt'][len(prefix):])
            out = response['candidates']
            check(len(out)==1 and out[0]['finish_reason']=='STOP' and
                  response['model_version']==protocol['model'],'Incomplete source reader')
            text = ''.join(p.get('text','') for p in out[0]['content']['parts'] if not p.get('thought'))
            selected = json.loads(re.sub(r'^\s*`{3}(?:json)?\s*|\s*`{3}\s*$','',text))
            check(candidates.keys()==selected.keys()==case['spans'].keys(),'Incomplete original inventory')
            saved = record.read(folder+'/result.json')
            for number, data in candidates.items():
                n=int(number)
                check((j,n) not in seen, 'Repeated supplement candidate')
                seen.add((j,n))
                roots={}
                for a in links['links'][str(j)][number]:
                    if a['filing_frequency']!=2:continue
                    root=a['prior'];p=tuple(a['phrase'])
                    check(root in base[j] and by_phrase[p]=={root,n},'Issuer phrase link differs')
                    roots[str(root)] = pieces[str(root)]['text']
                check(bool(roots) and roots==data['earlier_passages'], 'Unmatched source link')
                spans = case['spans'][number]
                raw = pieces[number]['text']
                lines = [raw[v['a']:v['b']] for v in spans]
                check({str(k):line for k,line in enumerate(lines,1)}==data['candidate_lines'], 'Changed original wording')
                check(''.join(''.join(lines).split())==''.join(raw.split()),'Omitted source line')
                labels = {str(k): k for k in range(1,len(lines)+1)}
                check(isinstance(selected[number],list), 'Invalid line list')
                chosen = [labels.get(k) if type(k) is str else k for k in selected[number]]
                check(all(type(k) is int and 1<=k<=len(spans) for k in chosen) and len(set(chosen))==len(chosen),'Invalid source line')
                support = attach_scope(index,j,lines,chosen)
                check(saved['chosen'][number]==sorted(chosen) and saved['scope_lines'][number]==support,'Source scope differs')
                if chosen:
                    proposals[j,n] = {'roots':list(map(int,roots)),'spans':[
                        {'a':spans[k-1]['a'],'b':spans[k-1]['b'],'scope_sentence':k in support} for k in sorted(chosen+support)]}
        check(seen==eligible, 'Whole-filing supplement inventory changed')
    verifier = record.read('more/verify/routing.json')
    answers = record.decisions('more/verify')
    check(set(answers)=={'p'+k for k in verifier['map']},'Missing source confirmation')
    confirmed = {}
    verified = set()
    for key, item in verifier['map'].items():
        j,n=item['driver'],item['original']
        check((j,n) not in verified and (j,n) in proposals,'Unexpected confirmation')
        verified.add((j,n));proposed=proposals[j,n];raw=pieces[str(n)]['text']
        check(proposed['roots']==item['roots'] and item['spans']==[[v['a'],v['b']] for v in proposed['spans']],'Changed candidate evidence')
        request = record.read(f'more/verify/{int(key)-1:03d}.request.json')
        check(request['state']=={'rule':verifier['rule'],'subject':cfg['names'][j-1],
              'earlier_originals':{str(i):pieces[str(i)]['text'] for i in item['roots']}},'Unmatched verifier context')
        instructions='What does this additional source contribute?\n'+'\n'.join(raw[a:b] for a,b in item['spans'])
        check(request['questions']=={'p'+key:{'type':'choice','instructions':instructions,'criteria':verifier['criteria']}},'Unmatched verifier question')
        if answers['p'+key]['choice'] in ('direct','linked'):
            confirmed[j,n]=proposed
    check(verified==proposals.keys(),'Some candidate excerpts lack a recorded decision')
    extra = Decimal(record.tokens['more/verify'])*Decimal(cfg['first_per_million_usd'])/1000000
    return confirmed, extra
