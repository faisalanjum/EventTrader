"""Check candidate originals against particular already-found source statements."""
from collections import defaultdict
from hashlib import sha256
from pathlib import Path
from time import monotonic
import sys
from assign import MODEL,judge_batches,material,save
from grounded_questions import S,PRIOR,load
from full_decision import Budget
from study import grade

RULE=('The quoted source statement has already been found for the requested subject. Does the candidate '
      'original supply a substantive detail about how that statement works, when it applies, or what '
      'qualifies its interpretation? The statement is a lead, not proof that anything else is relevant. '
      'Require an identifiable relationship and preserve the issuer’s scope.')
ROLES={'linked':'The candidate supplies specific evidence that explains or qualifies the quoted statement.',
       'other':'A substantive connection to the source statement is unsupported.'}

def run(dest,co,refs,singletons=None):
    dest.mkdir(exist_ok=False);start=monotonic()
    a=load(refs/'references.json');src=PRIOR/'filings'/f'{co}.json.gz';idx=load(src);pcs=idx['pieces'];names=a['names']
    if sha256(src.read_bytes()).hexdigest()!=a['source_sha256']:raise ValueError('Source changed')
    prior=Path(a['previous'])/co;orig=load(prior/'packets.json');base=load(prior/'score.json');budget=Budget(base['ceiling_usd'])
    guard=load(singletons/'score.json') if singletons else {};excluded=set(guard.get('rejected_indices',[]));budget.spent=base['usd']+guard.get('extra_usd',0)
    window=load(Path(a['windows'])/'windows.json')['requests'];jobs=[];mapping={}
    for key,rows in a['anchors'].items():
        j=int(key)
        if j in excluded:continue
        for n,vs in rows.items():
            qs={};ids=[];source=window[key]['windows'][n]
            if source['text']!='\n'.join(pcs[n]['text'][aa:bb] for aa,bb in source['spans']):raise ValueError('Changed candidate')
            for q in vs:
                m=q['source_id']
                if q['quote']!=pcs[str(m)]['text'][q['a']:q['b']] or m not in orig[key]['selected']:raise ValueError('Unverified reference')
                k=len(mapping)+1;ids.append(k);mapping[k]=[j,int(n),m,q['a'],q['b']]
                qs[f'p{k}']={'type':'choice','instructions':'Does the candidate explain or qualify the following source statement?\n'+q['quote'],'criteria':ROLES}
            jobs.append((1,ids,{'model':MODEL,'state':{'task':RULE,'requested_subject':names[j-1],'candidate_original':source['text']},'questions':qs}))
    save(dest/'plan.json',{'rule':RULE,'choices':ROLES,'reference_source':str(refs),'missing_scope_guard':str(singletons) if singletons else None,'base_usd':budget.spent,'cap':budget.cap,'mapping':mapping,'code_sha256':sha256(Path(__file__).read_bytes()).hexdigest()})
    try:yes=judge_batches(jobs,dest,budget,[1])[1]
    except Exception as e:
        save(dest/'incomplete.json',{'reason':str(e)[:220],'conservative_usd':budget.spent});return
    hits=defaultdict(set)
    for k in yes:
        j,n,*_=mapping[k];hits[j].add(n)
    before={int(j):set(r['with_companions']) for j,r in orig.items()}
    output={j:(set() if j in excluded else b|material(pcs,hits[j],idx['source_structure']['edges'])[0]) for j,b in before.items()}
    save(dest/'deliveries.json',{j:{'added':sorted(v-before[j]),'output':sorted(v)} for j,v in output.items()})
    r={'before':grade(co,idx,names,before),'after':grade(co,idx,names,output),'usd':budget.spent,'extra_usd':budget.spent-base['usd'],'cap':budget.cap,
       'warm_seconds':base['seconds']+a['native_seconds']+monotonic()-start+guard.get('added_seconds',0),'cold_external_name_terms_seconds':a['name_terms_cold_seconds']}
    save(dest/'score.json',r);print(co,r['after']['kept'],r['after']['checks'],r['after']['negative_hits'],r['after']['pairs'],r['usd'],r['warm_seconds'],flush=True)

if __name__=='__main__':run(Path(sys.argv[1]),sys.argv[2],Path(sys.argv[3]),Path(sys.argv[4]) if len(sys.argv)>4 else None)
