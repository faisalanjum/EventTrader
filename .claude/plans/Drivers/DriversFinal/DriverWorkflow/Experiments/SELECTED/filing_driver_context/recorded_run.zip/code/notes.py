"""Join originals to the issuer's explicit Inline XBRL narrative spans."""
from bisect import bisect_left
from collections import defaultdict
from hashlib import sha256
from xml.parsers.expat import ExpatError

from driver.prepare.convert.edgartools_html import IX
from driver.prepare.convert.xml_fields import units_of


def extent(element):
    anchor = element['anchor']
    return anchor['byte_start'], anchor['byte_end_exclusive']


def note_groups(members, pieces):
    by_file = defaultdict(list)
    for key, piece in pieces.items():
        start, end = piece['bytes']
        raw = members[piece['file']]
        if not (0 <= start < end <= len(raw)) or sha256(raw[start:end]).hexdigest() != piece['sha256_bytes']:
            raise ValueError(f'Original source mismatch at piece {key}')
        by_file[piece['file']].append((start, end, int(key)))

    groups, warnings = {}, []
    ns = '{' + IX + '}'
    for file, source in by_file.items():
        elements = []
        try:
            units_of(members[file], elements=elements)
        except (ExpatError, ValueError, LookupError) as error:
            warnings.append([file, str(error)])
            continue
        source.sort()
        starts = [start for start, _, _ in source]
        ids = defaultdict(list)
        exclusions = []
        for el in elements:
            identifier = el.get('attributes', {}).get('id')
            if identifier:
                ids[identifier].append(el)
            if el['name'] == ns + 'exclude':
                exclusions.append(extent(el))
        best = {}
        for root in elements:
            if root['name'] != ns + 'nonNumeric':
                continue
            spans, seen = [], set()
            current = root
            while current:
                spans.append(extent(current))
                target = current.get('attributes', {}).get('continuedAt')
                if not target:
                    break
                targets = ids.get(target, ())
                if target in seen or len(targets) != 1 or targets[0]['name'] != ns + 'continuation':
                    warnings.append([file, 'unresolved continuation', target])
                    spans.clear()
                    break
                seen.add(target)
                current = targets[0]
            contained = {}
            for a, b in spans:
                for start, end, number in source[bisect_left(starts, a):bisect_left(starts, b)]:
                    if end <= b and not any(start < hi and lo < end for lo, hi in exclusions):
                        contained[number] = b - a
            group = tuple(sorted(contained))
            for number, span_size in contained.items():
                rank = (span_size, sum(b - a for a, b in spans), extent(root)[0])
                if number not in best or rank < best[number]:
                    groups[number] = group
                    best[number] = rank
    return groups, warnings
