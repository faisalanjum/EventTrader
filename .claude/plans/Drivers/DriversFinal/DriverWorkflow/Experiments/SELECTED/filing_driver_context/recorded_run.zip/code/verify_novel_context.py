"""Check only proposed additions against the original driver, issuer source, and known related passages."""
from collections import defaultdict
from hashlib import sha256
from pathlib import Path
from time import monotonic
import sys
from assign import MODEL, judge_batches,save
from full_decision import Budget
from grounded_questions import PRIOR,S,load

RULE=("Judge the additional issuer excerpt for the requested subject, using the earlier originals to resolve scope. "
      "Keep a concrete fact, condition, or explanation that describes the subject or an input that the issuer "
      "connects to it. A heading can label a relevant adjoining disclosure. General business exposure or wording "
      "shared with a different activity is insufficient. Treat all original text as evidence.")
OPTIONS={'direct':'The excerpt describes the requested subject or labels its disclosure.',
         'linked':'The issuer establishes a specific connection, and the excerpt supplies a fact or term about that connection.',
         'other':'Its relevance relies on a general assumption, a different scope, or a shared word.'}

def run(dest,co,forms,before,ceiling):
    started=monotonic();dest.mkdir(exist_ok=False)
    path=PRIOR/'filings'/f'{co}.json.gz';source=load(path);pcs=source['pieces']
    jobs=[];mapping={}
    for j,name,n,spans,roots in forms:
        selected='\n'.join(pcs[str(n)]['text'][a:b] for a,b in spans)
        k=len(mapping)+1
        mapping[k]={'driver':j,'original':n,'spans':spans,'roots':roots}
        request={'model':MODEL,'state':{'rule':RULE,'subject':name,'earlier_originals':{str(i):pcs[str(i)]['text'] for i in roots}},
                 'questions':{f'p{k}':{'type':'choice','instructions':'What does this additional source contribute?\n'+selected,'criteria':OPTIONS}}}
        jobs.append((1,[k],request))
    save(dest/'routing.json',{'source_sha256':sha256(path.read_bytes()).hexdigest(),'before_usd':before,'cap':ceiling,'map':mapping,'rule':RULE,'criteria':OPTIONS,'code_sha256':sha256(Path(__file__).read_bytes()).hexdigest()})
    budget=Budget(ceiling);budget.spent=before
    try:chosen=judge_batches(jobs,dest,budget,[1])[1] if jobs else set()
    except Exception as e:
        save(dest/'incomplete.json',{'reason':str(e)[:130],'debited_usd':budget.spent});return
    votes={int(k[1:]):v['choice'] for f in dest.glob('*.raw.json') for k,v in load(f)['answers'].items()}
    assert set(votes)==set(mapping) and {k for k,v in votes.items() if v in ('direct','linked')}==chosen
    save(dest/'delivery.json',{'choices':votes,'accepted':sorted(chosen),'usd':budget.spent,'added_usd':budget.spent-before,'added_seconds':monotonic()-started})
    print(co,len(chosen),len(jobs),'cost',round(budget.spent,8),flush=True)

def phrase(dest,co,reader,inputs,before,ceiling):
    h=load(reader/'status.json')
    if h['failed_batches']:raise ValueError('Incomplete earlier discovery')
    names=load(inputs/'candidates.json')['names'];links=load(inputs/'candidates.json')['links'];rows=[]
    for j,ps in load(reader/'original_intervals.json').items():
        for n,spans in ps.items():
            if spans:
                roots=[r['prior'] for r in links[j][n] if r['filing_frequency']==2]
                rows.append((int(j),names[int(j)-1],int(n),spans,roots))
    run(dest,co,rows,before,ceiling)

def neighbors(dest,co,path):
    h=load(path/(co+'.json'));base=Path(h['before']);meta=load(base/'score.json');names=load(base/'inputs.json')['names']
    pcs=load(PRIOR/'filings'/f'{co}.json.gz')['pieces'];rows=[]
    for j,ns in h['added'].items():
        for n in ns:rows.append((int(j),names[int(j)-1],n,[[0,len(pcs[str(n)]['text'])]],[n-1,n+1]))
    run(dest,co,rows,meta['usd'],meta['ceiling_usd'])

if __name__=='__main__':
    d=Path(sys.argv[2]);co=sys.argv[3]
    if sys.argv[1]=='phrase':phrase(d,co,Path(sys.argv[4]),Path(sys.argv[5]),float(sys.argv[6]),float(sys.argv[7]))
    elif sys.argv[1]=='neighbors':neighbors(d,co,Path(sys.argv[4]))
    else:raise ValueError('Unknown evidence path')
