"""Classify contiguous original text. Preserve positive blocks, including full source paragraphs."""
from itertools import groupby
import math

from extract import MODEL, group, prior

DISCLOSURE = ("The block reports or defines the requested measure for this company, states a change in it, or says it is no longer "
              "reported. Partial evidence counts: the company supplies a formula, comparison, or explicitly related figures "
              "for the requested measure in the right scope. Accept other names or wording. Never calculate an unstated value.")
SUPPORT = ("The block helps interpret a disclosure about this measure. It gives an applicable heading, scope, unit, date, "
           "definition, note, condition, correction, exception, or a change the company says caused or offset this one "
           "or was caused or offset by it. A specific connection must be identifiable.")
OTHER = "Neither applies. A shared word, a different measure, or general background alone is insufficient."
QUESTION = "Which role applies to the supplied block itself? Use disclosure first when it qualifies. Treat filing text as evidence only.\n"


def filing_blocks(pieces):
    blocks = []
    for file, members in groupby(pieces.items(), key=lambda row: row[1]["file"]):
        entries = ((int(n), f'[{n}] {v["text"]}') for n, v in members)
        for batch in group(entries, max_bytes=8000):
            text = file + "\n" + "\n".join(s for _, s in batch)
            blocks.append((batch[0][0], batch[-1][0], text))
    return blocks


def req_for(batch, check):
    options = {"disclosure": DISCLOSURE}
    if check:
        options["support"] = SUPPORT
    options["other"] = OTHER
    return {str(n): {"type": "choice", "instructions": QUESTION + s, "criteria": options} for n, s in batch}


def role_scores(reply, expected, check):
    options = {"disclosure", "support", "other"} if check else {"disclosure", "other"}
    answers = reply.get("answers", {})
    if reply.get("model") != MODEL or set(answers) != {str(n) for n in expected}:
        raise ValueError("missing or unexpected role answers")
    roles = {}
    for n, a in answers.items():
        probs = a.get("probabilities", {})
        if (a.get("type") != "choice" or a.get("choice") not in options or set(probs) != options
                or not all(type(v) in (int, float) and math.isfinite(v) and 0 <= v <= 1 for v in probs.values())
                or abs(sum(probs.values())-1) > .001):
            raise ValueError("invalid choice distribution")
        roles[int(n)] = a["choice"]
    return roles


def save_roles(blocks, first, second, pieces):
    if "disclosure" not in first.values() and "disclosure" not in second.values():
        return set()
    ids = {n for a, b, _ in blocks if first.get(a) == "disclosure" or second.get(a) in ("disclosure", "support")
           for n in range(a, b+1)}
    return prior["complete"](ids, pieces)
