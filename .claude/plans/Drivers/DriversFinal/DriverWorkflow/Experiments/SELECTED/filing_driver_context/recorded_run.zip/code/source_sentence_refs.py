"""Rank verbatim statements about a subject as possible reading references for another original."""
from hashlib import sha256
from pathlib import Path
from time import monotonic
import json,re,sys
from edgar.search.textsearch import BM25Search
from claude_trial import EX,PRIOR,OUT,load
sys.path.insert(0,str(EX/'2026-11-15_decider_guidance/experiment/vendor'))
import pysbd

def run(dest,co,windows):
    dest.mkdir(exist_ok=False);start=monotonic()
    source=PRIOR/'filings'/f'{co}.json.gz';idx=load(source);pcs=idx['pieces'];w=load(windows/'windows.json')
    if w['source_sha256']!=sha256(source.read_bytes()).hexdigest():raise ValueError('Different source file')
    previous=Path(w['previous'])/co;original=load(previous/'packets.json')
    seg=pysbd.Segmenter(language='en',clean=False,char_span=True);cache={};pairs={}
    for j,base in original.items():
        phrases=[]
        for n in base['selected']:
            p=pcs[str(n)];s=p['text']
            if n not in cache:
                if p['kind']=='table':
                    ms=list(re.finditer(r'(?m)^r\d+: (?=\[c\d)',s))
                    boundaries=[(m.start(),ms[i+1].start() if i+1<len(ms) else len(s)) for i,m in enumerate(ms)] or [(0,len(s))]
                else:boundaries=[(v.start,v.end) for v in seg.segment(s)]
                cache[n]=[(n,a,b,s[a:b]) for a,b in boundaries if s[a:b].strip()]
            phrases.extend(cache[n])
        source_index=BM25Search([row[3] for row in phrases]) if phrases else None;res={}
        for n in sorted(set(w['requests'][j]['actual_ids'])-set(base['with_companions'])):
            if not source_index:continue
            q=w['requests'][j]['windows'][str(n)]['text']
            ranked=sorted(source_index.search(q).sections,key=lambda h:(-h.score,h.loc));picked=[];used=set()
            for h in ranked:
                m,a,b,quote=phrases[h.loc]
                if m==n or m in used or len(quote)>2400:continue
                picked.append({'source_id':m,'a':a,'b':b,'quote':quote,'lexical_score':h.score});used.add(m)
                if len(picked)==3:break
            if picked:res[n]=picked
        pairs[j]=res
    report={'names':w['names'],'source_sha256':w['source_sha256'],'anchors':pairs,'previous':w['previous'],'windows':str(windows),
      'native_seconds':monotonic()-start+w['time_to_build'],'name_terms_cold_seconds':w['new_terms_cold_seconds'],
      'method':'For every previously unseen candidate, use native word search to select up to three original sentences or printed rows, from distinct directly selected original pieces. No generated questions or vector embeddings. No answer key.'}
    (dest/'references.json').write_text(json.dumps(report,ensure_ascii=False,indent=1))
    print(co,sum(len(ys) for ys in pairs.values()),sum(len(v) for ys in pairs.values() for v in ys.values()),flush=True)

if __name__=='__main__':run(Path(sys.argv[1]),sys.argv[2],Path(sys.argv[3]))
