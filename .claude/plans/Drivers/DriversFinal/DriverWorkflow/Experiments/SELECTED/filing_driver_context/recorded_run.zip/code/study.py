"""Offline structural retrieval diagnostic. Gold is accessed only by grade()."""
from datetime import datetime
from pathlib import Path
import json
import statistics
import sys
import time
from zoneinfo import ZoneInfo

from driver.prepare.get.acquire import open_package
from notes import note_groups
from claude_trial import OUT, PRIOR, load


def grade(co, index, names, packets):
    truth = load(PRIOR / 'references' / f'{co}.json')
    if names != truth['names']:
        raise ValueError('References and requests differ')
    checks = [(int(j), f'{j}_{i}', c['alternatives'])
              for j, row in truth['review'].items() for i, c in enumerate(row['checks'])]
    negatives = [(names.index(c['driver']) + 1, c['piece']) for c in load(OUT / 'context_development_controls_v2.json') if c['co'] == co]
    for version, key in [('v2', 'added_checks'), ('v3', 'new_checks'), ('v4', 'new_checks')]:
        path = OUT / f'{co}_context_audit_{version}.json'
        if path.exists():
            audit = load(path)
            checks.extend((c['driver_index'], c['id'], c['alternatives']) for c in audit[key])
            negatives.extend((c['driver_index'], c['piece']) for c in audit.get('new_negative_controls', []))
    checks = [(j, key, alternatives) for j, key, alternatives in checks if j in packets]
    negatives = [(j, n) for j, n in negatives if j in packets]
    missed = [key for j, key, alternatives in checks if not any(set(a) <= packets[j] for a in alternatives)]
    negative_hits = [(j, n) for j, n in set(negatives) if n in packets[j]]
    tagged = [(j, c['any']) for j, cs in truth['tagged'].items() if int(j) in packets for c in cs]
    sizes = {int(i): len(p['text']) for i, p in index['pieces'].items()}
    shares = [sum(sizes[i] for i in ids) / sum(sizes.values()) for ids in packets.values()]
    return {'kept': len(checks)-len(missed), 'checks': len(checks), 'missed': missed,
            'negative_hits': negative_hits, 'negative_checks': len(set(negatives)), 'pairs': sum(map(len, packets.values())),
            'tagged_kept': sum(not packets[int(j)].isdisjoint(ns) for j, ns in tagged), 'tagged_checks': len(tagged),
            'median_source_share': statistics.median(shares), 'largest_source_share': max(shares)}


def expanded(packets, hints):
    return {j: ids.union(*(hints.get(n, ()) for n in ids)) for j, ids in packets.items()}


def first_pass(co):
    return OUT / ('pairwise_defined_IFF_2' if co == 'IFF' else f'validation_defined_v1_{co}')


def rows_to_packets(score):
    return {j: set(r['expanded_ids']) for j, r in enumerate(score['rows'], 1)}


def audit(dest):
    from reference_support import base_reference
    dest.mkdir(exist_ok=False)
    cohort = load(PRIOR / 'cohort.json')['companies']
    for co in sorted(cohort):
        first = first_pass(co)
        if not (first / 'score.json').exists():
            continue
        started = time.perf_counter()
        protocol, index, refs, _ = base_reference(first)
        _, members = open_package(cohort[co]['version'])
        hints, warnings = note_groups(members, index['pieces'])
        seconds = time.perf_counter() - started
        def sorted_packets(packets):
            return {j: sorted(ids) for j, ids in packets.items()}
        extra = OUT / f'reference_scan_{co}_small_2' / 'score.json'
        sources = {'first': refs}
        if extra.exists():
            sources['second'] = rows_to_packets(load(extra))
        saved = {method: sorted_packets(expanded(packets, hints)) for method, packets in sources.items()}
        # Freeze inputs and structural candidates before looking at expected results.
        (dest / f'{co}_candidates.json').write_text(json.dumps({'issuer_groups': hints, 'packets': saved, 'source_sha256': protocol['source_sha256']}))
        scores = {}
        for method, packets in sources.items():
            for variant, pool in [('seed', packets), ('issuer_note', expanded(packets, hints))]:
                scores[method+'_'+variant] = grade(co, index, protocol['names'], pool)
        report = {'company': co, 'names': len(refs), 'source_pieces': len(index['pieces']),
                  'pieces_with_hint': len(hints), 'warnings': warnings, 'seconds': seconds, 'scores': scores,
                  'time': datetime.now(ZoneInfo('America/Toronto')).isoformat()}
        (dest / f'{co}_report.json').write_text(json.dumps(report, indent=2))
        print(co, len(hints), len(warnings),
              {m: (r['kept'], r['checks'], len(r['negative_hits']), r['pairs']) for m,r in scores.items()}, flush=True)


if __name__ == '__main__':
    audit(Path(sys.argv[1]))
