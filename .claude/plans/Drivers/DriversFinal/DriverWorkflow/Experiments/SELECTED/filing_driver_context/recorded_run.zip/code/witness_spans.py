"""Locate generated quotes in already supplied source intervals, preserving the original bytes."""
from collections import defaultdict
from pathlib import Path
import json,re,sys
from hashlib import sha256
from grounded_questions import S,PRIOR,load
from assign import save

def locate(quote,text,lo=0,hi=None):
    if not isinstance(quote,str):return []
    words=quote.strip().split()
    if not words:return []
    pat=r'\s+'.join(map(re.escape,words))
    return [(lo+m.start(),lo+m.end()) for m in re.finditer(pat,text[lo:hi])]

def resolve(quote,hint,candidates,pcs):
    hits=set()
    for n,spans in candidates.items():
        for lo,hi in spans:
            hits.update((n,a,b) for a,b in locate(quote,pcs[str(n)]['text'],lo,hi))
    claimed=[v for v in hits if type(hint) is int and v[0]==hint or isinstance(hint,str) and str(v[0])==hint]
    if len(claimed)==1:return claimed[0]
    return next(iter(hits)) if len(hits)==1 else None

def build(dest,prior,cos):
    dest.mkdir(exist_ok=False)
    for co in cos:
        qroot=S/f'qualified_{co}_v1';q=load(qroot/'protocol.json');anchors=load(S/f'subject_statements_{co}_v1'/'statements.json')
        rel=load(Path(q['relation'])/'plan.json');refs=load(Path(rel['reference_source'])/'references.json');win=load(Path(refs['windows'])/'windows.json')
        src=PRIOR/'filings'/f'{co}.json.gz';idx=load(src);pcs=idx['pieces'];out=defaultdict(list);reject=[]
        if sha256(src.read_bytes()).hexdigest()!=q['source_sha256']:raise ValueError('Changed original')
        for f in sorted((prior/co).glob('d*/raw.json')):
            j=int(f.parent.name[1:]);inreq=load(f.parent/'request.json');cands=inreq['candidates']
            spans={n:win['requests'][str(j)]['windows'][str(n)]['spans'] for n in cands}
            roots=defaultdict(list)
            for st in anchors['subject_evidence'][str(j)][:4]:roots[st['n']].append([st['a'],st['b']])
            for k,n,ls in q['added_candidates']:
                if k==j and n in cands:
                    for _,v,x,y in ls:roots[v].append([x,y])
            r=load(f);can=r['candidates'][0]
            if can.get('finish_reason')!='STOP':reject.append([j,'incomplete response']);continue
            text=''.join(t.get('text','') for t in can['content']['parts'] if not t.get('thought'))
            try:docs=json.loads(re.sub(r'^\s*\x60{3}(?:json)?\s*|\s*\x60{3}\s*$','',text))['findings']
            except (ValueError,KeyError):reject.append([j,'invalid JSON']);continue
            for w in docs:
                hit=resolve(w.get('candidate_quote'),w.get('id'),spans,pcs)
                matched=sorted({(n,a,b) for n,ls in roots.items() for x,y in ls for a,b in locate(w.get('basis_quote'),pcs[str(n)]['text'],x,y)})
                if not hit or not matched or not isinstance(w.get('connection'),str) or not w['connection'].strip():
                    reject.append([j,w.get('id'),'candidate uniquely located' if hit else 'candidate unverified','basis present' if matched else 'basis unverified']);continue
                n,x,y=hit;out[j].append({'id':n,'model_id':w['id'],'candidate':[n,x,y],'candidate_source':pcs[str(n)]['text'][x:y],'basis':matched,'basis_source':pcs[str(matched[0][0])]['text'][matched[0][1]:matched[0][2]],'connection':w['connection']})
        save(dest/(co+'.json'),{'source_sha256':q['source_sha256'],'cases':out,'rejected':reject,'adjudicator':str(prior),'names':refs['names'],'code_sha256':sha256(Path(__file__).read_bytes()).hexdigest()})
        print(co,[(j,[x['id'] for x in vs]) for j,vs in out.items()],reject,flush=True)
if __name__=='__main__':build(Path(sys.argv[1]),Path(sys.argv[2]),sys.argv[3:])
