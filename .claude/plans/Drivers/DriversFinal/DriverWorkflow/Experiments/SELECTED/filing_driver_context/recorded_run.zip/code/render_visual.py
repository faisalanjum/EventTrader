"""Use native browser printing, verify original embedded JPEGs in the PDF."""
from hashlib import sha256
from pathlib import Path
import sys
import time
from playwright.sync_api import sync_playwright
from pypdf import PdfReader
from PIL import Image
from claude_trial import PRIOR, load
from driver.prepare.get.acquire import open_package
import json


def map_images(pdf,dest,names):
    source={sha256((dest/name).read_bytes()).hexdigest():name for name in names}
    by_pixels={}
    for name in names:
        with Image.open(dest/name) as pic:
            by_pixels[(pic.size,sha256(pic.convert('RGBA').tobytes()).hexdigest())]=name
    original_bytes,original_pixels,converted={},{},{}
    for num,page in enumerate(pdf.pages,1):
        for resource_name,ref in (page['/Resources'].get('/XObject') or {}).items():
            obj=ref.get_object()
            if obj.get('/Subtype')!='/Image':continue
            stream=sha256(obj.get_data()).hexdigest()
            if stream in source:
                original_bytes.setdefault(source[stream],[]).append(num)
                continue
            image=page.images[resource_name].image
            name=by_pixels.get((image.size,sha256(image.convert('RGBA').tobytes()).hexdigest()))
            if name:
                original_pixels.setdefault(name,[]).append(num)
                converted[stream]=name
    if set(original_bytes)|set(original_pixels)!=set(names):raise ValueError('Some originals could not be grounded by bytes or decoded pixels')
    return original_bytes,original_pixels,converted


def render(co, dest):
    started=time.monotonic()
    dest.mkdir(exist_ok=False)
    index=load(PRIOR/'filings'/f'{co}.json.gz')
    _,members=open_package(load(PRIOR/'cohort.json')['companies'][co]['version'])
    images=index['images_omitted']
    files={o['file'] for o in images}
    if len(files)!=1:raise ValueError('Pilot requires one original image-bearing document')
    source=files.pop()
    for path in [source,*[o['src'] for o in images]]:
        if Path(path).name!=path or path not in members:raise ValueError('Unresolved original package member')
        (dest/path).write_bytes(members[path])
    by_sha={sha256(members[o['src']]).hexdigest():o['src'] for o in images}
    pdf=dest/'original_render.pdf'
    with sync_playwright() as p:
        b=p.chromium.launch(executable_path='/usr/bin/google-chrome',headless=True,args=['--no-sandbox'])
        page=b.new_page(java_script_enabled=False,offline=True)
        page.goto((dest/source).as_uri(),wait_until='load')
        page.pdf(path=str(pdf),format='Letter',print_background=True,prefer_css_page_size=True)
        b.close()
    document=PdfReader(pdf)
    found,pixels,converted=map_images(document,dest,by_sha.values())
    all_images={name:sorted(set(found.get(name,[])+pixels.get(name,[]))) for name in by_sha.values()}
    result={'co':co,'source_sha256':sha256(members[source]).hexdigest(),'pdf_sha256':sha256(pdf.read_bytes()).hexdigest(),
            'pages':len(document.pages),'exact_original_jpeg_bytes_on_pages':found,'exact_decoded_pixels_on_pages':pixels,
            'converted_pdf_stream_to_original_file':converted,'source_images_on_pages':all_images,'all_image_pages':sorted({n for pages in all_images.values() for n in pages}),
            'seconds':time.monotonic()-started}
    (dest/'render.json').write_text(json.dumps(result,indent=1))
    print(co,len(document.pages),found,round(result['seconds'],2),flush=True)


if __name__=='__main__':
    base=Path(sys.argv[1])
    for co in sys.argv[2:]:
        render(co,base/f'original_visual_{co}')
