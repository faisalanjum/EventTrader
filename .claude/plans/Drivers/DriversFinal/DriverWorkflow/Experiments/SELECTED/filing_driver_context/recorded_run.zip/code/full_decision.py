"""Full coverage: Decisions selects blocks, cheap Flash-Lite selects source IDs.

Reuses SELECTED's complete original blocks and source-structure closure. All
decision calls share source across names. No key, reference label or score is
used for routing. One ledger caps the complete job at the paid Decider baseline.
"""
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
import hashlib
import json
import math
from pathlib import Path
import sys
from threading import Condition
import time
from zoneinfo import ZoneInfo

from claude_trial import EX, PRIOR, OUT, load
from selection import PROMPT, SCHEMA, selection
sys.path.insert(0,'/tmp/gemini-slicing-sdk-3.6.1')
from google import genai
from google.genai import types

CRITERIA={'reports':'Contains a statement or table about the requested subject.',
    'explains':'Contains a definition, method, condition, qualifier or source-stated connection that explains the requested subject, even without a separate value.',
    'other':'Only a different subject or a superficial word/topic match; no specific relevant context.'}
CAP=.04130152


class Budget:
    def __init__(self,cap=CAP):self.cap=cap;self.spent=0.;self.reserved=0.;self.lock=Condition()
    def reserve(self,bound):
        with self.lock:
            while self.spent+self.reserved+bound>self.cap:
                if self.reserved<=1e-10:raise ValueError('Combined Decider price ceiling reached')
                self.lock.wait(5)
            self.reserved+=bound
    def settle(self,bound,used):
        with self.lock:
            self.reserved-=bound;self.spent+=used;self.lock.notify_all()
            if used>bound or self.spent>self.cap:raise ValueError('Usage exceeded price bound; stop')


def main(label='full_decision_1',co='PANW'):
    from dotenv import dotenv_values
    sys.path.insert(0,str(EX/'2026-11-23_decider_driver_context'))
    from blocks import filing_blocks
    sys.path.insert(0,str(EX/'2026-11-23_decider_evidence_recovery'));from structure import material
    dest=OUT/label;dest.mkdir(exist_ok=False)
    index=load(PRIOR/'filings'/f'{co}.json.gz');spec=load(PRIOR/'cohort.json')['companies'][co]
    names=[r['kpi'] for r in spec['drivers']];blocks=filing_blocks(index['pieces'])
    assert set(n for a,b,_ in blocks for n in range(a,b+1))==set(map(int,index['pieces']))
    batches=[blocks[i:i+8] for i in range(0,len(blocks),8)]
    rule=PROMPT.split('Return original PIECE addresses')[0].split('\n\n',1)[1]
    frozen={'time':datetime.now(ZoneInfo('America/Toronto')).isoformat(),'company':co,'names':names,'blocks':len(blocks),'batches':len(batches),
        'source_sha256':hashlib.sha256((PRIOR/'filings'/f'{co}.json.gz').read_bytes()).hexdigest(),
        'classification_rule':rule,'criteria':CRITERIA,'refinement_prompt':PROMPT,'schema':SCHEMA,
        'selector':'gemini-decision-1','refiner':'gemini-2.5-flash-lite','combined_usd_cap':CAP,'truth_used_for_routing':False,
        'native_library_reuse':'SELECTED filing_blocks and material; google-genai 3.6.1 decisions, count_tokens and generate_content'}
    (dest/'protocol.json').write_text(json.dumps(frozen,indent=2));budget=Budget()
    key=dotenv_values('/tmp/gemini-test.env')['GEMINI_API_KEY']
    def client():return genai.Client(api_key=key,http_options=types.HttpOptions(api_version='v1beta',timeout=120000,retry_options=types.HttpRetryOptions(attempts=1)))
    started=time.monotonic()
    def one(item):
        i,batch=item
        state={'company':spec['company'],'context_selection_rule':rule,'blocks':{str(a):text for a,b,text in batch}}
        qs={f'b{a}_d{j}':{'type':'choice','instructions':f'Which role does text in block {a} have for "{name}" under the supplied context-selection rule?','criteria':CRITERIA}
            for a,b,text in batch for j,name in enumerate(names,1)}
        request={'model':'gemini-decision-1','input':[{'type':'text','text':json.dumps(state,ensure_ascii=False)}],'questions':qs}
        bound=(len(json.dumps(request,ensure_ascii=False).encode())+len(qs)*256+4096)*.10/1e6
        budget.reserve(bound)
        (dest/f'batch_{i:02d}.request.json').write_text(json.dumps(request,ensure_ascii=False,indent=2))
        c=client();t=time.monotonic()
        try:
            raw=c.decisions.create(**request).model_dump(mode='json')
            (dest/f'batch_{i:02d}.raw.json').write_text(json.dumps(raw,indent=2))
            used=(raw.get('usage',{}).get('total_input_tokens') or 0)*.10/1e6
            budget.settle(bound,used)
            answers=raw.get('answers',{})
            if set(answers)!=set(qs):raise ValueError('Missing or unexpected block decisions')
            for a in answers.values():
                probs=a.get('probabilities',{})
                if a.get('type')!='choice' or set(probs)!=set(CRITERIA) or a.get('choice') not in CRITERIA or any(type(p) not in (int,float) or not math.isfinite(p) or not 0<=p<=1 for p in probs.values()):
                    raise ValueError('Invalid block decision')
            print(json.dumps({'batch':i,'seconds':round(time.monotonic()-t,3),'usd':used,'spent_usd':budget.spent}),flush=True)
            return batch,answers
        finally:c.close()
    found={j:set() for j in range(1,len(names)+1)}
    with ThreadPoolExecutor(3) as pool:
        futures=[pool.submit(one,item) for item in enumerate(batches)]
        for f in as_completed(futures):
            batch,answers=f.result()
            for a,b,_ in batch:
                for j in found:
                    if answers[f'b{a}_d{j}']['choice']!='other':found[j].update(range(a,b+1))
    # No model failures or unprocessed source blocks are turned into empty results.
    def grade(ids_by_name,stage):
        ref=load(PRIOR/'references'/f'{co}.json');rows=[]
        for j,name in enumerate(names,1):
            _,ids=material(index['pieces'],set(ids_by_name[j]),index['source_structure']['edges'])
            rr=ref['review'][str(j)]
            missing=[k for k,check in enumerate(rr['checks']) if not any(set(alt)<=ids for alt in check['alternatives'])]
            tags=ref['tagged'].get(str(j),[])
            rows.append({'driver':name,'checks':len(rr['checks']),'missing':missing,'tag_checks':len(tags),
                'missing_tags':[k for k,t in enumerate(tags) if ids.isdisjoint(t['any'])],'reference_status':rr['status'],
                'selected_ids':sorted(ids_by_name[j]),'expanded_ids':sorted(ids),
                'source_share':sum(len(index['pieces'][str(n)]['text']) for n in ids)/sum(len(p['text']) for p in index['pieces'].values())})
        out={'stage':stage,'seconds':time.monotonic()-started,'usd':budget.spent,'rows':rows,
            'kept':sum(r['checks']-len(r['missing']) for r in rows),'checks':sum(r['checks'] for r in rows),
            'false_absent_returns':sum(bool(r['expanded_ids']) for r in rows if r['reference_status']=='absent')}
        (dest/f'{stage}.score.json').write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items() if k!='rows'}),flush=True)
    (dest/'routing.json').write_text(json.dumps({names[j-1]:sorted(v) for j,v in found.items()},indent=2))
    grade(found,'coarse')
    visible=set().union(*found.values())
    pcs={str(n):index['pieces'][str(n)] for n in sorted(visible)}
    source='\n\n'.join(f'PIECE_{n:06d}\n{index["pieces"][str(n)]["text"]}' for n in sorted(visible))
    prompt='<candidate_source>\n'+source+'\n</candidate_source>\n\n'+PROMPT.format(company=spec['company'],names=json.dumps(names))
    c=client()
    try:
        count=c.models.count_tokens(model='gemini-2.5-flash-lite',contents=prompt+'\n'+json.dumps(SCHEMA)).model_dump(mode='json')
        (dest/'refine.count.json').write_text(json.dumps(count,indent=2))
        bound=((count['total_tokens']+1024)*.10+4096*.40)/1e6;budget.reserve(bound)
        (dest/'refine.prompt.txt').write_text(prompt)
        raw=c.models.generate_content(model='gemini-2.5-flash-lite',contents=prompt,config=types.GenerateContentConfig(
            max_output_tokens=4096,response_mime_type='application/json',response_json_schema=SCHEMA,
            thinking_config=types.ThinkingConfig(thinking_budget=0))).model_dump(mode='json')
        (dest/'refine.raw.json').write_text(json.dumps(raw,indent=2))
        u=raw.get('usage_metadata',{});used=((u.get('prompt_token_count') or 0)*.10+((u.get('candidates_token_count') or 0)+(u.get('thoughts_token_count') or 0))*.40)/1e6
        budget.settle(bound,used)
        text=''.join(p.get('text','') for cc in raw.get('candidates',[]) for p in cc.get('content',{}).get('parts',[]))
        answer=selection(json.loads(text),names,pcs);(dest/'answer.json').write_text(json.dumps(answer,indent=2))
        grade({j:set(row['ids']) for j,row in enumerate(answer['results'],1)},'refined')
    finally:c.close()


if __name__=='__main__':main(*sys.argv[1:])
