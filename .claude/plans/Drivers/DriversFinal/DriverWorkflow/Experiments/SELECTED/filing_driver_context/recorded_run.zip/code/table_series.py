"""Test the filing's published numeric series as a separate source of original rows."""
from bisect import bisect_right
from collections import Counter, defaultdict
from datetime import datetime
from decimal import Decimal, InvalidOperation
from hashlib import sha256
from pathlib import Path
from time import monotonic
from zoneinfo import ZoneInfo
import gzip
import json
import sys

from assign import MODEL, judge_batches, save
from claude_trial import OUT, PRIOR, load
from driver.prepare.get.acquire import open_package
from full_decision import Budget
from pairwise_decider import valid

STUDY = OUT/'issuer_notes_study'
RULE = ('Select numeric series that report the requested measure at the requested scope. '
        'Read the company filing’s concept, unit, dimensions and printed labels together. '
        'Allow different wording for the same measure. Related, broader or narrower measures are separate.')
CHOICES = {'direct':'The measure and scope match.', 'other':'The measure or scope differs, or the evidence is insufficient.'}


class Spans:
    def __init__(self, rows):
        self.rows=sorted(rows,key=lambda r:(r[0],r[1]))
        self.starts=[r[0] for r in self.rows]
        self.maxends=[]
        maxend=-1
        for _,end,_ in self.rows:
            maxend=max(maxend,end)
            self.maxends.append(maxend)

    def covering(self,start,end):
        i=bisect_right(self.starts,start)-1
        matches=[]
        while i>=0 and self.maxends[i]>=end:
            a,b,thing=self.rows[i]
            if end<=b:matches.append((b-a,thing))
            i-=1
        matches.sort(key=lambda pair:pair[0])
        if not matches or (len(matches)>1 and matches[1][0]==matches[0][0]):return None
        return matches[0][1]


def inventory(co):
    index=load(PRIOR/'filings'/f'{co}.json.gz')
    spec=load(PRIOR/'cohort.json')['companies'][co]
    _,members=open_package(spec['version'])
    pieces=index['pieces']
    grouped=defaultdict(list)
    for n,p in pieces.items():
        a,b=p['bytes']
        if sha256(members[p['file']][a:b]).hexdigest()!=p['sha256_bytes']:raise ValueError('Source piece changed')
        grouped[p['file']].append((a,b,int(n)))
    data,series_ids,source_rows={},{},{}
    stats=Counter()
    checked_files=set()
    for route_path in sorted((Path('/tmp/selected-decider-production-20261123')/co/'job').glob('attempt_*/ROUTE.json.gz')):
        packed=route_path.read_bytes()
        route=json.loads(gzip.decompress(packed))
        file=route['file_id']
        if (file in checked_files or sha256(packed).hexdigest()!=index['source_structure']['route_sha256'][file]
            or sha256(members[file]).hexdigest()!=route['sha256']):
            raise ValueError('Missing, repeated or changed prepared filing')
        checked_files.add(file)
        spans=Spans(grouped[file])
        units={u['id']:u for u in route['units']}
        table_cells={}
        for _,_,n in grouped[file]:
            p=pieces[str(n)]
            if p['kind']!='table':continue
            cells=units[p['unit']]['cells']
            rows=defaultdict(list)
            locations=[]
            for c in cells:
                if c.get('source'):
                    locations.append((c['source']['byte_start'],c['source']['byte_end_exclusive'],c))
                if c['text'].strip():
                    rows[c['r']].append({k:c[k] for k in ('c','rs','cs','text','source') if k in c})
            table_cells[n]=Spans(locations)
            source_rows.update({(n,r):cells for r,cells in rows.items()})
        sf=route['source_facts']
        if not sf['read']:stats['members_with_unread_tags']+=1
        for item in sf['records']:
            v=item.get('native') or {}; ctx=v.get('context') or {}
            if not v.get('unit') or not v.get('concept'):continue
            stats['numeric_tags']+=1
            if (v.get('metadata') or {}).get('hidden') or not item['element_text'].strip() or str(item['attributes'].get('xsi:nil','')).lower() in ('true','1'):
                stats['hidden_or_empty']+=1;continue
            try:
                if not Decimal(str(v['value'])).is_finite():raise InvalidOperation()
            except (InvalidOperation,KeyError):
                stats['non_number']+=1;continue
            a,b=(item['source_tag'][k] for k in ('byte_start','byte_end_exclusive'))
            n=spans.covering(a,b)
            if n is None:
                stats['unattached_to_visible_original']+=1;continue
            dims=ctx.get('dimensions') or {}
            key=(v['concept'],json.dumps(dims,sort_keys=True),v['unit'],ctx.get('entity'))
            if key not in series_ids:series_ids[key]=len(series_ids)
            sid=series_ids[key]
            bucket=data.setdefault(sid,{'concept':v['concept'],'dimensions':dims,'entity':ctx.get('entity'),
                    'unit':v['unit'],'labels':set(),'observations':[]})
            cell=table_cells[n].covering(a,b) if n in table_cells else None
            row=cell['r'] if cell else None
            display=cell['text'] if cell else item['element_text']
            if row is not None:
                row_cells=source_rows.get((n,row),[])
                if row_cells and row_cells[0]['c']<cell['c']:
                    bucket['labels'].add(row_cells[0]['text'])
            elif n in table_cells:stats['in_table_without_unique_cell']+=1
            observation={'file':file,'piece':n,'row':row,'column':cell['c'] if cell else None,
                'source_tag_bytes':[a,b],'display':display,'start':ctx.get('start_date',''),
                'end':ctx.get('end_date') or ctx.get('instant',''),'value':str(v['value']),
                'scale':v.get('scale'),'sign':v.get('sign'),'source_text':item['element_text']}
            bucket['observations'].append(observation);stats['anchored']+=1
    if checked_files!=set(index['source_structure']['route_sha256']):raise ValueError('Partial source inventory')
    series=[]
    for sid in range(len(data)):
        row=data[sid]
        row['labels']=sorted(row['labels'],key=lambda s:(len(s),s))
        series.append(row)
    return {'series':series,'rows':source_rows,'stats':dict(stats),'issuer':str(spec['cik'])}


def make_jobs(series,names,issuer,limit=150,model=MODEL):
    jobs=[];mapping={}
    pairs=[(j,s) for s in range(len(series)) for j in range(1,len(names)+1)]
    for start in range(0,len(pairs),limit):
        group=pairs[start:start+limit];questions={};descriptions={}
        numbers=[]
        for j,k in group:
            s=series[k]
            descriptions[str(k)]={key:s[key] for key in ('concept','dimensions','unit','entity')}
            descriptions[str(k)]['printed_labels']=[text[:140] for text in s['labels'][:3]]
            serial=len(mapping)+1
            mapping[serial]=(j,k);numbers.append(serial)
            questions[f'p{serial}']={'type':'choice','instructions':f'Does series {k} report "{names[j-1]}"?','criteria':CHOICES}
        jobs.append((1,numbers,{'model':model,'state':{'task':RULE,'filing_issuer':issuer,'series':descriptions},'questions':questions}))
    if len(mapping)!=len(series)*len(names):raise ValueError('Incomplete request inventory')
    return jobs,mapping


def evidence_for(data,ids):
    out=[]
    for sid in sorted(ids):
        s=data['series'][sid]
        for o in s['observations']:
            out.append({**o,'concept':s['concept'],'dimensions':s['dimensions'],'unit':s['unit'],
                        'entity':s['entity'],'row_text':data['rows'].get((o['piece'],o['row']),[])})
    return out


def complete_from_receipts(jobs,mapping,earlier,dest,budget):
    accepted=set();missing=[]
    total=budget.spent
    for i,(_,numbers,req) in enumerate(jobs):
        output=earlier/f'{i:03d}.raw.json';given=earlier/f'{i:03d}.request.json'
        if not output.exists():
            if given.exists():raise ValueError('Unsettled external request')
            missing.append((numbers,req))
            continue
        if req!=load(given):raise ValueError('Cached question or input changed')
        raw=load(output);answers=valid(raw,req['questions'],CHOICES)
        if raw['model']!=MODEL:raise ValueError('Cached model changed')
        total+=raw['usage']['input_tokens']*.02/1e6
        accepted.update(n for n in numbers if answers[f'p{n}']['choice']=='direct')
    old=load(earlier/'incomplete.json')['conservative_total_usd']
    if abs(total-old)>1e-8:raise ValueError('Unknown cost or invalid receipt inventory')
    budget.spent=old
    billed=used=0
    pending=list(reversed(missing))
    while pending:
        numbers,base=pending.pop()
        series={str(mapping[n][1]) for n in numbers}
        req={**base,'state':{**base['state'],'series':{s:v for s,v in base['state']['series'].items() if s in series}},
             'questions':{f'p{n}':base['questions'][f'p{n}'] for n in numbers}}
        bound=(len(json.dumps(req,ensure_ascii=False).encode())+256*len(numbers)+4096)*.02/1e6
        if budget.spent+bound>budget.cap and len(numbers)>1:
            mid=len(numbers)//2
            pending.extend([(numbers[mid:],base),(numbers[:mid],base)])
            continue
        chunk=dest/f'completion_{billed:03d}';chunk.mkdir()
        accepted.update(judge_batches([(1,numbers,req)],chunk,budget,[1])[1])
        billed+=1;used+=len(numbers)
    save(dest/'replay.json',{'from':str(earlier),'unchanged_cached_jobs':len(jobs)-len(missing),
                              'remaining_questions_completed':used,'new_requests':billed})
    return accepted


def run(dest,companies,text_root=None,partial_root=None,reader_model=MODEL):
    dest.mkdir(exist_ok=False)
    rate={MODEL:.02,'pplx-decider-flash-v1.3':.01}[reader_model]
    if partial_root and reader_model!=MODEL:raise ValueError('Model mismatch for cached receipts')
    save(dest/'protocol.json',{'rule':RULE,'choices':CHOICES,'companies':companies,'reader_model':reader_model,'usd_per_million':rate,'starting_time':datetime.now(ZoneInfo('America/Toronto')).isoformat(),
         'method':'All visible original tagged series in the whole filing; direct meaning and scope only. No expected answers used to select. Deliver original row cells with typed periods, source bytes and units.',
         'baseline':'Same complete ten-name text method plus this extra pass, guarded by the original ten-name paid cost.','code_sha256':sha256(Path(__file__).read_bytes()).hexdigest()})
    for co in companies:
        folder=dest/co;folder.mkdir()
        original=(text_root or STUDY/'layout_ten_v1')/co
        prior=load(original/'score.json')
        names=load(original/'inputs.json')['names']
        budget=Budget(prior['ceiling_usd']);budget.spent=prior['usd']
        started=monotonic()
        data=inventory(co)
        jobs,mapping=make_jobs(data['series'],names,data['issuer'],model=reader_model)
        save(folder/'inventory.json',{'names':names,'series':[{k:v for k,v in s.items() if k!='observations'} for s in data['series']],
             'source_stats':data['stats'],'questions':len(mapping),'jobs':len(jobs),'prior_usd':prior['usd'],'usd_ceiling':budget.cap})
        try:
            selected=complete_from_receipts(jobs,mapping,partial_root/co,folder,budget) if partial_root else judge_batches(jobs,folder,budget,[1],reader_model,rate)[1]
        except Exception as err:
            save(folder/'incomplete.json',{'error':type(err).__name__,'seconds':monotonic()-started,'conservative_total_usd':budget.spent})
            print(co,'incomplete',type(err).__name__,budget.spent,flush=True);continue
        by_name={j:[] for j in range(1,len(names)+1)}
        for serial in sorted(selected):
            j,sid=mapping[serial];by_name[j].append(sid)
        packets={j:evidence_for(data,ids) for j,ids in by_name.items()}
        (folder/'observations.json.gz').write_bytes(gzip.compress(json.dumps(packets,ensure_ascii=False).encode()))
        save(folder/'selected_series.json',by_name)
        elapsed=monotonic()-started
        ref=load(PRIOR/'references'/f'{co}.json')
        originals=load(original/'packets.json')
        def signature(o):return json.dumps([o['concept'],sorted(o['dimensions'].items()),o['start'],o['end'],o['unit'],o['value']])
        recovered,old,additional,total=0,0,0,0
        for j,controls in ref['tagged'].items():
            got={signature(o) for o in packets[int(j)]}
            pieces=set(originals[j]['with_companions'])
            for c in controls:
                before=not pieces.isdisjoint(c['any']); now=json.dumps(c['fact']) in got
                recovered+=now; old+=before; additional+=not before and now;total+=1
        score={'previous_tagged_piece_hits':old,'tagged_checks':total,'new_exact_fact_hits_alone':recovered,'new_previously_missing':additional,
               'combined':old+additional,'usd':budget.spent,'new_usd':budget.spent-prior['usd'],'ceiling_usd':budget.cap,
               'new_seconds':elapsed,'prior_seconds':prior['seconds'],'series_selected':{j:len(v) for j,v in by_name.items()}}
        save(folder/'score.json',score)
        print(co,json.dumps(score),flush=True)


if __name__=='__main__': run(Path(sys.argv[1]),sys.argv[2:])
