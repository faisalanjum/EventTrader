"""Look for the filing's own uncommon phrases in passages linked by its reporting notes."""
from collections import defaultdict,Counter
from contextlib import closing
from pathlib import Path
from hashlib import sha256
from math import ceil
from time import monotonic
import sqlite3,sys
from assign import save
from grounded_questions import PRIOR,S,load
from study import grade

def run(dest,co,base,full,screen,controls):
    dest.mkdir(exist_ok=False);t=monotonic();src=PRIOR/'filings'/f'{co}.json.gz';idx=load(src);pcs=idx['pieces'];orig=load(base/co/'packets.json')
    final={int(j):set(v) for j,v in load(full/'delivery.json').items()};meta=load(base/co/'inputs.json');sc=load(screen/'results.json');names=meta['names']
    small={int(j):set(v) for j,v in sc['any_prior_support']['kept'].items()};tokens=defaultdict(list)
    with closing(sqlite3.connect(':memory:')) as db:
        db.execute("CREATE VIRTUAL TABLE sections USING fts5(body,tokenize='unicode61')");db.execute("CREATE VIRTUAL TABLE terms USING fts5vocab(sections,instance)")
        db.executemany('INSERT INTO sections(rowid,body) VALUES(?,?)',((int(n),p['text']) for n,p in pcs.items()))
        for n,word in db.execute('SELECT doc,term FROM terms ORDER BY doc,offset'):tokens[n].append(word)
    result={};limits=[4,6,8];num_docs=len(pcs)
    for length in limits:
        index={n:{tuple(ws[k:k+length]) for k in range(len(ws)-length+1)} for n,ws in tokens.items()}
        df=Counter(s for vs in index.values() for s in vs)
        for sources in ['independent_additions','all_primary']:
            output={j:set(ns) for j,ns in small.items()};proven={}
            for j,ns in final.items():
                roots=ns-set(orig[str(j)]['with_companions'])
                if sources=='all_primary':roots|=ns&set(orig[str(j)]['selected'])
                phrases=defaultdict(set)
                for n in roots:
                    for phrase in index.get(n,()):
                        if df[phrase]<=max(2,ceil(num_docs*.01)):phrases[phrase].add(n)
                for n in sorted(ns-small[j]):
                    shared=set(index.get(n,()))&phrases.keys()
                    if not shared:continue
                    q=min(shared,key=lambda s:(df[s],s))
                    output[j].add(n);proven[f'{j}/{n}']={'shared_words':q,'source_ids':sorted(phrases[q]),'filing_frequency':df[q]}
            checks=[{**c,'pass':(c['n'] in output[c['j']])==c['keep']} for c in load(controls)]
            g=grade(co,idx,names,output);key=sources+'_'+str(length)
            rows={j:sorted(v) for j,v in output.items()};total=sum(len(pcs[str(n)]['text']) for ns in output.values() for n in ns)
            result[key]={'grade':g,'checks':checks,'passed':sum(c['pass'] for c in checks),'chars':total,'kept':rows,'new_shared_phrases':proven,'usd':load(full/'score.json')['usd']}
            print(key,g['kept'],g['pairs'],result[key]['passed'],len(checks),total,flush=True)
    save(dest/'results.json',result)
    save(dest/'protocol.json',{'code_hash':sha256(Path(__file__).read_bytes()).hexdigest(),'source_sha256':sha256(src.read_bytes()).hexdigest(),'elapsed_s':monotonic()-t,'verified_new_evidence':str(full),'screen':str(screen),'shared_phrase_lengths_tested':limits,'rare_limit':'At most 1% of originals, rounded up, with a minimum of two. All operating points shown; development only.'})
if __name__=='__main__':run(Path(sys.argv[1]),sys.argv[2],*map(Path,sys.argv[3:7]))
