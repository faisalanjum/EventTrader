"""Join adjacent original legend swatches to verified chart pixels, independent of driver names."""
from collections import defaultdict
from hashlib import sha256
from itertools import groupby
from pathlib import Path
from time import monotonic
import re,sys
from lxml import html
from PIL import Image
import tinycss2
from tinycss2.color3 import parse_color
from assign import save
from claude_trial import PRIOR,load
from driver.prepare.get.acquire import open_package
from grounded_questions import S

MARK=re.compile(r'(\([0-9A-Za-z]{1,3}\)|[†‡*]+)$')

def swatch(markup):
    td=html.fromstring(markup)
    declarations=tinycss2.parse_declaration_list(td.get('style',''),skip_comments=True,skip_whitespace=True)
    color=next((tinycss2.serialize(d.value).strip() for d in reversed(declarations)
                if d.type=='declaration' and d.lower_name=='background-color'),td.get('bgcolor'))
    parsed=parse_color(color) if color else None
    if parsed is None or isinstance(parsed,str) or parsed.alpha!=1:return None
    return tuple(round(x*255) for x in parsed[:3])

def pixel_matches(histograms,color):
    winners=[]
    for name,(pixels,total) in histograms.items():
        matches=sum(n for n,rgb in pixels if rgb[3]==255 and max(abs(a-b) for a,b in zip(color,rgb[:3]))<=8)
        if matches>=max(2,total*.001):
            winners.append((name,matches))
    return winners

def read(co):
    start=monotonic();source_path=PRIOR/'filings'/f'{co}.json.gz';index=load(source_path)
    spec=load(PRIOR/'cohort.json')['companies'][co];_,members=open_package(spec['version'])
    original={(p['file'],p['unit']):(int(n),p) for n,p in index['pieces'].items()}
    images={x['src']:[] for x in index['images_omitted']};hist={};ambiguous=[]
    for rp in sorted((Path('/tmp/selected-decider-production-20261123')/co/'job').glob('attempt_*/ROUTE.json.gz')):
        route=load(rp);file=route['file_id']
        if not any(x['file']==file for x in index['images_omitted']):continue
        if sha256(rp.read_bytes()).hexdigest()!=index['source_structure']['route_sha256'][file] or sha256(members[file]).hexdigest()!=route['sha256']:raise ValueError('Source changed')
        data=members[file];units=route['units']
        for is_image,seq in groupby(enumerate(units),key=lambda entry:entry[1]['kind']=='image'):
            group=list(seq)
            if not is_image:continue
            names={u['src'] for _,u in group};start_idx=group[0][0];end_idx=group[-1][0]+1
            for table_idx in (start_idx-1,end_idx):
                if not 0<=table_idx<len(units) or units[table_idx]['kind']!='table':continue
                table=units[table_idx];table_id,_=original[(file,table['id'])]
                notes=defaultdict(list)
                for u in units[table_idx+1:]:
                    if u['kind'] in ('table','image'):break
                    if (file,u['id']) not in original:continue
                    n,p=original[(file,u['id'])];m=re.match(r'^\s*(\([0-9A-Za-z]{1,3}\)|[†‡*]+)',p['text'])
                    if m:notes[m.group(1)].append(n)
                for _,cells in groupby(table['cells'],key=lambda c:c['r']):
                    row=list(cells)
                    for cell,label in zip(row,row[1:]):
                        if cell['text'].strip() or not label['text'].strip() or not cell.get('source') or not label.get('source'):continue
                        a=cell['source'];raw=data[a['byte_start']:a['byte_end_exclusive']]
                        color=swatch(raw)
                        ref=label['source'];a,b=ref['byte_start'],ref['byte_end_exclusive']
                        if color is None or swatch(data[a:b])==color:continue
                        from io import BytesIO
                        for name in names:
                            if name not in hist:
                                with Image.open(BytesIO(members[name])) as im:
                                    im=im.convert('RGBA');total=im.width*im.height;hist[name]=(im.getcolors(total),total)
                        winners=pixel_matches({n:hist[n] for n in names},color)
                        if len(winners)!=1:
                            ambiguous.append({'legend':table_id,'label':label['text'],'candidate_images':[n for n,_ in winners]});continue
                        name,count=winners[0];marker=MARK.search(label['text'].strip())
                        matches=notes.get(marker.group(1),[]) if marker else []
                        images[name].append({'label':label['text'],'table_id':table_id,'row':label['r'],'column':label['c'],
                                'filing_file':file,'label_bytes':[a,b],'label_bytes_sha256':sha256(data[a:b]).hexdigest(),
                                'rgb':color,'matching_pixels':count,'note_ids':matches if len(matches)==1 else []})
    return {'source_sha256':sha256(source_path.read_bytes()).hexdigest(),'images':images,'unresolved':ambiguous,'seconds':monotonic()-start}

if __name__=='__main__':
    dest=Path(sys.argv[1]);dest.mkdir(exist_ok=False)
    save(dest/'protocol.json',{'method':'Consecutive original image groups. Only immediately adjacent native source tables. Empty source cell with inline issuer swatch beside its original label. Native CSS parser and Pillow histogram. At least 0.1 percent opaque pixels within 8 levels per channel, one unique image within that group. Ambiguous/unmarked material remains available visually. Carry uniquely numbered original notes before the next chart or table.',
        'source':sha256(Path(__file__).read_bytes()).hexdigest()})
    for co in sys.argv[2:]:
        r=read(co);save(dest/(co+'.json'),r);print(co,{k:[(x['label'],x['note_ids']) for x in v] for k,v in r['images'].items() if v},round(r['seconds'],3),flush=True)
