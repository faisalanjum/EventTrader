"""Whole-source reference-conditioned scan, then exact original-piece selection.

Uses native Decider questions, existing source blocks and structural closure.
References are unapproved first-pass source passages, never expected answers.
"""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
import hashlib
import json
import re
import sys
import time
from zoneinfo import ZoneInfo
from reference_support import ROOT,EX,PRIOR,OUT,load,base_reference,question,RULE,ROLES
from pairwise_decider import baseline_cap,valid
from full_decision import Budget


def accepted(answer):
    p=answer['probabilities']
    return p['context']+p['uncertain']>=p['unrelated']


def saved_cost(dest):
    completed=sum(load(f)['usage']['input_tokens']*.02/1e6 for f in dest.glob('*.raw.json'))
    failures=list(dest.glob('*.error.json'))+list(dest.glob('*.failure_*.json'))
    return completed+sum(load(f).get('charged_bound') or 0 for f in failures)


def coarse_jobs(index,names,state):
    sys.path.insert(0,str(EX/'2026-11-23_decider_driver_context'))
    from blocks import filing_blocks
    blocks=filing_blocks(index['pieces'])
    covered=[n for a,b,_ in blocks for n in range(a,b+1)]
    if covered!=list(map(int,index['pieces'])):raise ValueError('Incomplete/duplicate whole-source block coverage')
    jobs=[]
    for start in range(0,len(blocks),4):
        batch=blocks[start:start+4]
        qs={f'b{a}_d{j}':{'type':'choice','instructions':f'Does any part of candidate block {a} provide reading context for "{name}" under context_rule and that topic\'s assigned references? Inspect that block, not other candidate blocks.','criteria':ROLES}
            for a,b,text in batch for j,name in enumerate(names,1)}
        jobs.append({'model':'pplx-decider-v1.3','state':{**state,'candidate_blocks':{str(a):text for a,b,text in batch}},'questions':qs})
    return blocks,jobs


def refinement_jobs(index,names,refs,state,blocks,answers):
    expected={f'b{a}_d{j}' for a,b,_ in blocks for j in refs}
    if set(answers)!=expected:raise ValueError('Incomplete block/name decisions')
    pairs={(n,j) for j,ids in refs.items() for n in ids}
    pairs.update((n,j) for a,b,_ in blocks for j in refs if accepted(answers[f'b{a}_d{j}']) for n in range(a,b+1))
    jobs=[]
    for j,name in enumerate(names,1):
        own={**state,'reference_ids':{name:sorted(refs[j])},'reference_passages':{str(n):index['pieces'][str(n)]['text'] for n in sorted(refs[j])}}
        ordered=sorted(n for n,k in pairs if k==j)
        for start in range(0,len(ordered),25):
            qs={f'p{n}_d{j}':question(name,n,index['pieces'][str(n)]['text']) for n in ordered[start:start+25]}
            jobs.append({'model':'pplx-decider-v1.3','state':own,'questions':qs})
    return pairs,jobs


def main(first_label,label,resume=False):
    from dotenv import dotenv_values
    from ratelimit import limits,sleep_and_retry
    from urllib3.util import Retry
    sys.path.insert(0,str(EX/'2026-11-23_decider_driver_context'));from lookup import make_client
    sys.path.insert(0,str(EX/'2026-11-23_decider_evidence_recovery'));from structure import material
    sys.path.insert(0,str(ROOT));from driver.prepare.get.acquire import open_package
    first=OUT/first_label;proto,index,refs,state=base_reference(first);co=proto['company'];names=proto['names']
    spec=load(PRIOR/'cohort.json')['companies'][co];_,members=open_package(spec['version'])
    for p in index['pieces'].values():
        a,b=p['bytes']
        if hashlib.sha256(members[p['file']][a:b]).hexdigest()!=p['sha256_bytes']:raise ValueError('Original source-byte drift')
    blocks,jobs=coarse_jobs(index,names,state);dest=OUT/label;dest.mkdir(exist_ok=resume)
    prior=load(first/'score.json');cap=baseline_cap(co);budget=Budget(cap);budget.spent=prior['usd']
    freeze={'time':datetime.now(ZoneInfo('America/Toronto')).isoformat(),'company':co,'names':names,'source_sha256':proto['source_sha256'],
        'first_pass':str(first),'first_pass_usd':prior['usd'],'first_pass_seconds':prior['seconds'],'combined_usd_cap':cap,
        'rule':RULE,'criteria':ROLES,'selection':'Coarse candidates: P(context)+P(uncertain)>=P(unrelated). Final: native choice context or uncertain; reject unrelated. No fitted cutoff.',
        'coverage':'Every source block judged for every name. Review all first-pass originals and model-routed pieces, per-name references only; no unconditional seed carry-through.',
        'coarse_blocks_per_request':4,'fine_questions_per_request':25,
        'truth_in_routing':False,'native_reuse':['filing_blocks','structure.material','lookup.make_client','Budget','native v1/decisions choice'],
        'code_sha256':{f:hashlib.sha256((OUT/f).read_bytes()).hexdigest() for f in ('reference_scan.py','reference_support.py')},'blocks':len(blocks)}
    if resume:
        saved=load(dest/'protocol.json')
        if {k:v for k,v in saved.items() if k not in ('time','code_sha256')}!={k:v for k,v in freeze.items() if k not in ('time','code_sha256')}:raise ValueError('Resume changes frozen experiment')
        if saved['code_sha256']!=freeze['code_sha256']:
            (dest/'resume_accounting_amendment.json').write_text(json.dumps({'time':freeze['time'],'change':'Account for unknown costs of earlier HTTP504 failures and retain immutable failure receipts. Identical model inputs, decisions and coverage; reuse completed calls.','old_code_sha256':saved['code_sha256'],'new_code_sha256':freeze['code_sha256']},indent=2))
        budget.spent+=saved_cost(dest)
    else:(dest/'protocol.json').write_text(json.dumps(freeze,indent=2))
    key=dotenv_values(ROOT/'.env')['PERPLEXITY_API_KEY']
    @sleep_and_retry
    @limits(calls=1,period=.105)
    def post(c,request):return c.post('https://api.perplexity.ai/v1/decisions',json=request,timeout=(15,120))
    def one(item):
        name,request=item;path=dest/f'{name}.raw.json';rp=dest/f'{name}.request.json'
        if path.exists():
            if load(rp)!=request:raise ValueError('Saved request drift')
            return valid(load(path),request['questions'],ROLES)
        bound=(len(json.dumps(request,ensure_ascii=False).encode())+len(request['questions'])*256+4096)*.02/1e6
        try:
            history=[p for p in [dest/f'{name}.error.json',*dest.glob(name+'.failure_*.json')] if p.exists()]
            if sum('504' in load(p).get('message','') for p in history)>=2:raise ValueError('Repeated transport timeout: partition unsent work')
            budget.reserve(bound)
        except ValueError:
            # Divide only unsent transport work; never drop source or a question.
            items=list(request['questions'].items())
            if len(items)<2:raise
            result={}
            for suffix,part in (('a',items[:len(items)//2]),('b',items[len(items)//2:])):
                child={**request,'questions':dict(part)}
                if 'candidate_blocks' in request['state']:
                    ids={re.fullmatch(r'b(\d+)_d\d+',q)[1] for q,_ in part}
                    child['state']={**request['state'],'candidate_blocks':{n:request['state']['candidate_blocks'][n] for n in ids}}
                result.update(one((name+suffix,child)))
            return result
        rp.write_text(json.dumps(request,ensure_ascii=False,indent=2));c=make_client(key);c.adapters['https://'].max_retries=Retry(total=0);settled=False;t=time.monotonic()
        try:
            response=post(c,request);response.raise_for_status();raw=response.json();path.write_text(json.dumps(raw,indent=2))
            used=raw['usage']['input_tokens']*.02/1e6;settled=True;budget.settle(bound,used)
            result=valid(raw,request['questions'],ROLES)
            print(json.dumps({'batch':name,'seconds':round(time.monotonic()-t,2),'questions':len(result),'combined_usd':budget.spent}),flush=True)
            return result
        except Exception as e:
            if not settled:budget.settle(bound,bound)
            failure=dest/f'{name}.failure_{len(list(dest.glob(name+".failure_*.json"))):03d}.json'
            failure.write_text(json.dumps({'error':type(e).__name__,'message':str(e).replace(key,'[redacted]'),'charged_bound':None if settled else bound}))
            raise
        finally:c.close()
    started=time.monotonic()
    def stage(label,requests):
        merged={}
        with ThreadPoolExecutor(4) as pool:
            for reply in pool.map(one,[(f'{label}_{i:03d}',req) for i,req in enumerate(requests)]):
                if merged.keys()&reply.keys():raise ValueError('Duplicate judgment')
                merged.update(reply)
        if set(merged)!={q for req in requests for q in req['questions']}:raise ValueError('Incomplete judgment stage')
        (dest/f'{label}_answers.json').write_text(json.dumps(merged,indent=2));return merged
    coarse=stage('coarse',jobs);pairs,fine=refinement_jobs(index,names,refs,state,blocks,coarse)
    (dest/'routing.json').write_text(json.dumps({'pairs':sorted(pairs),'fine_requests':len(fine),'combined_usd_before_fine':budget.spent},indent=2))
    print(json.dumps({'stage':'coarse_complete','refinement_pairs':len(pairs),'combined_usd':budget.spent}),flush=True)
    answer=stage('fine',fine);chosen={j:set() for j in refs}
    for q,a in answer.items():
        n,j=map(int,re.fullmatch(r'p(\d+)_d(\d+)',q).groups())
        if a['choice']!='unrelated':chosen[j].add(n)
    expanded={j:material(index['pieces'],ids,index['source_structure']['edges'])[1] for j,ids in chosen.items()}
    # Only now read hidden development checks; never use them to repair selections.
    truth=load(PRIOR/'references'/f'{co}.json');audit=OUT/f'{co}_context_audit_v2.json';add=load(audit)['added_checks'] if audit.exists() else []
    missing=[{'driver_index':int(j),'check':k} for j,r in truth['review'].items() for k,c in enumerate(r['checks']) if not any(set(a)<=expanded[int(j)] for a in c['alternatives'])]
    added_missed=[c['id'] for c in add if not any(set(a)<=expanded[c['driver_index']] for a in c['alternatives'])]
    total=sum(len(r['checks']) for r in truth['review'].values())+len(add);size=sum(len(p['text']) for p in index['pieces'].values())
    controls=[c for c in load(OUT/'context_development_controls_v2.json') if c['co']==co]
    result={'seconds_new_stages':time.monotonic()-started,'seconds_total':time.monotonic()-started+prior['seconds'],'usd_total':budget.spent,'usd_cap':cap,
        'kept':total-len(missing)-len(added_missed),'checks':total,'old_missing':missing,'added_missing':added_missed,
        'unrelated_controls_kept':[c for c in controls if c['piece'] in expanded[names.index(c['driver'])+1]],
        'historical_absence_nonempty':[names[int(j)-1] for j,r in truth['review'].items() if r['status']=='absent' and expanded[int(j)]],
        'rows':[{'driver':name,'selected_ids':sorted(chosen[j]),'expanded_ids':sorted(expanded[j]),'source_share':sum(len(index['pieces'][str(n)]['text']) for n in expanded[j])/size} for j,name in enumerate(names,1)],
        'scope':'Development checks only; exhaustive source and unrelated-text audits remain open.'}
    (dest/'score.json').write_text(json.dumps(result,indent=2))
    print(json.dumps({k:v for k,v in result.items() if k!='rows'}),flush=True)


if __name__=='__main__':main(sys.argv[1],sys.argv[2],'--resume' in sys.argv)
