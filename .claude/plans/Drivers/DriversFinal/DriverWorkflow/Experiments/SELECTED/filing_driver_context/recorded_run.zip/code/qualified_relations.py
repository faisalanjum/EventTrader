"""Qualify evidence roots, the actual statements used as leads, and alternative originals independently."""
from collections import defaultdict
from pathlib import Path
from hashlib import sha256
from time import monotonic
import sys
from scope_counterchecks import RULE,QUESTIONS,CRITERIA
from assign import MODEL,judge_batches,material,save
from grounded_questions import S,PRIOR,load
from full_decision import Budget
from study import grade

def run(dest,co,base,relation):
    dest.mkdir(exist_ok=False);start=monotonic();src=PRIOR/'filings'/f'{co}.json.gz';idx=load(src);pcs=idx['pieces'];b=base/co
    info=load(b/'inputs.json');names=info['names'];orig=load(b/'packets.json');score=load(b/'score.json')
    if info['source_sha256']!=sha256(src.read_bytes()).hexdigest():raise ValueError('Changed filing')
    baseusd=score['usd'];prior_secs=score['seconds'];pairs=defaultdict(list);todo={};single={}
    if relation:
        m=load(relation/'plan.json')['mapping'];rs=load(relation/'score.json');paths=load(relation/'deliveries.json')
        previously=Path(load(Path(load(relation/'plan.json')['reference_source'])/'references.json')['previous'])
        if base.resolve()!=previously.resolve():raise ValueError('Different original retrieval')
        baseusd=rs['usd'];prior_secs=rs['warm_seconds']
        for path in sorted(relation.glob('*.raw.json')):
            for q,ans in load(path)['answers'].items():
                if ans['choice']!='linked':continue
                j,n,root,a,z=m[q[1:]]
                if n in orig[str(j)]['with_companions']:continue
                item=(j,root,a,z);pairs[j,n].append(item);todo[item]=pcs[str(root)]['text'][a:z]
                whole=(j,n,0,len(pcs[str(n)]['text']));todo[whole]=pcs[str(n)]['text']
        for j,x in paths.items():
            if set(x['added'])-material(pcs,{n for k,n in pairs if k==int(j)},idx['source_structure']['edges'])[0]:raise ValueError('Untraced additions')
    for j,z in orig.items():
        if len(z['selected'])!=1:continue
        n=z['selected'][0];key=(int(j),n,0,len(pcs[str(n)]['text']));single[int(j)]=key;todo[key]=pcs[str(n)]['text']
    budget=Budget(score['ceiling_usd']);budget.spent=baseusd;qsmap={};jobs=[];kept=set()
    for item,text in sorted(todo.items()):
        j,n,a,z=item;qs={};ids=[]
        for q in QUESTIONS:
            k=len(qsmap)+1;qsmap[k]=item;ids.append(k);qs[f'p{k}']={'type':'choice','instructions':q,'criteria':CRITERIA}
        jobs.append((1,ids,{'model':MODEL,'state':{'instruction':RULE,'requested_subject':names[j-1],'original':text},'questions':qs}))
    save(dest/'protocol.json',{'source_sha256':info['source_sha256'],'normal_roots':str(base),'relation':str(relation),'prompts':[RULE,*QUESTIONS],'question_mapping':qsmap,'singleton_root':single,'added_candidates':[[j,n,rs] for (j,n),rs in pairs.items()],'before':baseusd,'cap':budget.cap,'code_hash':sha256(Path(__file__).read_bytes()).hexdigest()})
    try:
        if jobs:kept={qsmap[k] for k in judge_batches(jobs,dest,budget,[1])[1]}
    except Exception as e:
        save(dest/'incomplete.json',{'reason':str(e)[:220],'conservative_spend':budget.spent});return
    bad={j for j,k in single.items() if k not in kept};output={int(j):(set() if int(j) in bad else set(r['with_companions'])) for j,r in orig.items()}
    supports={}
    for (j,n),items in pairs.items():
        own=(j,n,0,len(pcs[str(n)]['text'])) in kept
        via=[] if j in bad else [i for i in items if i in kept]
        supports[f'{j}/{n}']={'candidate_direct_or_class':own,'qualified_lead':via}
        if own or via:output[j]|=material(pcs,{n},idx['source_structure']['edges'])[0]
    save(dest/'delivery.json',{j:sorted(ids) for j,ids in output.items()})
    save(dest/'reasons.json',supports);g=grade(co,idx,names,output)
    result={'after':g,'usd':budget.spent,'extra_usd':budget.spent-baseusd,'cap':budget.cap,'warm_elapsed':prior_secs+monotonic()-start,'single_roots_removed':sorted(bad),'calls':len(jobs)}
    save(dest/'score.json',result);print(co,g['kept'],g['checks'],g['negative_hits'],g['pairs'],budget.spent,result['warm_elapsed'],sorted(bad),flush=True)
if __name__=='__main__':run(Path(sys.argv[1]),sys.argv[2],Path(sys.argv[3]),Path(sys.argv[4]) if len(sys.argv)>4 else None)
