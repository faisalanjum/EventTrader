"""Use issuer phrases in confirmed driver passages to find every other filing location, before any reading or grading."""
from collections import Counter,defaultdict
from contextlib import closing
from hashlib import sha256
from math import ceil
from pathlib import Path
from time import monotonic
import sqlite3,sys
from grounded_questions import S,PRIOR,load
from assign import save
def run(dest,co,roots,outgoing):
    dest.mkdir(exist_ok=False);start=monotonic();src=PRIOR/'filings'/f'{co}.json.gz';idx=load(src);pcs=idx['pieces'];names=load(roots/co/'inputs.json')['names']
    assert load(roots/co/'inputs.json')['source_sha256']==sha256(src.read_bytes()).hexdigest()
    evidence={int(j):set(ns) for j,ns in load(outgoing)['independent_additions_6']['kept'].items()}
    core=load(roots/co/'packets.json')
    words=defaultdict(list)
    with closing(sqlite3.connect(':memory:')) as db:
        db.execute("CREATE VIRTUAL TABLE docs USING fts5(body, tokenize='unicode61')");db.execute("CREATE VIRTUAL TABLE vocab USING fts5vocab(docs,instance)")
        db.executemany('INSERT INTO docs(rowid,body) VALUES(?,?)',((int(n),p['text']) for n,p in pcs.items()))
        for doc,tok in db.execute('SELECT doc,term FROM vocab ORDER BY doc,offset'):words[doc].append(tok)
    # Count phrase frequency over every source, including exhibits and tables. Use the previously selected six-word rule.
    length=6;positions=defaultdict(lambda:defaultdict(list))
    for n,terms in words.items():
        for i in range(len(terms)-length+1):positions[tuple(terms[i:i+length])][n].append(i)
    rare={p:where for p,where in positions.items() if 1<len(where)<=max(2,ceil(.01*len(pcs)))}
    links={};all_candidates={}
    for j,ns in evidence.items():
        selected=(ns & set(core[str(j)]['selected'])) | (ns - set(core[str(j)]['with_companions']))
        connections=defaultdict(dict)
        for phr,matches in rare.items():
            good=selected&matches.keys();new=matches.keys()-ns
            if not good:continue
            for n in new:
                for root in good:
                    # Most distinctive match per donor passage; ties broken in source order. Keep auditable offsets.
                    score=(len(matches),matches[n][0],matches[root][0])
                    v=connections[n].get(root)
                    if not v or score<v[0]:connections[n][root]=(score,phr)
        all_candidates[j]={n:[{'prior':m,'phrase':list(v[1]),'filing_frequency':v[0][0],'original_word_offset':v[0][1],'prior_word_offset':v[0][2]} for m,v in sorted(ms.items(),key=lambda it:(it[1][0],it[0]))[:3]] for n,ms in connections.items()}
        links[j]={n:ls for n,ls in all_candidates[j].items() if pcs[str(n)]['text'].strip() not in {pcs[str(m)]['text'].strip() for m in ns}}
    save(dest/'candidates.json',{'source_sha256':sha256(src.read_bytes()).hexdigest(),'names':names,'links':links,'base_ids':{j:sorted(v) for j,v in evidence.items()},'code_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),'seconds':monotonic()-start})
    print([(j,len(v)) for j,v in links.items()],flush=True)
if __name__=='__main__':run(Path(sys.argv[1]),sys.argv[2],Path(sys.argv[3]),Path(sys.argv[4]))
