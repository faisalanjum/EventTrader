"""Prepare a text index of native issuer row labels and accounting identifiers."""
from collections import defaultdict
from pathlib import Path
from hashlib import sha256
from time import monotonic
import sys
from table_series import inventory,save
from grounded_questions import PRIOR,load

def build(dest,co):
    d=dest/(co+'.json');start=monotonic();source=PRIOR/'filings'/f'{co}.json.gz';idx=load(source);pieces=idx['pieces'];native=inventory(co)
    tags=defaultdict(set)
    for s in native['series']:
        for o in s['observations']:
            if o['row'] is not None:tags[(o['piece'],o['row'])].update([s['concept'],*s['dimensions'].values()])
    summaries={}
    for (n,r),cells in sorted(native['rows'].items()):
        if n not in summaries:
            intro=pieces.get(str(n-1),{});before=intro.get('text','') if intro.get('file')==pieces[str(n)]['file'] and intro.get('kind')!='table' else ''
            summaries[n]={'lead_in':before,'rows':{}}
        summaries[n]['rows'][r]={'printed':[c['text'] for c in cells],'accounting_terms':sorted(tags[(n,r)])}
    save(d,{'source_sha256':sha256(source.read_bytes()).hexdigest(),'tables':summaries,'seconds':monotonic()-start})
    print(co,len(summaries),sum(len(t['rows']) for t in summaries.values()),flush=True)

if __name__=='__main__':
    dest=Path(sys.argv[1]);dest.mkdir(exist_ok=False)
    for co in sys.argv[2:]:build(dest,co)
