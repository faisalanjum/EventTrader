"""Point to original company images using native PDF source positions."""
from hashlib import sha256
from pypdf import PdfReader, PdfWriter
import json

RULE=('For each numbered original chart or image, decide whether it supplies evidence for the requested subject. '
      'Keep each chart that reports or directly helps explain it, including an explicitly connected total or component. '
      'Use the complete requested scope. Copy relevant series labels as printed. Return one decision per image. '
      'The original images will be copied, so omit numerical transcriptions. The boxes use percentages from the top left.')
SCHEMA={'type':'object','required':['images'],'properties':{'images':{'type':'array','items':{'type':'object',
        'required':['id','keep','labels'],'properties':{'id':{'type':'integer'},'keep':{'type':'boolean'},
        'labels':{'type':'array','items':{'type':'string'}}}}}}}


def expand_votes(votes,sources):
    if not isinstance(votes,dict) or set(votes)!={str(i) for i in sources} or any(type(v) is not bool for v in votes.values()):
        raise ValueError('Missing, unexpected or invalid chart decision')
    return {'images':[{'id':i,'keep':votes[str(i)],'labels':[]} for i in sources]}


def matrix_votes(answer,sources,count):
    ids={str(i) for i in sources}
    if not isinstance(answer,dict) or set(answer)!=ids:raise ValueError('Incomplete image inventory')
    out={j:{i:False for i in ids} for j in range(1,count+1)}
    for image,names in answer.items():
        if (not isinstance(names,list) or any(type(j) is not int or j not in out for j in names)
            or len(names)!=len(set(names))):
            raise ValueError('Unrecognized or duplicate subject in image response')
        for j in names:out[j][image]=True
    return out

def named_votes(answer,sources,names):
    if (not isinstance(answer,dict) or len(set(names))!=len(names) or set(answer)!=set(names)):
        raise ValueError('Response does not cover the exact requested names')
    labels={'chart_'+str(i):str(i) for i in sources}
    votes={}
    for j,name in enumerate(names,1):
        chosen=answer[name]
        if (not isinstance(chosen,list) or any(type(x) is not str or x not in labels for x in chosen)
                or len(chosen)!=len(set(chosen))):raise ValueError('Invalid source IDs')
        votes[j]={k:label in chosen for label,k in labels.items()}
    return votes


def positions(folder, render):
    pdf=PdfReader(folder/'original_render.pdf')
    source_names=render.get('source_images_on_pages',render['exact_original_jpeg_bytes_on_pages'])
    by_sha={sha256((folder/name).read_bytes()).hexdigest():name for name in source_names}
    converted=render.get('converted_pdf_stream_to_original_file',{})
    images=[]
    for page_number in render['all_image_pages']:
        page=pdf.pages[page_number-1];box=page.mediabox
        def visit(op,args,cm,tm):
            if op!=b'Do':return
            ob=page['/Resources']['/XObject'][args[0]].get_object()
            if ob.get('/Subtype')!='/Image':return
            sha=sha256(ob.get_data()).hexdigest()
            name=by_sha.get(sha,converted.get(sha))
            if name is None:return
            a,b,c,d,e,f=cm
            corners=[(a*u+c*v+e,b*u+d*v+f) for u,v in [(0,0),(1,0),(0,1),(1,1)]]
            xs=[100*(x-float(box.left))/float(box.width) for x,_ in corners]
            ys=[100*(float(box.top)-y)/float(box.height) for _,y in corners]
            images.append({'page':page_number,'box':[round(min(xs)),round(min(ys)),round(max(xs)),round(max(ys))],
                           'file':name,'sha256':sha256((folder/name).read_bytes()).hexdigest()})
        page.extract_text(visitor_operand_before=visit)
    if {im['file'] for im in images}!=set(by_sha.values()):
        raise ValueError('Missing verified original chart locations')
    images.sort(key=lambda x:(x['page'],x['box'][1],x['box'][0]))
    return {i+1:item for i,item in enumerate(images)}


def packet(answer,images,folder,dest):
    rows=answer['images']
    if not isinstance(rows,list) or sorted(row['id'] for row in rows)!=sorted(images):
        raise ValueError('Missing, duplicate or unknown original image')
    selected=[]
    for row in rows:
        if type(row['id']) is not int or type(row['keep']) is not bool or not isinstance(row['labels'],list) or any(type(x) is not str for x in row['labels']):
            raise ValueError('Invalid image decision')
        if row['keep']:
            info=images[row['id']]
            original=(folder/info['file']).read_bytes()
            if sha256(original).hexdigest()!=info['sha256']:raise ValueError('Original image changed')
            (dest/info['file']).write_bytes(original)
            selected.append({**info,'labels_as_read':row['labels']})
    pages=sorted({row['page'] for row in selected})
    if pages:
        # A separate reference view preserves the issuer's colors, captions and page context.
        reader=PdfReader(folder/'original_render.pdf');writer=PdfWriter()
        for i in pages:writer.add_page(reader.pages[i-1])
        writer.write(dest/'selected_source_pages.pdf')
    (dest/'selected_chart_sources.json').write_text(json.dumps(selected,indent=1))
    return [row['file'] for row in selected]
