"""Pick independent issuer language about the subject without relying on the candidate's own claims."""
from pathlib import Path
from hashlib import sha256
from time import monotonic
import json,re,sys
from edgar.search.textsearch import BM25Search
from claude_trial import EX,PRIOR,OUT,load
sys.path.insert(0,str(EX/'2026-11-15_decider_guidance/experiment/vendor'))
import pysbd

def build(dest,co,base):
    dest.mkdir(exist_ok=False);t=monotonic();src=PRIOR/'filings'/f'{co}.json.gz';idx=load(src);pcs=idx['pieces']
    info=load(base/co/'inputs.json');names=info['names'];d=load(base/co/'packets.json')
    if info['source_sha256']!=sha256(src.read_bytes()).hexdigest():raise ValueError('Old filing')
    rows={};seg=pysbd.Segmenter(language='en',clean=False,char_span=True)
    for j,name in enumerate(names,1):
        allrows=[]
        for n in d[str(j)]['selected']:
            raw=pcs[str(n)]['text']
            if pcs[str(n)]['kind']=='table':
                markers=list(re.finditer(r'(?m)^r\d+: (?=\[c\d)',raw));intervals=[(x.start(),markers[i+1].start() if i+1<len(markers) else len(raw)) for i,x in enumerate(markers)] or [(0,len(raw))]
            else:intervals=[(x.start,x.end) for x in seg.segment(raw)]
            for a,b in intervals:
                if 25<=len(raw[a:b].strip())<=1800:allrows.append((n,a,b,raw[a:b]))
        chosen=[];sources=set()
        if allrows:
            engine=BM25Search([r[3] for r in allrows])
            for h in sorted(engine.search(name).sections,key=lambda k:(-k.score,k.loc)):
                n,a,b,quote=allrows[h.loc]
                if n in sources:continue
                chosen.append({'n':n,'a':a,'b':b,'quote':quote});sources.add(n)
                if len(chosen)==6:break
        rows[j]=chosen
    result={'base':str(base),'source_sha256':info['source_sha256'],'names':names,'subject_evidence':rows,'elapsed':monotonic()-t,'input':'Unchanged driver name. Native word search of sentences/rows from different original passages already located independently.'}
    (dest/'statements.json').write_text(json.dumps(result,ensure_ascii=False,indent=1))
if __name__=='__main__':build(Path(sys.argv[1]),sys.argv[2],Path(sys.argv[3]))
