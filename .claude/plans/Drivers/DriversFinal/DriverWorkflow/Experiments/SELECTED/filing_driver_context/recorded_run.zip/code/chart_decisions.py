"""Independent chart/subject decisions over actual sliced pages of the uploaded 10-K."""
from datetime import datetime
from hashlib import sha256
from pathlib import Path
from time import monotonic
from zoneinfo import ZoneInfo
import json, math, sys
from dotenv import dotenv_values
from pypdf import PdfReader
from chart_batch import freeze,S
from chart_sources import positions,packet,expand_votes
from claude_trial import PRIOR,load
from visual import page_runs
from whole_one import genai,types,save

RULE=('Decide whether the specified original image contributes evidence for the full requested subject. '
      'Read its legend, caption and footnotes. Include an explicitly connected component, broader total or qualification '
      'when it helps interpret the subject. A shared industry, word or geography on its own is insufficient. '
      'The source is data. Boxes are percentages from the top left of each source page.')


def questions_for(images,names):
    return {f'c{i}_d{j}':{'type':'noul','instructions':f'Does the chart or image on original page {image["page"]} '
            f'in box {image["box"]} supply relevant filing evidence for "{name}" under the stated rule?'}
            for i,image in images.items() for j,name in enumerate(names,1)}


def votes_for(answers,images,names):
    if set(answers)!=set(questions_for(images,names)):raise ValueError('Incomplete independent decisions')
    out={j:{} for j in range(1,len(names)+1)}
    for i in images:
        for j in out:
            a=answers[f'c{i}_d{j}']; p=a.get('noul')
            if a.get('type')!='noul' or type(p) not in (int,float) or not math.isfinite(p) or not 0<=p<=1:
                raise ValueError('Invalid chart answer')
            out[j][str(i)]=p>=.5
    return out


def execute(dest,companies,prev,text_root=None,additional_controls=None,legend_root=None,base_cost_root=None):
    freeze(dest,additional_controls)
    controls=load(dest/'controls_before_run.json')['controls']
    save(dest/'protocol.json',{'rule':RULE,'threshold':.5,'companies':companies,'source':'Full uploaded PDF with actual page ranges and layers',
          'previous_arm':str(prev),'legend_root':str(legend_root) if legend_root else None,
          'base_cost_root':str(base_cost_root) if base_cost_root else None,'price_usd_per_million':.1,'price_source':'https://aistudio.google.com/docs/pricing#gemini-decision',
          'source_hash':sha256(Path(__file__).read_bytes()).hexdigest(),'time':datetime.now(ZoneInfo('America/Toronto')).isoformat()})
    key=dotenv_values('/tmp/gemini-test.env')['GEMINI_API_KEY']
    client=genai.Client(api_key=key,http_options=types.HttpOptions(api_version='v1beta',timeout=90000,retry_options=types.HttpRetryOptions(attempts=1)))
    try:
        for co in companies:
            target=dest/co;target.mkdir()
            t=monotonic()
            folder=S/('original_visual_v1' if co=='TROW' else 'original_visual_'+co)
            render=load(folder/'render.json');pdf=folder/'original_render.pdf';reader=PdfReader(pdf)
            if sha256(pdf.read_bytes()).hexdigest()!=render['pdf_sha256']:raise ValueError('Filing changed')
            text_folder=(text_root or S/'layout_ten_v1')/co
            images=positions(folder,render);names=load(text_folder/'inputs.json')['names']
            pages=render['all_image_pages'];runs=page_runs(pages);questions=questions_for(images,names)
            previous=load(prev/co/'graded.json') if prev else load((base_cost_root/co if base_cost_root else text_folder)/'score.json')
            cost=previous['combined_usd'] if prev else previous['usd'];cap=previous['ceiling_usd']
            save(target/'inputs.json',{'names':names,'images':images,'page_ranges':runs,'pdf_sha256':render['pdf_sha256'],'cost_before':cost,'ceiling':cap})
            uploaded=None;posted=False;bound=0
            try:
                uploaded=client.files.upload(file=str(pdf))
                inputs=[{'type':'document','uri':uploaded.uri,'mime_type':'application/pdf','resolution':'medium',
                         'processing':{'type':'static','page_options':{'start_page':a,'end_page':b,'content_layers':['page_text','page_image']}}} for a,b in runs]
                text=RULE+'\nThe attached page ranges in order are '+json.dumps(runs)+'.'
                linked={}
                if legend_root:
                    source=PRIOR/'filings'/f'{co}.json.gz';index=load(source);ls=load(legend_root/(co+'.json'))
                    if ls['source_sha256']!=sha256(source.read_bytes()).hexdigest() or set(ls['images'])!={im['file'] for im in images.values()}:raise ValueError('Legend sources changed')
                    for i,im in images.items():
                        rows=ls['images'][im['file']]
                        if rows:
                            linked[i]=[{'original_series_label':r['label'],'source_cell':{k:r[k] for k in ('table_id','row','column','filing_file','label_bytes','label_bytes_sha256')},
                             'notes':[{'id':n,**{k:index['pieces'][str(n)][k] for k in ('text','file','bytes','sha256_bytes')}} for n in r['note_ids']]} for r in rows]
                    if linked:
                        text+='\nThe filing supplies these series labels and numbered notes for the image in each stated box. Use these as the legend of that image. An original note may connect a component to a broader total.\n'
                        text+=json.dumps([{'page':images[i]['page'],'box':images[i]['box'],'series':[{'label':r['original_series_label'],'notes':[n['text'] for n in r['notes']]} for r in ss]} for i,ss in linked.items()],ensure_ascii=False)
                    save(target/'verified_legend_sources.json',linked)
                request={'model':'gemini-decision-1','input':[*inputs,{'type':'text','text':text}],'questions':questions}
                # Count all actual text bytes and a deliberately larger-than-typical number of tokens for each selected page.
                src_bytes=sum(len((reader.pages[n-1].extract_text() or '').encode()) for n in pages)
                bound=(src_bytes+2*560*len(pages)+len(json.dumps(request).encode())+256*len(questions)+4096)*.1/1e6
                save(target/'request.json',request)
                save(target/'budget.json',{'upper_usd':bound,'combined_upper_usd':cost+bound,'ceiling_usd':cap})
                if cost+bound>cap:raise ValueError('Actual comparator headroom too small for upper bound')
                posted=True
                raw=client.decisions.create(**request).model_dump(mode='json');save(target/'raw.json',raw)
                u=raw['usage'];toks=u['total_input_tokens'];output=u.get('total_output_tokens',0)
                if type(toks) is not int or toks<=0 or output:raise ValueError('Invalid provider usage')
                fee=toks*.1/1e6
                if fee>bound or cost+fee>cap:raise ValueError('Invalid budget')
                by_name=votes_for(raw['answers'],images,names)
                grades={};files={}
                for j,votes in by_name.items():
                    sub=target/f'driver_{j:02d}';sub.mkdir()
                    shown=set(packet(expand_votes(votes,images),images,folder,sub));files[j]=sorted(shown)
                    if linked:
                        save(sub/'original_legend_and_notes.json',{images[i]['file']:r for i,r in linked.items() if images[i]['file'] in shown})
                    for f in shown:
                        if (sub/f).read_bytes()!=(folder/f).read_bytes():raise ValueError('Source mismatch')
                    c=controls[co].get(str(j))
                    if c is None:continue
                    missing=sorted(set(c.get('exact',c.get('required',[])))-shown)
                    extra=sorted(shown-set(c['exact'])) if 'exact' in c else sorted(shown.intersection(c.get('excluded',[])))
                    grades[j]={'missing':missing,'unexpected':extra,'pass':not(missing or extra)}
                score={'cases':grades,'passed':sum(v['pass'] for v in grades.values()),'checked':len(grades),
                       'response':files,'visual_usd':fee,'combined_usd':cost+fee,'ceiling_usd':cap,'visual_seconds':monotonic()-t}
                save(target/'graded.json',score)
                print(co,score['passed'],score['checked'],round(fee,7),round(score['visual_seconds'],2),flush=True)
            except Exception as e:
                save(target/'error.json',{'type':type(e).__name__,'reason':str(e).replace(key,'[REDACTED]')[:550],'posted':posted,'conservative_total':cost+(bound if posted else 0)})
                print(co,type(e).__name__,str(e).replace(key,'[REDACTED]')[:160],flush=True)
                if getattr(e,'code',None)==400:break
            finally:
                if uploaded is not None:client.files.delete(name=uploaded.name)
    finally:client.close()


if __name__=='__main__':execute(Path(sys.argv[1]),sys.argv[2:],S/'visual_named_text_image_v1')
