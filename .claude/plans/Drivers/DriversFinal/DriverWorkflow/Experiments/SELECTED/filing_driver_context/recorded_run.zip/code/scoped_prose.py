"""Use the same native full-text tokenizer for the filing, supplied names and source sentences."""
from collections import defaultdict
import sqlite3

class FilingTerms:
    def __init__(self, pieces, names):
        self.db=sqlite3.connect(':memory:')
        self.db.executescript("""
            CREATE VIRTUAL TABLE docs USING fts5(wording, tokenize='porter unicode61');
            CREATE VIRTUAL TABLE vocab USING fts5vocab(docs,instance);
            CREATE VIRTUAL TABLE names USING fts5(wording, tokenize='porter unicode61');
            CREATE VIRTUAL TABLE terms USING fts5vocab(names,instance);
            CREATE VIRTUAL TABLE sentences USING fts5(wording, tokenize='porter unicode61');
            CREATE VIRTUAL TABLE words USING fts5vocab(sentences,instance);
        """)
        self.db.executemany('INSERT INTO docs(rowid,wording) VALUES(?,?)',
            ((int(n),p['text']) for n,p in pieces.items() if p['kind'] in ('text','list_item')))
        self.db.executemany('INSERT INTO names(rowid,wording) VALUES(?,?)',enumerate(names,1))
        self.docs=defaultdict(set)
        for term,n in self.db.execute('SELECT DISTINCT term,doc FROM vocab WHERE term IN (SELECT term FROM terms)'):
            self.docs[term].add(n)
        count,=self.db.execute('SELECT COUNT(*) FROM docs').fetchone()
        self.terms=defaultdict(set)
        for j,term in self.db.execute('SELECT DISTINCT doc,term FROM terms'):
            # A term in at least half the prose originals has no positive Robertson/Sparck Jones IDF.
            if 0<2*len(self.docs[term])<count:
                self.terms[j].add(term)

    def matches(self,j,n):
        return any(n in self.docs[term] for term in self.terms[j])

    def sentence_matches(self,j,lines):
        self.db.execute('DELETE FROM sentences')
        self.db.executemany('INSERT INTO sentences(rowid,wording) VALUES(?,?)',enumerate(lines,1))
        return {i for i,word in self.db.execute('SELECT DISTINCT doc,term FROM words') if word in self.terms[j]}

    def __enter__(self):return self
    def __exit__(self,*_):self.db.close()

def attach_scope(index,j,lines,chosen):
    if not chosen:return []
    named=index.sentence_matches(j,lines)
    if not named or named.intersection(chosen):return []
    # At most one original sentence supplies the missing subject wording.
    _,_,pos=min((abs(i-k),i>k,i) for i in named for k in chosen)
    return [pos]
