"""Compare source-complete vs corroborated note expansions, using already recorded filing-wide judgments."""
from collections import defaultdict
from pathlib import Path
from hashlib import sha256
from time import monotonic
import re,sys
from assign import material,save
from grounded_questions import PRIOR,S,OUT,load
from study import grade

def run(dest,co,base,full,controls):
    dest.mkdir(exist_ok=False);t=monotonic();idx=load(PRIOR/'filings'/f'{co}.json.gz');pcs=idx['pieces'];meta=load(base/co/'inputs.json');names=meta['names'];original=load(base/co/'packets.json')
    which=Path(meta['underlying_source']);proto=load(which/'protocol.json');first=Path(proto['first_pass']);f=load(first/'first_answers.json');fine=load(which/'fine_answers.json');coarse=load(which/'coarse_answers.json')
    if len(f)!=len(names)*len(pcs) or proto['source_sha256']!=meta['source_sha256']:raise ValueError('Incomplete matched receipts')
    final={int(j):set(v) for j,v in load(full/'delivery.json').items()};rules=['all','originals_with_explicit_links','prior_evidence','any_prior_support','prior_evidence_or_coarse_evidence'];results={}
    sys.path.insert(0,str(PRIOR.parent.parent/'2026-11-23_decider_driver_context'))
    from blocks import filing_blocks
    parent={n:a for a,b,_ in filing_blocks(pcs) for n in range(a,b+1)}
    for rule in rules:
        outputs={};reasons={}
        for j,nset in final.items():
            prev=set(original[str(j)]['with_companions']);seeds=(set(original[str(j)]['selected'])&nset)|(nset-prev);protected=material(pcs,seeds,idx['source_structure']['edges'])[0]&nset
            allowed=set(protected)
            for n in sorted(nset-protected):
                primary=f[f'p{n}_d{j}']['choice'];second=fine.get(f'p{n}_d{j}',{}).get('choice');big=coarse[f'b{parent[n]}_d{j}']['choice']
                evidence=(primary in ('reports','explains','context') or second=='context')
                anyvote=(primary!='other' or (second is not None and second!='unrelated'))
                if rule=='all' or (rule=='prior_evidence' and evidence) or (rule=='any_prior_support' and anyvote) or (rule=='prior_evidence_or_coarse_evidence' and (evidence or big=='context')):allowed.add(n)
                reasons[f'{j}/{n}']=[primary,second,big]
            outputs[j]=allowed
        checked=[{**q,'pass':(q['n'] in outputs[q['j']])==q['keep']} for q in load(controls)]
        char=sum(len(pcs[str(n)]['text']) for ns in outputs.values() for n in ns)
        results[rule]={'grade':grade(co,idx,names,outputs),'expanded_precision_checks':checked,'extra_correct':sum(c['pass'] for c in checked),'checked':len(checked),'chars':char,'usd':load(full/'score.json')['usd'],'kept':{j:sorted(ns) for j,ns in outputs.items()}}
        print(rule,results[rule]['grade']['kept'],results[rule]['grade']['pairs'],results[rule]['extra_correct'],len(checked),char,flush=True)
    save(dest/'source_votes.json',reasons);save(dest/'results.json',results)
if __name__=='__main__':run(Path(sys.argv[1]),sys.argv[2],Path(sys.argv[3]),Path(sys.argv[4]),Path(sys.argv[5]))
