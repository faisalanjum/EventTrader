"""Audit proposed explanations against both the requested subject and the actual original statements."""
from collections import defaultdict
from hashlib import sha256
from pathlib import Path
from time import monotonic
import sys
from assign import MODEL,judge_batches,material,save
from grounded_questions import S,PRIOR,load
from full_decision import Budget
from study import grade

QUESTIONS=('Is the proposed connection supported by the identified issuer statements and the candidate in its original context?',
           'Does the proposed connection explain a concrete aspect of the requested measure, its inputs, scope, or interpretation? Elaborating on a different measure alone is insufficient.')
OPT={'direct':'Yes, the evidence supports this.', 'other':'This is unsupported or addresses something else.'}
def run(dest,co,witnesses,controls):
    dest.mkdir(exist_ok=False);start=monotonic();s=load(witnesses/(co+'.json'));src=PRIOR/'filings'/f'{co}.json.gz'
    if s['source_sha256']!=sha256(src.read_bytes()).hexdigest():raise ValueError('Changed source')
    pcs=load(src)['pieces'];idx=load(src);names=s['names'];m={};jobs=[]
    prev=S/f'checked_chain_{co}_v1';out={int(j):set(ns) for j,ns in load(prev/'delivery.json').items()};r=load(Path(s['adjudicator'])/co/'score.json')
    budget=Budget(r['cap']);usd=budget.spent=r['usd']
    for js,vs in s['cases'].items():
        j=int(js)
        for v in vs:
            n,a,b=v['candidate'];raw=pcs[str(n)]['text']
            if v['candidate_source']!=raw[a:b]:raise ValueError('Ungrounded evidence')
            ids=[];qs={}
            for ax,q in enumerate(QUESTIONS):
                k=len(m)+1;ids.append(k);m[k]=[j,n,ax];qs[f'p{k}']={'type':'choice','instructions':q,'criteria':OPT}
            state={'requested_subject':names[j-1],'candidate_in_context':raw,'exact_candidate_sentence_or_fragment':raw[a:b],'quoted_other_original':v['basis_source'],'proposed_connection_to_test':v['connection']}
            jobs.append((1,ids,{'model':MODEL,'state':state,'questions':qs}))
    save(dest/'protocol.json',{'source_sha256':s['source_sha256'],'witnesses':str(witnesses),'questions':QUESTIONS,'map':m,'usd_before':usd,'cap':budget.cap,'controls_sha256':sha256(controls.read_bytes()).hexdigest(),'code_sha256':sha256(Path(__file__).read_bytes()).hexdigest()})
    try:yes={tuple(m[k]) for k in judge_batches(jobs,dest,budget,[1])[1]} if jobs else set()
    except Exception as e:save(dest/'incomplete.json',{'reason':str(e)[:160],'conservative_usd':budget.spent});return
    kept=[]
    for j,n,ax in yes:
        if ax==0 and (j,n,1) in yes:out[j]|=material(pcs,{n},idx['source_structure']['edges'])[0];kept.append((j,n))
    checks=[]
    for j,n,expected,why in load(controls).get(co,[]):
        checks.append({'j':j,'n':n,'expected':expected,'present':n in out[j],'pass':(n in out[j])==expected,'reason':why})
    g=grade(co,idx,names,out);unresolved=s['rejected']
    result={'after':g,'passed_frozen':[sum(c['pass'] for c in checks),len(checks)],'frozen_checks':checks,'added':sorted(kept),'unverified_witnesses':unresolved,'usd':budget.spent,'extra_usd':budget.spent-usd,'cap':budget.cap,'warm_elapsed':r['combined_warm_seconds']+monotonic()-start}
    save(dest/'delivery.json',{j:sorted(ns) for j,ns in out.items()});save(dest/'score.json',result);print(co,g['kept'],g['checks'],g['negative_hits'],result['passed_frozen'],kept,unresolved,budget.spent,flush=True)
if __name__=='__main__':run(Path(sys.argv[1]),sys.argv[2],Path(sys.argv[3]),Path(sys.argv[4]))
