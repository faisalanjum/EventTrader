"""Read explicit relationships from the existing, verified filing preparation."""
from collections import Counter, defaultdict
import gzip
from hashlib import sha256
import json


def material(pieces, ids, edges):
    def related(seeds):
        found, pending = set(seeds), list(seeds)
        while pending:
            n = pending.pop()
            extra = set(pieces[str(n)]["companions"]).union(edges.get(str(n), ())) - found
            found.update(extra)
            pending.extend(extra)
        return found

    proven = related(ids)
    # Plain prose at a table boundary may carry its scale. Keep it as possible context.
    # Do this once so neighboring tables cannot recursively collect an entire document.
    adjacent = {j for n in proven if pieces[str(n)]["kind"] == "table" for j in (n - 1, n + 1)
                if str(j) in pieces and pieces[str(j)]["file"] == pieces[str(n)]["file"]}
    return proven, proven | related(adjacent)


def prepared_edges(index, job):
    from driver.prepare.reconstruct import _resolve

    pieces = index["pieces"]
    edges, counts, receipts = defaultdict(set), Counter(), {}
    members = {m["name"]: m for m in index["members"]}
    rows = json.loads((job / "RESULT.json").read_bytes())["rows"]
    assert [r["file_id"] for r in rows] == list(members)
    for row in rows:
        name = row["file_id"]
        raw = (job / f"attempt_{row['ordinal']}" / "ROUTE.json.gz").read_bytes()
        receipts[name] = sha256(raw).hexdigest()
        route = json.loads(gzip.decompress(raw))
        assert route["sha256"] == members[name]["sha256"] and route["text_proved"] and not route["uncovered"]
        actual = {p["unit"]: int(n) for n, p in pieces.items() if p["file"] == name}
        units = route["units"]
        assert set(actual) == {u["id"] for u in units if u["kind"] != "image"}
        _, placed, unknown = _resolve(units)
        counts["unresolved_native_placements"] += len(unknown)

        def connect(a, b, kind):
            if a in actual and b in actual and a != b:
                edges[actual[a]].add(actual[b])
                counts[kind] += 1

        for child, placement in placed.items():
            a, b = units[placement[1]]["id"], units[child]["id"]
            connect(a, b, "caption_or_nested_table")
            connect(b, a, "caption_or_nested_table")
        notes = set()
        for rel in route.get("source_relations", {}).get("relationships", []):
            if rel["attributes"].get("arcrole") != "http://www.xbrl.org/2003/arcrole/fact-footnote":
                continue
            def owners(endpoints):
                return {owner["unit"] for e in endpoints if e["status"] == "one"
                        for part in [e, *e.get("continuations", [])] if part["status"] == "one"
                        for owner in (part.get("owners") or [])}
            facts = owners(rel["from"])
            linked = owners([e for e in rel["to"] if e.get("element", "").endswith("}footnote")])
            notes.update(linked)
            for a in facts:
                for b in linked:
                    connect(a, b, "fact_to_note")
                    connect(b, a, "note_to_fact")
        for link in route.get("source_links", []):
            destination = link.get("destination") or {}
            if destination.get("kind") != "same_document":
                continue
            owner = destination.get("owner")
            if destination.get("status") != "one" or not owner:
                counts["internal_links_without_unique_text_owner"] += 1
                continue
            # Within an explicitly identified footnote, preserve an owned internal target.
            for src in link.get("owners") or []:
                if src["unit"] in notes:
                    connect(src["unit"], owner["unit"], "reference_inside_note")
        counts["members"] += 1
        counts["tables"] += sum(u["kind"] == "table" for u in units)
    return {"edges": {str(n): sorted(v) for n, v in sorted(edges.items())},
            "native_counts": dict(counts), "route_sha256": receipts}
