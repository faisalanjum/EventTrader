from datetime import datetime
from hashlib import sha256
from pathlib import Path
from zoneinfo import ZoneInfo
import sys
from claude_trial import OUT,load
from assign import save
from visual import run

S=OUT/'issuer_notes_study'


def freeze(dest,additional=None):
    old=load(S/'chart_compact_v1/score.json')['cases']
    checks={}
    for c in old:
        co,j=c['name'].split('_')
        checks.setdefault(co,{})[str(int(j))]={'exact':c['expected'],'basis':'Previously inspected original image/legend and caption'}
    checks['TROW']['7']={'exact':['trow-20251231_g2.jpg','trow-20251231_g4.jpg'],
        'basis':'Account-type chart gives U.S. Defined Contribution. The original client-type chart legend cites footnote 3, which says Institutional includes defined contribution sourced through intermediaries and the issuer recordkeeper. Broader reading context; the total is not a direct plan-sponsor amount.'}
    checks['TROW']['9']={'required':['trow-20251231_g2.jpg'],'basis':'Client-type figure explicitly reports Institutional AUM, qualified in footnote 3.'}
    checks['TROW']['10']={'excluded':['trow-20251231_g3.jpg'],'basis':'Geography grouping is AUM for U.S. and combined APAC/EMEA/Canada. This is not a geographic revenue percentage.'}
    checks['RJF']['6']={'required':['rjf-20240930_g1.jpg'],'basis':'Asset Management contributes 8% in the original segments net revenue chart.'}
    for j in (4,10):checks['RJF'][str(j)]={'exact':[],'basis':'Restaurants and intermodal loads have no supporting chart.'}
    for co,why in {'TKR':'Only logo, employee injury rates and shareholder stock returns.',
                   'CSCO':'Only logo, employee distributions and shareholder stock returns.',
                   'PANW':'Only shareholder stock return graphics.',
                   'STX':'Only shareholder stock return graphics.'}.items():
        checks[co]={str(j):{'exact':[],'basis':why} for j in range(1,11)}
    if additional:checks.update(additional)
    dest.mkdir(exist_ok=False)
    save(dest/'controls_before_run.json',{'controls':checks,'time':datetime.now(ZoneInfo('America/Toronto')).isoformat(),
        'qualification':'Original source review before this batch. CSCO and TKR are new visual issuers; known cases include newly audited related-scope material. Unlisted drivers on TROW/RJF are not adjudicated.'})


def execute(dest,companies,layers,mode='matrix',previous_visual=None):
    controls=load(dest/'controls_before_run.json')['controls']
    scores={}
    for co in companies:
        folder=S/('original_visual_v1' if co=='TROW' else 'original_visual_'+co)
        prev=S/('table_series_confirm_v1' if co in ('FTV','TKR') else 'table_series_confirm_remaining_v1')/co/'score.json'
        if previous_visual:
            earlier=load(previous_visual/co/'graded.json')
            prior_cost=dest/'prior'/co/'score.json';prior_cost.parent.mkdir(parents=True,exist_ok=True)
            save(prior_cost,{'usd':earlier['combined_usd'],'ceiling_usd':earlier['ceiling_usd']})
            prev=prior_cost
        one=dest/co
        run(folder,one,S/'layout_ten_v1'/co,'medium',700 if mode=='named' else 350,mode,prev,layers)
        if not (one/'answer.json').exists():continue
        actual={}
        for sub in one.glob('driver_*/selected_chart_sources.json'):
            j=str(int(sub.parent.name.partition('_')[2]));files=set()
            for source in load(sub):
                name=source['file']
                if sha256((sub.parent/name).read_bytes()).hexdigest()!=source['sha256'] or (sub.parent/name).read_bytes()!=(folder/name).read_bytes():
                    raise ValueError('Selected output differs from original')
                files.add(name)
            actual[j]=files
        if len(actual)!=10:raise ValueError('Missing requested name')
        grades={}
        for j,c in controls[co].items():
            got=actual[j]
            missing=sorted(set(c.get('exact',c.get('required',[])))-got)
            extra=sorted(got-set(c['exact'])) if 'exact' in c else sorted(got.intersection(c.get('excluded',[])))
            grades[j]={'missing':missing,'unexpected':extra,'pass':not missing and not extra}
        receipt=load(one/'usage.json')
        scores[co]={'cases':grades,'checked':len(grades),'passed':sum(r['pass'] for r in grades.values()),'response':{j:sorted(v) for j,v in actual.items()},
                    'visual_usd':receipt['cost_usd'],'combined_usd':receipt['combined_usd'],'ceiling_usd':load(prev)['ceiling_usd'],
                    'visual_seconds':receipt['seconds_with_upload_and_count']}
        save(one/'graded.json',scores[co])
        print(co,scores[co]['passed'],scores[co]['checked'],{j:v for j,v in grades.items() if not v['pass']},flush=True)
    save(dest/'summary.json',scores)


if __name__=='__main__':
    dest=Path(sys.argv[1])
    freeze(dest)
    execute(dest,sys.argv[2:],('page_image',))
