"""Can an original support the requested quantity, including a logically applicable limit?"""
from pathlib import Path
from hashlib import sha256
from time import monotonic
import json,sys
from assign import MODEL,judge_batches,save
from grounded_questions import S,PRIOR,load
from full_decision import Budget

CRITERIA={'direct':'Yes, the original supports this.', 'other':'No, the original does not establish this.'}
RULE='Judge only what the filing original establishes. Keep its reported measure, scope and qualifications.'
QUESTIONS=[
 'Can you identify a specific statement in the original about the requested measurement for the requested scope?',
 'Does the original state a rule, limit or reporting convention for a class that includes the requested subject, even when it is unnamed? It must apply to that same measurement.',
]
def run(dest,casefile):
    dest.mkdir(exist_ok=False);cases=load(casefile); bysource={}
    for c in cases:bysource.setdefault((c['co'],c['piece']),[]).append(c)
    plan={};per_co={}
    for (co,n),rows in bysource.items():
        src=PRIOR/'filings'/f'{co}.json.gz';p=load(src)['pieces'][str(n)]
        for case in rows:
            qs={};ids=[]
            for axis,t in enumerate(QUESTIONS):
                k=len(plan)+1;ids.append(k);plan[k]=[case['id'],axis];qs[f'p{k}']={'type':'choice','instructions':t,'criteria':CRITERIA}
            req={'model':MODEL,'state':{'instruction':RULE,'requested_subject':case['subject'],'original':p['text']},'questions':qs}
            per_co.setdefault(co,[]).append((1,ids,req))
    save(dest/'protocol.json',{'code':sha256(Path(__file__).read_bytes()).hexdigest(),'cases':sha256(casefile.read_bytes()).hexdigest(),'answers_computed_after_selection':True,'map':plan})
    records={};costs={}
    for co,jobs in per_co.items():
        sub=dest/co;sub.mkdir();start=monotonic();cap=next(c['baseline_usd'] for c in cases if c['co']==co)
        budget=Budget(cap);yes=judge_batches(jobs,sub,budget,[1])[1];costs[co]={'usd':budget.spent,'seconds':monotonic()-start}
        for q,file in [(q,file) for file in sorted(sub.glob('*.raw.json')) for q in load(file)['answers']]:
            k=int(q[1:]);name,axis=plan[k];info=records.setdefault(name,{'axes':{},'model_vote':False});a=load(file)['answers'][q];info['axes'][str(axis)]=a['probabilities']['direct']
            info['model_vote']|=(k in yes)
    rows=[]
    for c in cases:
        r=records[c['id']];rows.append({**c,**r,'passed':c['expected']==r['model_vote']})
    save(dest/'score.json',{'rows':rows,'costs':costs,'passed':sum(c['passed'] for c in rows),'total':len(rows)})
    for row in rows:print(row['id'],row['model_vote'],row['expected'],list(row['axes'].values()),flush=True)
if __name__=='__main__':run(Path(sys.argv[1]),Path(sys.argv[2]))
