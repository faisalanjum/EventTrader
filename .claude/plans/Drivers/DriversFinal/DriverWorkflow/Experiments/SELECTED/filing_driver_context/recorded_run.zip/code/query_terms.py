"""Generate reusable search strings from names alone; none are filing evidence."""
from hashlib import sha256
from pathlib import Path
from time import monotonic
import json,re,sys
from dotenv import dotenv_values
from grounded_questions import MODEL,S,PRIOR,load,genai,types,save

TASK=('For each requested measure give up to three short search phrases a filing may use. Spell out '
      'abbreviations and preserve qualifiers. A phrase can help find a related disclosure without being '
      'an accounting equivalent. Do not assume issuer-specific facts. Return only a JSON object keyed '
      'by every original name, with an array of distinct strings for each.')

def run(dest,companies):
    dest.mkdir(exist_ok=False);t=monotonic()
    cohort=load(PRIOR/'cohort.json')['companies']
    names=sorted({r['kpi'] for co in companies for r in cohort[co]['drivers']})
    prompt=TASK+'\n'+json.dumps(names,ensure_ascii=False)
    save(dest/'protocol.json',{'names':names,'prompt':prompt,'model':MODEL,'cost_usd':0,'purpose':'Navigation only. No source material, issuer identifiers or test controls. Reusable for repeated names.','code_sha256':sha256(Path(__file__).read_bytes()).hexdigest()})
    key=dotenv_values('/tmp/gemini-test.env')['GEMINI_API_KEY']
    c=genai.Client(api_key=key,http_options=types.HttpOptions(api_version='v1beta',timeout=65000,retry_options=types.HttpRetryOptions(attempts=1)))
    try:
        response=c.models.generate_content(model=MODEL,contents=prompt,config=types.GenerateContentConfig(temperature=0,max_output_tokens=1700,thinking_config=types.ThinkingConfig(thinking_level='minimal'))).model_dump(mode='json')
    finally:c.close()
    save(dest/'raw.json',response);candidates=response['candidates']
    if len(candidates)!=1 or candidates[0]['finish_reason']!='STOP':raise ValueError('Incomplete query vocabulary')
    text=''.join(p.get('text','') for p in candidates[0]['content']['parts'] if not p.get('thought'))
    terms=json.loads(re.sub(r'^\s*\x60{3}(?:json)?\s*|\s*\x60{3}\s*$','',text))
    if set(terms)!=set(names) or any(not isinstance(v,list) or len(v)>3 or any(not isinstance(x,str) or not x.strip() for x in v) for v in terms.values()):raise ValueError('Incomplete or malformed name coverage')
    save(dest/'terms.json',terms);save(dest/'usage.json',{'seconds':monotonic()-t,'usd':0,'provider_tokens':response['usage_metadata']})
    print(len(names),'names',round(monotonic()-t,2),'seconds',flush=True)

if __name__=='__main__':run(Path(sys.argv[1]),sys.argv[2:])
